// Запускается хуком capacitor:sync:after (package.json) и шагом workflow: делает APK с нативным мостом (частота экрана, настройки).
const fs=require('fs'),path=require('path');
const root=process.env.CAPACITOR_ROOT_DIR||process.cwd(),main=path.join(root,'android','app','src','main'),mf=path.join(main,'AndroidManifest.xml');
if(!fs.existsSync(mf)){console.log('patch-android: android-проекта ещё нет');process.exit(0)}
let m=fs.readFileSync(mf,'utf8');
const find=d=>{for(const e of fs.readdirSync(d,{withFileTypes:true})){const p=path.join(d,e.name);if(e.isDirectory()){const r=find(p);if(r)return r}else if(e.name==='MainActivity.java')return p}};
const ja=path.join(main,'java'),ma=fs.existsSync(ja)&&find(ja);
if(ma){const pkg=(fs.readFileSync(ma,'utf8').match(/^package\s+([\w.]+);/m)||[])[1];
if(pkg){fs.writeFileSync(ma,`package ${pkg};
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  private void hiRefresh() {
    try {
      android.view.Display d = getWindowManager().getDefaultDisplay();
      android.view.Display.Mode cur = d.getMode(), best = cur;
      for (android.view.Display.Mode m : d.getSupportedModes())
        if (m.getPhysicalWidth() == cur.getPhysicalWidth() && m.getPhysicalHeight() == cur.getPhysicalHeight() && m.getRefreshRate() > best.getRefreshRate()) best = m;
      WindowManager.LayoutParams lp = getWindow().getAttributes();
      lp.preferredDisplayModeId = best.getModeId();
      lp.preferredRefreshRate = best.getRefreshRate();
      getWindow().setAttributes(lp);
    } catch (Throwable t) {}
  }
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    hiRefresh();
    getBridge().getWebView().addJavascriptInterface(new Object() {
      @JavascriptInterface public float hz() { try { return getWindowManager().getDefaultDisplay().getRefreshRate(); } catch (Throwable t) { return 60f; } }
      @JavascriptInterface public void openSettings() {
        runOnUiThread(() -> {
          Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
          i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
          startActivity(i);
        });
      }
    }, "NativeApp");
  }
}
`);console.log('patch-android: MainActivity обновлён')}}
