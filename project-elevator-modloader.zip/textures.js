// ============================================================
// ТЕКСТУРЫ — все процедурные текстуры и материалы игры (фотореалистичная версия).
// Файл подставляется в index.html при запуске (маркеры //@TEXTURES:X@).
// Секции: A, B, C, D, E. Каждая начинается со строки //@@X.
// ============================================================
//@@A  ===== Базовые процедурные текстуры: стены, ковёр, потолок, дерево, металл, клавиши, башня ПК, лампа, отражение =====
const AN=R.capabilities.getMaxAnisotropy(),rnd=(a,b)=>a+Math.random()*(b-a);
function cv2(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return[c,c.getContext('2d')]}
function toTex(c){const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=AN;return t}
function blot(g,w,h,n,a0,a1,col,a){for(let i=0;i<n;i++){const x=rnd(0,w),y=rnd(0,h),r=rnd(a0,a1),gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(${col},${a*Math.random()})`);gr.addColorStop(.5,`rgba(${col},${a*Math.random()*.4})`);gr.addColorStop(1,`rgba(${col},0)`);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r)}}
function grain(g,w,h,n,a){for(let i=0;i<n;i++){const v=Math.random()<.5?0:255;g.fillStyle=`rgba(${v},${v},${v*.7|0},${Math.random()*a})`;g.fillRect(Math.random()*w,Math.random()*h,1+Math.random()*1.5,1+Math.random()*1.5)}}
// --- ядро: бесшовный шум, пиксельный генератор с запечённым рельефом, хелперы ---
const TX_NT=new Float32Array(65536);for(let i=0;i<65536;i++)TX_NT[i]=Math.random();
const TX_pn=(x,y,px,py)=>{const xi=Math.floor(x),yi=Math.floor(y),u=x-xi,v=y-yi,s=u*u*(3-2*u),t=v*v*(3-2*v),a=((xi%px)+px)%px,b=((yi%py)+py)%py,a1=(a+1)%px&255,b1=(b+1)%py&255;return TX_NT[(b&255)*256+(a&255)]*(1-s)*(1-t)+TX_NT[(b&255)*256+a1]*s*(1-t)+TX_NT[b1*256+(a&255)]*(1-s)*t+TX_NT[b1*256+a1]*s*t};
const TX_fp=(x,y,px,py,o=4)=>{let a=.5,s=0,n=0;for(let i=0;i<o;i++){s+=a*TX_pn(x,y,px,py);n+=a;x*=2;y*=2;px*=2;py*=2;a*=.5}return s/n};
const TX_h=(a,b)=>{const t=Math.sin(a*127.1+b*311.7)*43758.5;return t-Math.floor(t)},TX_sm=(a,b,x)=>{x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x)},TX_mx=(a,b,t)=>a+(b-a)*t,TX_mc=(A,B,t)=>[TX_mx(A[0],B[0],t),TX_mx(A[1],B[1],t),TX_mx(A[2],B[2],t)],TX_c=(a,k=1,al=1)=>`rgba(${a[0]*k|0},${a[1]*k|0},${a[2]*k|0},${al})`;
function TX_px(w,h,f,k=0){const[c,g]=cv2(w,h),im=g.createImageData(w,h),d=im.data,H=k?new Float32Array(w*h):0;let i=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++,i+=4){const q=f(x/w,y/h);d[i]=q[0];d[i+1]=q[1];d[i+2]=q[2];d[i+3]=255;if(k)H[y*w+x]=q[3]}
 if(k)for(let y=0;y<h;y++){const a=((y+h-1)%h)*w,b=y*w,e=((y+1)%h)*w;for(let x=0;x<w;x++){const s=1+k*(H[e+(x+1)%w]-H[a+(x+w-1)%w]),j=(b+x)*4;d[j]*=s;d[j+1]*=s;d[j+2]*=s}}
 g.putImageData(im,0,0);return c}
function TX_up(c,W,H){const[o,g]=cv2(W,H);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(c,0,0,W,H);return[o,g]}
// утопленная панель (внутренняя тень) и выпуклая деталь (внешняя тень + блик кромки)
function TX_in(g,x,y,w,h,r,a=.55,b=8){g.save();g.beginPath();g.roundRect(x,y,w,h,r);g.clip();g.shadowColor=`rgba(0,0,0,${a})`;g.shadowBlur=b;g.shadowOffsetX=1;g.shadowOffsetY=3;g.beginPath();g.rect(x-80,y-80,w+160,h+160);g.roundRect(x,y,w,h,r);g.fillStyle='#000';g.fill('evenodd');g.restore();g.strokeStyle='rgba(255,255,255,.28)';g.lineWidth=1.2;g.beginPath();g.moveTo(x+r,y+h+1);g.lineTo(x+w-r,y+h+1);g.stroke()}
function TX_out(g,x,y,w,h,r,fill){g.save();g.shadowColor='rgba(0,0,0,.5)';g.shadowBlur=7;g.shadowOffsetY=3;g.fillStyle=fill;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();g.restore();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.2;g.beginPath();g.roundRect(x+.6,y+.6,w-1.2,h-1.2,r);g.stroke()}
function TX_bay(g,x,y,w,h){const q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#aaa384');q.addColorStop(1,'#bdb596');g.fillStyle=q;g.fillRect(x-3,y-3,w+6,h+6);TX_in(g,x,y,w,h,3,.6,10);g.fillStyle=q;g.fillRect(x,y,w,h);TX_in(g,x,y,w,h,3,.5,9)}
function TX_led(g,x,y,r,col){const q=g.createRadialGradient(x,y,0,x,y,r*3);q.addColorStop(0,col+'aa');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(x-r*3,y-r*3,r*6,r*6);const s=g.createRadialGradient(x-r*.3,y-r*.3,0,x,y,r);s.addColorStop(0,'#fff');s.addColorStop(.4,col);s.addColorStop(1,'#000');g.fillStyle=s;g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}
function TX_txt(g,t,x,y,font,col,al='left'){g.font=font;g.textAlign=al;g.fillStyle='rgba(255,255,255,.4)';g.fillText(t,x,y+1);g.fillStyle=col;g.fillText(t,x,y)}
// пластик ABS (пожелтевший, с лёгкой неоднородностью): возвращает [canvas,ctx]
function TX_abs(W,H,A,B){const c=TX_px(W,H,(u,v)=>{const n=TX_fp(u*5,v*8,5,8,4),m=TX_pn(u*240,v*460,240,460),e=Math.min(u,1-u,v,1-v)*Math.min(W,H),k=(.94+.1*n)*(.97+.06*m)*(1-.16*TX_sm(.7,1,v))*(.82+.18*TX_sm(0,22,e)),q=TX_mc(A,B,u);return[q[0]*k*(1+.02*n),q[1]*k,q[2]*k*(1-.04*n),m*.4]},1.2);return[c,c.getContext('2d')]}
function wallTex(){const W=2048,H=768,f=(u,v)=>{const cx=u*42,ix=Math.floor(cx),fx=cx-ix,y=v*H,cy=(y-20)/56,iy=Math.floor(cy),fy=cy-iy,s=.5+.5*Math.cos(cx*6.2832),
 dm=(y>20&&y<H-60&&TX_h(ix,iy)>.08)?1-TX_sm(.55,1,Math.hypot(Math.abs(fx-.5)/.19,Math.min(fy,1-fy)/.21)):0,
 n=TX_fp(u*8,v*3,8,3,4),bl=TX_sm(.55,.8,TX_fp(u*5,v*3,5,3,3)),stk=TX_sm(.52,.8,TX_fp(u*90,v*2.5,90,3,3))*Math.pow(1-v,1.4),pn=TX_fp(u*4,v*2.5,4,3,3),top=v<.6?1:0,
 pl=TX_sm(.69,.72,pn)*top*(1-TX_sm(.5,.6,v)),ed=TX_sm(.67,.69,pn)*(1-TX_sm(.71,.73,pn))*top;
 let c=TX_mc([176,152,69],[205,184,96],v);const k=(1+.14*(s-.5)+(TX_h(ix,3)-.5)*.07)*(1-.1*dm)*(.8+.4*n)*(1-.4*bl)*(1-.28*TX_sm(.55,1,v))*(.8+.2*TX_sm(0,.12,v));
 c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[84,56,12],stk*.5);c=TX_mc(c,[224,212,164],pl*.9);const e=1-.45*ed;return[c[0]*e,c[1]*e,c[2]*e,dm*.5+s*.15-pl*.6-ed*.2]};
 const[o,g]=TX_up(TX_px(1024,384,f,3),W,H);
 let q=g.createLinearGradient(0,H-62,0,H-52);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,.45)');g.fillStyle=q;g.fillRect(0,H-62,W,10);
 q=g.createLinearGradient(0,H-55,0,H);q.addColorStop(0,'#4d3c23');q.addColorStop(.5,'#3d2e18');q.addColorStop(1,'#271c0f');g.fillStyle=q;g.fillRect(0,H-55,W,55);g.fillStyle='rgba(255,230,170,.2)';g.fillRect(0,H-55,W,3);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,H-22,W,2);
 for(let i=0;i<300;i++){g.strokeStyle=`rgba(${Math.random()<.5?'20,12,4':'130,95,55'},${rnd(.05,.2)})`;g.lineWidth=rnd(.5,1.5);const y=rnd(H-52,H-2),x=rnd(0,W);g.beginPath();g.moveTo(x,y);g.lineTo(x+rnd(60,400),y+rnd(-1,1));g.stroke()}
 blot(g,W,H,20,40,150,'20,12,2',.25);grain(g,W,H,30000,.13);return toTex(o)}
function carTex(){const S=2048,c=TX_px(1024,1024,(u,v)=>{const a=TX_fp(u*6,v*6,6,6,5),b=TX_fp(u*24,v*24,24,24,4),t=TX_pn(u*256,v*256,256,256),fb=TX_pn(u*512,v*128,512,128),
 st=TX_sm(.6,.78,TX_fp(u*4,v*4,4,4,4)),wr=TX_sm(.55,.8,TX_fp(u*3,v*2,3,2,3)),sp=TX_sm(.78,.9,TX_fp(u*12,v*12,12,12,3));
 let c=[107,102,54];const k=(.78+.5*a)*(.9+.2*b)*(.78+.44*t)*(.9+.2*fb);c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[40,32,12],st*.55);c=TX_mc(c,[150,140,76],wr*.25);c=TX_mc(c,[26,18,6],sp*.6);return[c[0],c[1],c[2],t*.6+b*.3]},2.5),[o,g]=TX_up(c,S,S);
 for(const col of['rgba(40,34,12,.35)','rgba(150,140,80,.28)','rgba(90,82,38,.35)','rgba(20,16,4,.3)']){g.strokeStyle=col;g.lineWidth=1;g.beginPath();for(let i=0;i<14000;i++){const x=rnd(0,S),y=rnd(0,S),a=rnd(0,6.3),l=rnd(3,8);g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke()}
 grain(g,S,S,60000,.22);return toTex(o)}
function ceilTex(){const S=2048,T=128,c=TX_px(512,512,(u,v)=>{const cx=u*16,cy=v*16,h=TX_h(Math.floor(cx),Math.floor(cy)),dk=h<.12?.8:1,n=TX_fp(u*8,v*8,8,8,5),m=TX_fp(u*64,v*64,64,64,3),st=TX_sm(.58,.78,TX_fp(u*5,v*5,5,5,4)),
 e=Math.min(cx%1,1-cx%1,cy%1,1-cy%1)*T,ao=.62+.38*TX_sm(0,14,e);let c=TX_mc([216,209,164],[150,112,52],st*.55);const k=(.9+.2*n)*(.95+.1*m)*dk*(.96+.08*h)*ao;return[c[0]*k,c[1]*k,c[2]*k,m*.4+.2*n]},2),[o,g]=TX_up(c,S,S);
 g.fillStyle='rgba(60,54,28,.45)';g.beginPath();for(let i=0;i<20000;i++){const x=rnd(0,S),y=rnd(0,S),r=rnd(.7,2.2);g.moveTo(x+r,y);g.arc(x,y,r,0,6.3)}g.fill();
 g.strokeStyle='rgba(80,72,40,.3)';g.lineWidth=1;g.beginPath();for(let i=0;i<4000;i++){const x=rnd(0,S),y=rnd(0,S),a=rnd(0,6.3),l=rnd(4,12);g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke();
 for(let i=0;i<=16;i++){for(const[x0,y0,x1,y1,dx,dy]of[[i*T,0,i*T,S,1,0],[0,i*T,S,i*T,0,1]]){let q=g.createLinearGradient(x0-12*dx,y0-12*dy,x0+12*dx+1e-3*dy,y0+12*dy+1e-3*dx);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.5,'rgba(0,0,0,.32)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(x0-12*dx,y0-12*dy,dx?24:S,dy?24:S);
  g.strokeStyle='#5d5840';g.lineWidth=8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='rgba(255,252,215,.5)';g.lineWidth=2;g.beginPath();g.moveTo(x0+6*dx,y0+6*dy);g.lineTo(x1+6*dx,y1+6*dy);g.stroke();g.strokeStyle='rgba(0,0,0,.35)';g.beginPath();g.moveTo(x0-4*dx,y0-4*dy);g.lineTo(x1-4*dx,y1-4*dy);g.stroke()}}
 blot(g,S,S,30,60,200,'90,60,10',.18);grain(g,S,S,40000,.12);return toTex(o)}
function woodTex(){return toTex(TX_px(1024,512,(u,v)=>{const w=TX_fp(u*8,v*16,8,16,3)*5,r=v*28+w+TX_fp(u*3,v*6,3,6,2)*10,b=Math.pow(Math.abs(Math.sin(r*3.14159)),.8),fib=TX_pn(u*16,v*512,16,512),pore=TX_pn(u*256,v*256,256,256)>.84?.3:0,kn=TX_sm(.7,.85,TX_fp(u*2,v*3,2,3,3));
 const t=Math.min(1,Math.max(0,.25+.55*b+.5*(fib-.5)-pore-kn*.3)),c=TX_mc([58,37,20],[122,84,48],t),s=.92+.12*Math.sin(v*3.14159);return[c[0]*s,c[1]*s,c[2]*s,fib*.5+b*.3]},1.5))}
function metalTex(){return toTex(TX_px(512,512,(u,v)=>{const a=TX_pn(u*3,v*400,3,400),b=TX_pn(u*9,v*160,9,160),ox=TX_sm(.6,.8,TX_fp(u*3,v*3,3,3,4));let c=[123,127,119];const k=(.82+.36*a)*(.9+.2*b);c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[70,64,40],ox*.35);return[c[0],c[1],c[2],0]}))}
function TX_kc(g,x,y,w,h,T,B,ink,t,z){g.save();g.shadowColor='rgba(0,0,0,.6)';g.shadowBlur=9;g.shadowOffsetY=4;g.fillStyle=TX_c(B);g.beginPath();g.roundRect(x,y,w,h,9);g.fill();g.restore();
 let q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,TX_c(B,1.25));q.addColorStop(1,TX_c(B,.78));g.fillStyle=q;g.beginPath();g.roundRect(x,y,w,h,9);g.fill();
 const ix=x+w*.08,iy=y+h*.05,iw=w*.84,ih=h*.76,rr=()=>{g.beginPath();g.roundRect(ix,iy,iw,ih,7)};
 q=g.createLinearGradient(0,iy,0,iy+ih);q.addColorStop(0,TX_c(T,.9));q.addColorStop(.3,TX_c(T,1.04));q.addColorStop(1,TX_c(T,1.14));g.fillStyle=q;rr();g.fill();
 q=g.createRadialGradient(x+w/2,iy+ih*.4,2,x+w/2,iy+ih*.5,w*.62);q.addColorStop(0,'rgba(0,0,0,.12)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;rr();g.fill();g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=1.4;rr();g.stroke();
 if(t){const ty=iy+ih/2+z*.35;g.font=`bold ${z}px Arial, Helvetica, sans-serif`;g.textAlign='center';g.fillStyle='rgba(0,0,0,.35)';g.fillText(t,x+w/2,ty+1.5);g.fillStyle=ink;g.fillText(t,x+w/2,ty)}}
function keysTex(){const[c,g]=cv2(1024,384);let q=g.createLinearGradient(0,0,0,384);q.addColorStop(0,'#1c1c21');q.addColorStop(1,'#111115');g.fillStyle=q;g.fillRect(0,0,1024,384);grain(g,1024,384,5000,.1);const L='QWERTYUIOPASDFGHJKLZXCVBNM';let n=0;
 const key=(x,y,w,h,t)=>TX_kc(g,x,y,w,h,[76,76,84],[40,40,46],'#dcdcdc',t,22);
 for(let r=0;r<4;r++)for(let i=0;i<14;i++)key(14+r*14+i*70,14+r*72,64,64,r>0&&i<10?L[n++%26]:'');
 key(14,302,120,64);key(150,302,120,64);key(286,302,440,64);key(742,302,120,64);key(878,302,120,64);return toTex(c)}
function towerTex(){const W=480,H=920,[c,g]=TX_abs(W,H,[200,192,160],[172,164,130]);
 [[50,40,380,100],[50,160,380,100]].forEach(([x,y,w,h])=>{TX_bay(g,x,y,w,h);g.fillStyle='#16150f';g.beginPath();g.roundRect(x+30,y+h/2-6,w-60,12,3);g.fill();TX_in(g,x+30,y+h/2-6,w-60,12,3,.7,5)});
 g.fillStyle='#16150f';g.fillRect(50,290,200,30);TX_in(g,50,290,200,30,2,.6,5);g.fillStyle='#8f8869';g.fillRect(60,300,180,5);
 g.strokeStyle='#706a50';g.lineWidth=3;g.beginPath();g.arc(240,420,52,0,6.3);g.stroke();let q=g.createRadialGradient(236,414,4,240,420,40);q.addColorStop(0,'#e4dfc6');q.addColorStop(1,'#bdb89c');g.fillStyle=q;g.beginPath();g.arc(240,420,40,0,6.3);g.fill();
 for(let y=520;y<880;y+=16){g.fillStyle='#17160f';g.fillRect(60,y,360,6);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(60,y+6,360,1.5)}
 TX_txt(g,'PENTIUM',60,360,'bold 24px Arial','#3a3624');TX_txt(g,'turbo  HDD  PWR',280,325,'16px Arial','#3a3624');return toTex(c)}
function lampTex(){const[c,g]=cv2(256,128);let q=g.createLinearGradient(0,0,0,128);q.addColorStop(0,'#fff1bd');q.addColorStop(.5,'#fffbe8');q.addColorStop(1,'#fff0bb');g.fillStyle=q;g.fillRect(0,0,256,128);
 [33,101].forEach(y=>{const t=g.createLinearGradient(0,y-12,0,y+12);t.addColorStop(0,'rgba(255,255,255,0)');t.addColorStop(.5,'rgba(255,255,255,1)');t.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=t;g.fillRect(6,y-12,244,24)});
 q=g.createLinearGradient(0,0,256,0);q.addColorStop(0,'rgba(120,100,40,.4)');q.addColorStop(.12,'rgba(120,100,40,0)');q.addColorStop(.88,'rgba(120,100,40,0)');q.addColorStop(1,'rgba(120,100,40,.4)');g.fillStyle=q;g.fillRect(0,0,256,128);
 for(let x=0;x<=256;x+=16){g.fillStyle='rgba(140,125,60,.3)';g.fillRect(x,0,1.6,128);g.fillStyle='rgba(255,255,255,.55)';g.fillRect(x+1.6,0,1,128)}
 for(let y=0;y<=128;y+=16){g.fillStyle='rgba(140,125,60,.3)';g.fillRect(0,y,256,1.6);g.fillStyle='rgba(255,255,255,.55)';g.fillRect(0,y+1.6,256,1)}
 for(const y of[0,124]){q=g.createLinearGradient(0,y,0,y+4);q.addColorStop(0,'#7a7a7a');q.addColorStop(1,'#3d3d3d');g.fillStyle=q;g.fillRect(0,y,256,4)}grain(g,256,128,1200,.05);return toTex(c)}
function reflTex(){const[c,g]=cv2(256,144);let q=g.createLinearGradient(0,0,256,144);q.addColorStop(0,'rgba(255,255,255,.14)');q.addColorStop(.35,'rgba(255,255,255,.02)');q.addColorStop(.5,'rgba(255,255,255,.08)');q.addColorStop(.6,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(255,240,200,.06)');g.fillStyle=q;g.fillRect(0,0,256,144);
 q=g.createRadialGradient(40,30,2,40,30,110);q.addColorStop(0,'rgba(255,255,255,.1)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,256,144);
 q=g.createRadialGradient(128,72,60,128,72,170);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,.08)');g.fillStyle=q;g.fillRect(0,0,256,144);return toTex(c)}

//@@B  ===== PBR-набор: шум/fbm, нормали, ткань, дерево, металл, пластик, розетки, монитор, клавиатура, шкаф, вентиляция, кружка, часы, постер =====
const NZT=TX_NT;
const vn=(x,y)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=xi&255,b=yi&255,a1=(a+1)&255,b1=(b+1)&255;return NZT[b*256+a]*(1-u)*(1-v)+NZT[b*256+a1]*u*(1-v)+NZT[b1*256+a]*(1-u)*v+NZT[b1*256+a1]*u*v};
const fbm=(x,y,o=4)=>{let a=.5,s=0;for(let i=0;i<o;i++){s+=a*vn(x,y);x=x*2.03+17;y=y*2.03+9;a*=.5}return s};
const vnp=(x,y,m)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=xi&(m-1),b=yi&(m-1),a1=(xi+1)&(m-1),b1=(yi+1)&(m-1);return NZT[b*256+a]*(1-u)*(1-v)+NZT[b*256+a1]*u*(1-v)+NZT[b1*256+a]*(1-u)*v+NZT[b1*256+a1]*u*v};
const fbmp=(x,y,m,o=4)=>{let a=.5,s=0;for(let i=0;i<o;i++){s+=a*vnp(x,y,m);x*=2;y*=2;m*=2;a*=.5}return s};
const PQ=[0,0,0];
function pix(w,h,f){const[c,g]=cv2(w,h),im=g.createImageData(w,h),d=im.data;let i=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const q=f(x,y);d[i++]=q[0];d[i++]=q[1];d[i++]=q[2];d[i++]=255}g.putImageData(im,0,0);return[c,g]}
function nmap(c,k=4){const w=c.width,h=c.height,s=c.getContext('2d').getImageData(0,0,w,h).data,H=new Float32Array(w*h);for(let i=0;i<w*h;i++)H[i]=(s[i*4]*.3+s[i*4+1]*.59+s[i*4+2]*.11)/255;
 const[o,og]=cv2(w,h),im=og.createImageData(w,h),d=im.data;
 for(let y=0;y<h;y++){const y0=((y+h-1)%h)*w,y1=y*w,y2=((y+1)%h)*w;for(let x=0;x<w;x++){const xl=(x+w-1)%w,xr=(x+1)%w,dx=(H[y1+xl]-H[y1+xr])*k,dy=(H[y2+x]-H[y0+x])*k,n=1/Math.hypot(dx,dy,1),i=(y1+x)*4;d[i]=(dx*n*.5+.5)*255;d[i+1]=(dy*n*.5+.5)*255;d[i+2]=(n*.5+.5)*255;d[i+3]=255}}
 og.putImageData(im,0,0);const t=new THREE.CanvasTexture(o);t.anisotropy=AN;return t}
const rpt=(t,x,y)=>{t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(x,y);return t};
// пластик: микрорельеф «апельсиновая корка»
const PLN=rpt(nmap(pix(256,256,(x,y)=>{PQ[0]=PQ[1]=PQ[2]=(fbmp(x/32,y/32,8,5)*.7+Math.random()*.3)*255;return PQ})[0],7),10,10);
// тканое полотно: нити с кручёными волокнами
const FC=pix(256,256,(x,y)=>{const cx=x&7,cy=y&7,o=((x>>3)+(y>>3))&1,h=o?Math.sin(cy/8*Math.PI):Math.sin(cx/8*Math.PI),fz=o?TX_pn(x/4,y*1.5,64,384):TX_pn(x*1.5,y/4,384,64),n=Math.random()*.15+fbmp(x/16,y/16,16,3)*.3,v=Math.min(255,(.6+.3*h+fz*.18+n*.35)*255*(o?1:.92));PQ[0]=PQ[1]=PQ[2]=v;return PQ})[0],FT=rpt(toTex(FC),12,12),FN=rpt(nmap(FC,9),12,12);
const fabM=col=>new THREE.MeshStandardMaterial({color:col,map:FT,normalMap:FN,roughness:1});
// шлифованный металл: тонкие продольные риски
const BMC=TX_px(256,256,(u,v)=>{const a=TX_pn(u*2,v*256,2,256),b=TX_pn(u*6,v*128,6,128),s=.5+.6*a+.3*b,t=TX_fp(u*3,v*3,3,3,3);const k=(.86+.2*(s-.7))*(.95+.1*t);return[163*k,165*k,166*k,0]});
// дуб: годовые кольца, волокна, поры, сердцевинные лучи
const WC=pix(1024,512,(x,y)=>{const w1=fbm(x*.004,y*.03,3)*5,r=y*.055+w1+fbm(x*.0015,y*.006,2)*14,b=Math.pow(Math.abs(Math.sin(r*3.14159)),.8),fib=fbm(x*.02,y*.6,3),pore=vn(x*.5,y*1.2)>.86?.4:0,ray=vn(x*.05,y*.9)>.9?.12:0,t=Math.min(1,Math.max(0,.25+.55*b+.5*(fib-.5)-pore+ray));PQ[0]=88+90*t;PQ[1]=54+70*t;PQ[2]=26+44*t;return PQ})[0],WT=rpt(toTex(WC),.5,1),WN=rpt(nmap(WC,5),.5,1);
const wood=new THREE.MeshPhysicalMaterial({map:WT,normalMap:WN,roughness:.5,clearcoat:.3,clearcoatRoughness:.35}),woodDk=new THREE.MeshStandardMaterial({color:0x8a6a4c,map:WT,normalMap:WN,roughness:.6}),
 dark=new THREE.MeshStandardMaterial({color:0x1b1c20,roughness:.42,normalMap:PLN,normalScale:new THREE.Vector2(.6,.6)}),beige=new THREE.MeshStandardMaterial({color:0xd2caa8,roughness:.48,normalMap:PLN,normalScale:new THREE.Vector2(.5,.5)}),
 metal=new THREE.MeshStandardMaterial({color:0xc4c6c7,map:rpt(toTex(BMC),4,4),normalMap:rpt(nmap(BMC,3),4,4),roughness:.32,metalness:.95}),fab=fabM(0x7a7960),
 chromeM=new THREE.MeshStandardMaterial({color:0xdadcdc,metalness:1,roughness:.18});
function plateTex(t){const[c,g]=cv2(256,384);g.scale(2,2);let q=g.createLinearGradient(0,0,128,192);q.addColorStop(0,'#ece5cd');q.addColorStop(1,'#d1c7a7');g.fillStyle=q;g.fillRect(0,0,128,192);grain(g,128,192,900,.1);blot(g,128,192,5,10,40,'120,95,40',.22);
 g.fillStyle='rgba(255,255,255,.65)';g.fillRect(0,0,128,2);g.fillRect(0,0,2,192);g.fillStyle='rgba(0,0,0,.3)';g.fillRect(0,190,128,2);g.fillRect(126,0,2,192);
 q=g.createLinearGradient(0,0,0,192);q.addColorStop(0,'rgba(255,255,255,.35)');q.addColorStop(.5,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(0,0,0,.14)');g.fillStyle=q;g.fillRect(3,3,122,186);
 const scr=(x,y,a)=>{g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.arc(x+1,y+1.8,7,0,6.3);g.fill();const r=g.createRadialGradient(x-2.5,y-2.5,1,x,y,7);r.addColorStop(0,'#f6f6f2');r.addColorStop(.7,'#b4b4aa');r.addColorStop(1,'#8a8a80');g.fillStyle=r;g.beginPath();g.arc(x,y,6,0,6.3);g.fill();const ca=Math.cos(a),sa=Math.sin(a);g.strokeStyle='#33332f';g.lineWidth=1.7;g.beginPath();g.moveTo(x+ca*5,y+sa*5);g.lineTo(x-ca*5,y-sa*5);g.stroke();g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=.8;g.beginPath();g.moveTo(x+ca*5-sa*1.6,y+sa*5+ca*1.6);g.lineTo(x-ca*5-sa*1.6,y-sa*5+ca*1.6);g.stroke()};
 const rec=(x,y,w,h)=>{g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.roundRect(x-1,y-1,w+2,h+2,8);g.fill();q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#bfb696');q.addColorStop(1,'#dbd2b4');g.fillStyle=q;g.beginPath();g.roundRect(x,y,w,h,7);g.fill();TX_in(g,x,y,w,h,7,.45,5)};
 if(t==='outlet'){[20,108].forEach(y=>{rec(24,y,80,64);[50,78].forEach(x=>{g.fillStyle='#0d0c0a';g.fillRect(x-3,y+12,7,24);g.fillStyle='rgba(176,138,70,.8)';g.fillRect(x-2,y+33,5,2)});const r=g.createRadialGradient(64,y+50,0,64,y+50,5);r.addColorStop(0,'#000');r.addColorStop(1,'#1b1a16');g.fillStyle=r;g.beginPath();g.arc(64,y+50,4.5,0,6.3);g.fill()});scr(64,96,.5)}
 else{rec(30,38,68,116);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(34,96,60,2);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(34,98,60,1);scr(64,16,.9);scr(64,176,2.1)}
 return toTex(c)}
function towerTex2(){const W=480,H=920,[c,g]=TX_abs(W,H,[214,207,174],[191,183,147]);
 const tx=(t,x,y,f='bold 14px Arial')=>TX_txt(g,t,x,y,f,'#4a4632');
 TX_bay(g,40,36,400,92);g.fillStyle='#24231e';g.beginPath();g.roundRect(70,66,340,12,3);g.fill();TX_in(g,70,66,340,12,3,.7,5);g.fillStyle='rgba(255,255,255,.25)';g.fillRect(70,79,340,1.5);TX_out(g,330,92,60,18,4,'#a79f80');g.fillStyle='#4a4632';g.fillRect(340,100,40,2);tx('CD-ROM',64,108);TX_led(g,300,101,4,'#22bb66');
 TX_bay(g,40,150,400,70);g.strokeStyle='rgba(0,0,0,.3)';g.lineWidth=2;g.beginPath();g.moveTo(60,185);g.lineTo(420,185);g.stroke();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1;g.beginPath();g.moveTo(60,187);g.lineTo(420,187);g.stroke();
 TX_bay(g,40,238,400,100);g.fillStyle='#121210';g.beginPath();g.roundRect(150,276,180,12,3);g.fill();TX_in(g,150,276,180,12,3,.7,5);g.fillStyle='#8c8a80';g.fillRect(152,279,176,2);TX_out(g,350,300,50,20,4,'#a79f80');TX_led(g,120,312,4,'#dd3333');tx('3.5"  1.44MB',64,326,'12px Arial');
 let q=g.createLinearGradient(170,360,310,480);q.addColorStop(0,'#8a8466');q.addColorStop(.5,'#c9c3a6');q.addColorStop(1,'#6e684e');g.strokeStyle=q;g.lineWidth=5;g.beginPath();g.arc(240,420,66,0,6.3);g.stroke();g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=2;g.beginPath();g.arc(240,420,70,.2,2.6);g.stroke();
 g.fillStyle='#8f8869';g.fillRect(60,350,170,34);g.fillStyle='#14130e';g.fillRect(64,354,162,26);TX_in(g,64,354,162,26,2,.7,6);g.fillStyle='#d1342a';g.shadowColor='#ff3322';g.shadowBlur=6;g.font='bold 22px monospace';g.textAlign='left';g.fillText('P5  200',74,374);g.shadowBlur=0;tx('turbo',250,372);
 q=g.createRadialGradient(397,677,1,400,680,13);q.addColorStop(0,'#3a392f');q.addColorStop(1,'#0e0d09');g.fillStyle=q;g.beginPath();g.arc(400,680,12,0,6.3);g.fill();g.strokeStyle='#7d775c';g.lineWidth=3;g.stroke();tx('HDD  PWR',340,716,'12px Arial');
 for(let y=520;y<880;y+=16){g.fillStyle='#17160f';g.fillRect(60,y,360,7);q=g.createLinearGradient(0,y,0,y+7);q.addColorStop(0,'rgba(0,0,0,.6)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(60,y,360,7);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(60,y+7,360,2)}
 tx('PENTIUM',60,500,'bold 26px Arial');return toTex(c)}
function monTex(){const W=1024,H=614,[c,g]=TX_abs(W,H,[225,218,186],[194,186,151]);TX_in(g,30,30,964,554,10,.75,16);
 let q=g.createLinearGradient(34,34,990,580);q.addColorStop(0,'#0a0a0b');q.addColorStop(1,'#030303');g.fillStyle=q;g.fillRect(34,34,956,546);
 q=g.createRadialGradient(300,180,10,512,307,620);q.addColorStop(0,'rgba(255,255,255,.04)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(34,34,956,546);
 TX_txt(g,'V I E W S Y N C',60,604,'bold 20px Arial','#7d765c');TX_txt(g,'LCD  15"  XGA',470,603,'14px Arial','#7d765c');
 for(let i=0;i<3;i++)TX_out(g,820+i*34,592,26,14,3,'#cdc5a6');TX_led(g,960,599,3.5,'#22cc66');return toTex(c)}
function keysTex2(){const W=1024,H=348,[c,g]=cv2(W,H);let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#948c73');q.addColorStop(1,'#827b64');g.fillStyle=q;g.fillRect(0,0,W,H);grain(g,W,H,4000,.1);
 const u=63,key=(x,y,w,h,t)=>TX_kc(g,x,y,w,h,[232,225,198],[196,188,158],'#34322a',t,t.length>2?15:22),
 row=(a,y)=>{let x=(W-15*u)/2;a.forEach(([t,w=1])=>{key(x,y,w*u-6,60,t);x+=w*u})},ch=s=>[...s].map(t=>[t]);
 row([...ch('`1234567890-='),['BKSP',2]],8);row([['TAB',1.5],...ch('QWERTYUIOP[]'),['\\',1.5]],76);row([['CAPS',1.75],...ch("ASDFGHJKL;'"),['ENTER',2.25]],144);row([['SHIFT',2.25],...ch('ZXCVBNM,./'),['SHIFT',2.75]],212);row([['CTRL',1.5],['WIN',1.25],['ALT',1.25],['',6.25],['ALT',1.25],['WIN',1.25],['MENU',1.25],['CTRL',1.5]],280);return toTex(c)}
function cabTex(){const W=256,H=666,c=TX_px(W,H,(u,v)=>{const p=TX_pn(u*128,v*333,128,333),s=TX_pn(u*4,v*300,4,300),n=TX_fp(u*5,v*5,5,5,4);let q=TX_mc([152,163,155],[127,138,131],u);const k=(.92+.1*p)*(.94+.1*s)*(.9+.2*n);return[q[0]*k,q[1]*k,q[2]*k,p*.4]},1),g=c.getContext('2d');
 [[.1,.3615],[.3692,.6308],[.6385,.9]].forEach(([a,b])=>{const y0=a*H,y1=b*H;g.fillStyle='rgba(0,0,0,.6)';g.fillRect(8,y0-3,W-16,y1-y0+6);TX_in(g,8,y0-3,W-16,y1-y0+6,2,.7,8);
  let q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,'#a4afa7');q.addColorStop(1,'#86918a');g.fillStyle=q;g.fillRect(12,y0,W-24,y1-y0-2);
  g.fillStyle='rgba(255,255,255,.45)';g.fillRect(12,y0,W-24,2);g.fillRect(12,y0,2,y1-y0-2);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(12,y1-4,W-24,2);g.fillRect(W-14,y0,2,y1-y0-2);
  for(let i=0;i<14;i++){g.strokeStyle=`rgba(255,255,255,${rnd(.04,.12)})`;g.lineWidth=1;const x=rnd(14,W-14),y=rnd(y0,y1);g.beginPath();g.moveTo(x,y);g.lineTo(x+rnd(-30,30),y+rnd(-8,8));g.stroke()}
  TX_out(g,94,y0+12,68,26,2,'#c9ced0');g.fillStyle='#f3efe0';g.fillRect(99,y0+17,58,16);TX_in(g,99,y0+17,58,16,1,.5,3);g.fillStyle='#4a4a4a';g.font='11px Arial';g.textAlign='center';g.fillText('ARCHIVE',128,y0+29);
  TX_in(g,84,y1-36,88,16,6,.7,6);q=g.createLinearGradient(0,y1-32,0,y1-24);q.addColorStop(0,'#eef0f0');q.addColorStop(.5,'#9aa0a2');q.addColorStop(1,'#d4d8d9');g.fillStyle=q;g.beginPath();g.roundRect(90,y1-32,76,8,4);g.fill()});
 blot(g,W,H,10,10,50,'30,25,10',.15);grain(g,W,H,3000,.08);return toTex(c)}
function ventTex(){const[c,g]=TX_abs(256,170,[220,216,196],[206,201,180]);for(let i=0;i<15;i++){const y=8+i*10.5;let q=g.createLinearGradient(0,y,0,y+6);q.addColorStop(0,'#050504');q.addColorStop(1,'#2a281f');g.fillStyle=q;g.beginPath();g.roundRect(10,y,236,6,1.5);g.fill();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(10,y-1.5,236,1.5);g.fillStyle='rgba(255,255,255,.6)';g.fillRect(10,y+6,236,1.5)}
 g.strokeStyle='#8e8a74';g.lineWidth=4;g.strokeRect(2,2,252,166);g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1;g.strokeRect(4.5,4.5,247,161);blot(g,256,170,6,10,40,'110,100,70',.18);grain(g,256,170,700,.08);return toTex(c)}
function padTex(){const c=TX_px(256,358,(u,v)=>{const w=TX_pn(u*256,v*358,256,358),r=TX_pn(u*128,v*179,128,179),n=TX_fp(u*4,v*4,4,4,3),q=TX_mc([47,58,78],[34,42,56],(u+v)/2),k=(.82+.3*w)*(.9+.2*r)*(.9+.2*n);return[q[0]*k,q[1]*k,q[2]*k,w*.5+r*.3]},1.5),g=c.getContext('2d');
 g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=3;g.setLineDash([7,5]);g.strokeRect(10.5,12,236,338);g.strokeStyle='#8a93a6';g.lineWidth=2.2;g.strokeRect(10,10,236,338);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=.8;g.strokeRect(10,9.2,236,338);g.setLineDash([]);
 g.strokeStyle='rgba(138,147,166,.25)';g.lineWidth=6;g.beginPath();g.arc(128,179,46,0,6.3);g.stroke();grain(g,256,358,3500,.1);return toTex(c)}
function mugTex(){const[c,g]=cv2(512,256);let q=g.createLinearGradient(0,0,0,256);q.addColorStop(0,'#f8f4e9');q.addColorStop(1,'#e1dac6');g.fillStyle=q;g.fillRect(0,0,512,256);blot(g,512,256,8,20,70,'160,140,90',.08);
 g.font='bold 34px Arial';g.textAlign='center';[0,256,512].forEach(x=>{[["WORLD'S",98],['OKAYEST',138],['EMPLOYEE',178]].forEach(([t,y])=>{g.fillStyle='rgba(255,255,255,.7)';g.fillText(t,x,y+1.5);g.fillStyle='rgba(29,53,87,.94)';g.fillText(t,x,y)})});
 g.strokeStyle='rgba(90,55,20,.35)';g.lineWidth=5;g.beginPath();g.arc(400,200,26,.2,5);g.stroke();g.fillStyle='rgba(110,70,30,.25)';g.beginPath();g.ellipse(256,252,200,6,0,0,6.3);g.fill();
 g.fillStyle='rgba(90,80,60,.35)';for(let i=0;i<120;i++)g.fillRect(rnd(0,512),rnd(0,256),1,1);return toTex(c)}
function clockFace(){const[c,g]=cv2(512,512);let q=g.createRadialGradient(256,256,20,256,256,256);q.addColorStop(0,'#f4efdd');q.addColorStop(.85,'#e0d9bd');q.addColorStop(1,'#cfc7a8');g.fillStyle=q;g.beginPath();g.arc(256,256,256,0,6.3);g.fill();grain(g,512,512,3000,.07);blot(g,512,512,6,30,110,'130,100,40',.12);
 g.strokeStyle='rgba(0,0,0,.28)';g.lineWidth=5;g.beginPath();g.arc(256,256,248,0,6.3);g.stroke();g.strokeStyle='rgba(27,27,30,.5)';g.lineWidth=1.5;g.beginPath();g.arc(256,256,240,0,6.3);g.stroke();
 g.strokeStyle='#1b1b1e';g.lineCap='round';for(let i=0;i<60;i++){const a=i*Math.PI/30,l=i%5?10:22,r1=236,r2=r1-l;g.lineWidth=i%5?2:5;g.beginPath();g.moveTo(256+Math.sin(a)*r1,256-Math.cos(a)*r1);g.lineTo(256+Math.sin(a)*r2,256-Math.cos(a)*r2);g.stroke()}
 g.font='bold 54px Arial, Helvetica, sans-serif';g.textAlign='center';g.textBaseline='middle';for(let i=1;i<=12;i++){const a=i*Math.PI/6,x=256+Math.sin(a)*172,y=256-Math.cos(a)*172+3;g.fillStyle='rgba(255,255,255,.5)';g.fillText(i,x+1,y+1.5);g.fillStyle='#1b1b1e';g.fillText(i,x,y)}
 g.font='bold 22px Arial';g.fillText('QUARTZ',256,170);g.font='14px Arial';g.fillText('MADE IN CHINA',256,372);return toTex(c)}
function posterFx(g){let q=g.createLinearGradient(0,0,0,360);q.addColorStop(0,'rgba(160,120,40,.16)');q.addColorStop(1,'rgba(160,120,40,.06)');g.fillStyle=q;g.fillRect(0,0,256,360);
 for(const[x0,y0,x1,y1]of[[0,180,256,182],[128,0,129,360]]){g.strokeStyle='rgba(0,0,0,.16)';g.lineWidth=.8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='rgba(255,255,255,.22)';g.beginPath();g.moveTo(x0+(y0?0:1.5),y0+(y0?1.5:0));g.lineTo(x1+(y0?0:1.5),y1+(y0?1.5:0));g.stroke()}
 q=g.createLinearGradient(0,176,0,188);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.5,'rgba(0,0,0,.07)');q.addColorStop(1,'rgba(255,255,255,.06)');g.fillStyle=q;g.fillRect(0,176,256,12);
 blot(g,256,360,5,15,50,'120,80,20',.25);
 [[4,12,-.7],[252,12,.7]].forEach(([x,y,a])=>{g.save();g.translate(x,y);g.rotate(a);g.shadowColor='rgba(0,0,0,.25)';g.shadowBlur=3;g.shadowOffsetY=1;const t=g.createLinearGradient(-14,0,14,0);t.addColorStop(0,'rgba(232,220,168,.7)');t.addColorStop(.5,'rgba(244,236,196,.55)');t.addColorStop(1,'rgba(226,214,160,.7)');g.fillStyle=t;g.fillRect(-14,-6,28,12);g.restore()});
 const e=g.createLinearGradient(0,0,12,0);e.addColorStop(0,'rgba(0,0,0,.28)');e.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=e;g.fillRect(0,0,12,360);g.save();g.translate(256,0);g.scale(-1,1);g.fillStyle=e;g.fillRect(0,0,12,360);g.restore();
 const b=g.createLinearGradient(0,348,0,360);b.addColorStop(0,'rgba(0,0,0,0)');b.addColorStop(1,'rgba(0,0,0,.18)');g.fillStyle=b;g.fillRect(0,348,256,12)}

//@@C  ===== Материалы стен (wm) и полов (fm) этажа 3: палитры, обои, ковёр =====
const TX_rc={};function TX_rgb(s){if(TX_rc[s])return TX_rc[s];const[c,g]=cv2(1,1);g.fillStyle=s;g.fillRect(0,0,1,1);const d=g.getImageData(0,0,1,1).data;return TX_rc[s]=[d[0],d[1],d[2]]}
function wm(k){if(WM[k])return WM[k];const W=1024,H=384,[m,g]=cv2(W,H),[a,b]=PAL[k/10|0],p=k%10,r=mk(k*7919+1),A=TX_rgb(a),B=TX_rgb(b);
 g.fillStyle='#000';g.fillRect(0,0,W,H);g.fillStyle=g.strokeStyle='#f00';g.lineWidth=6;
 if(p==0)for(let x=0;x<W;x+=40)g.fillRect(x,0,20,H);
 else if(p==1)for(let y=0;y<H;y+=32)for(let x=y/32%2*32;x<W;x+=64)g.fillRect(x+2,y+2,60,28);
 else if(p==2)for(let y=0;y<H;y+=40)for(let x=0;x<W;x+=40){g.beginPath();g.moveTo(x,y+20);g.lineTo(x+20,y);g.lineTo(x+40,y+20);g.lineTo(x+20,y+40);g.fill()}
 else if(p==3){for(let i=0;i<W;i+=64)g.fillRect(i,0,3,H);for(let i=0;i<H;i+=64)g.fillRect(0,i,W,3)}
 else if(p==4){g.fillRect(0,H*.55,W,H);g.fillStyle='#ff0';g.fillRect(0,H*.55-6,W,6)}
 else if(p==5)for(let i=0;i<500;i++){g.beginPath();g.arc(r()*W,r()*H,3+r()*4,0,6.3);g.fill()}
 else if(p==6)blot(g,W,H,80,40,200,'255,0,0',1);
 else if(p==7)for(let x=0;x<W;x+=r()*50+20)g.fillRect(x,0,3,H);
 else if(p==8)for(let y=0;y<H;y+=48)for(let x=y/48%2*48;x<W;x+=96)g.fillRect(x,y,48,48);
 else for(let y=0;y<H;y+=40){g.beginPath();for(let x=0;x<=W;x+=32)g.lineTo(x,y+x/32%2*20);g.stroke()}
 const M=g.getImageData(0,0,W,H).data,hue=r()*360,tn=TX_rgb(`hsl(${hue|0},35%,50%)`),sd=r()*50,w2=W>>1,h2=H>>1,[o0,og0]=cv2(w2,h2),im=og0.createImageData(w2,h2),d=im.data;let i=0;
 for(let y=0;y<h2;y++)for(let x=0;x<w2;x++,i+=4){const u=x/w2,v=y/h2,mi=(y*2*W+x*2)*4,al=.35*M[mi]/255+.3*M[mi+1]/255,e=(y>5&&y<h2-5&&x>5&&x<w2-5)?((M[mi+W*8+8]-M[mi-W*8-8])/255):0,
  n=TX_fp(u*16,v*6,16,6,3),f=TX_pn(u*256,v*96,256,96),bl=TX_fp(u*7+sd,v*3,7,3,3),st=TX_sm(.55,.8,TX_fp(u*60+sd,v*2.5,60,3,2))*Math.pow(1-v,1.3),dm=TX_sm(.58,.8,bl);
  let c=[A[0]+(B[0]-A[0])*al,A[1]+(B[1]-A[1])*al,A[2]+(B[2]-A[2])*al];c=TX_mc(c,tn,.07);
  let l=(.84+.3*n)*(.92+.14*f)*(1+e*.22)*(1-.35*dm)*(1-.25*TX_sm(.6,1,v))*(.82+.18*TX_sm(0,.12,v));c=TX_mc([c[0]*l,c[1]*l,c[2]*l],[40,28,6],st*.4);
  if(y>h2-13){const q=(y-(h2-13))/13,w=TX_mc([62,46,28],[38,28,16],q),lw=.85+.3*TX_pn(u*64,v*8,64,8),hl=y<h2-11?1.4:1;c=[w[0]*lw*hl,w[1]*lw*hl,w[2]*lw*hl]}
  d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255}
 og0.putImageData(im,0,0);const[o,og]=TX_up(o0,W,H);grain(og,W,H,9000,.14);
 return WM[k]=new THREE.MeshStandardMaterial({map:toTex(o),roughness:.92,side:THREE.DoubleSide})}
function fm(k){if(FM[k])return FM[k];const r=mk(k*131+7),P=['#6b6636','#55524a','#7a6a4a','#4a4d52','#5f6b52','#6a5a56','#74705c','#4f5a63','#6e5f3a','#58504a','#66705e','#7b7468'],B=TX_rgb(P[k]),tile=k%4==1,
 xs=[],ys=[];if(tile){for(let x=0;x<1024;x+=90+r()*110)xs.push(x);for(let y=0;y<1024;y+=90+r()*110)ys.push(y)}
 const S=384,dx=new Float32Array(S),dy=new Float32Array(S);if(tile){for(let i=0;i<S;i++){dx[i]=Math.min(...xs.map(x=>Math.abs(x*S/1024-i)),Math.abs(S-i));dy[i]=Math.min(...ys.map(y=>Math.abs(y*S/1024-i)),Math.abs(S-i))}}
 const c=TX_px(S,S,(u,v)=>{const a=TX_fp(u*8,v*8,8,8,5),b=TX_fp(u*32,v*32,32,32,4),t=TX_pn(u*256,v*256,256,256),st=TX_sm(.6,.78,TX_fp(u*5,v*5,5,5,4)),lt=TX_sm(.6,.8,TX_fp(u*6+3,v*6,6,6,4)),sp=TX_sm(.8,.9,TX_fp(u*14,v*14,14,14,3));
  let c=B,l=(.8+.4*a)*(.92+.16*b),h=t*.5+b*.3;
  if(tile){const x=u*S|0,y=v*S|0,e=Math.min(dx[x],dy[y]),gr=1-TX_sm(.5,1.6,e),tt=TX_h(Math.floor(u*8),Math.floor(v*8));l*=.9+.2*tt;l*=(.94+.12*TX_pn(u*128,v*128,128,128));c=TX_mc(c,[24,20,14],gr*.8);h=h*(1-gr)-gr*.6}
  else l*=(.8+.4*t);
  c=TX_mc([c[0]*l,c[1]*l,c[2]*l],[26,18,6],st*.5);c=TX_mc(c,[230,220,170],lt*.1);c=TX_mc(c,[20,14,4],sp*.5);return[c[0],c[1],c[2],h]},tile?2:2.5),[o,g]=TX_up(c,1024,1024);
 g.strokeStyle='rgba(0,0,0,.22)';g.beginPath();for(let i=0;i<(tile?3000:7000);i++){const x=r()*1024,y=r()*1024,a=r()*6.3,l=3+r()*6;g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke();grain(g,1024,1024,30000,.18);
 const t=toTex(o);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(1.5,1.5);return FM[k]=new THREE.MeshStandardMaterial({map:t,roughness:tile?.75:1})}

//@@D  ===== Текстуры этажа 2 и лифта: кирпич, бетон, ржавчина, штукатурка, плитка, решётка, лужи =====
const eC=(w,h,f)=>{const[c,g]=cv2(w,h);f(g,w,h);return c};
const T2=(w,h,f,rx=1,ry=1)=>{const t=toTex(eC(w,h,f));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);return t};
const MT=(t,r,b,m=0)=>new THREE.MeshStandardMaterial({map:t,bumpMap:t,bumpScale:b,roughness:r,metalness:m,side:THREE.DoubleSide});
const N1=(u,v,m,o=4)=>fbmp(u*m,v*m,m,o),H1=TX_h,sm=TX_sm,mx=TX_mx,mc=TX_mc;
// ржавчина на произвольном 2D-контексте: низкое разрешение + апскейл
function rustFill(g,w,h,n=70){const s=Math.min(1,512/Math.max(w,h)),cw=Math.max(8,w*s|0),ch=Math.max(8,h*s|0),sh=(n-70)*.002;
 const c=TX_px(cw,ch,(u,v)=>{const a=TX_fp(u*6,v*6,6,6,5),b=TX_fp(u*32,v*32,32,32,4),d=TX_fp(u*12+.5,v*12,12,12,4),r=TX_sm(.4-sh,.62-sh,a*.7+d*.5),q=TX_mc([70,62,58],TX_mc([112,52,22],[184,100,44],b),r),k=(.78+.44*b)*(1-.3*TX_sm(.65,.9,d)*(1-r));return[q[0]*k,q[1]*k,q[2]*k,r*.6+b*.4]},2);
 g.drawImage(c,0,0,w,h);grain(g,w,h,Math.min(w*h/90,60000),.25)}
const brickFn=(cr,R=12,C=4)=>(u,v)=>{const bh=1/R,bw=1/C,row=Math.floor(v/bh),fy=(v-row*bh)/bh,uo=u+(row&1)*bw/2,cc=Math.floor(uo/bw),fx=uo/bw-cc,id=((cc%C)+C)%C,h1=H1(id,row),h2=H1(id+9,row+3),
 ed=Math.min(Math.min(fx,1-fx)*bw*1024,Math.min(fy,1-fy)*bh*1024),nz=N1(u,v,64,3),m=sm(1.5,5,ed+(nz-.5)*7),gr=N1(u,v,8,5),sp=N1(u,v,128,2),soot=sm(.5,.85,TX_fp(u*24,v*3,24,3,3))*(1-.5*v);
 let c=mc([112,52,36],[158,92,62],h1);const dk=.72+.35*h2,sm2=.55+.6*gr,kk=dk*sm2*(.85+.3*sp)*(1-.4*soot);c=[c[0]*kk,c[1]*kk,c[2]*kk];
 const mo=mc([88,84,76],[124,118,106],sp);mo[0]*=.5+gr*.7;mo[1]*=.5+gr*.7;mo[2]*=.5+gr*.7;let q=mc(mo,c,m),h=m*(.7+.3*sp)+.1*nz;
 if(cr){const cf=Math.abs(N1(u,v,8,5)-.5);if(cf<.012){q=mc(q,[12,9,7],.8);h-=.5}}
 return[q[0],q[1],q[2],h,.9-.1*m*sp,0]};
function brickTex(cr){const f=brickFn(cr,16,8),t=toTex(TX_px(512,512,(u,v)=>f(u,v),4));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(2,1);return t}
// --- фотореалистичные PBR (бесшовные fbm, albedo + normal + roughness/metal) ---
function PH(w,rx,ry,fn,o={}){const n=w*w,cl=new Uint8ClampedArray(n*4),H=new Float32Array(n),rg=new Uint8ClampedArray(n*4),nm=new Uint8ClampedArray(n*4);
 for(let y=0;y<w;y++)for(let x=0;x<w;x++){const i=y*w+x,q=fn(x/w,y/w);cl[i*4]=q[0];cl[i*4+1]=q[1];cl[i*4+2]=q[2];cl[i*4+3]=255;H[i]=q[3];rg[i*4]=255;rg[i*4+1]=Math.min(1,q[4])*255;rg[i*4+2]=(q[5]==null?o.m||0:q[5])*255;rg[i*4+3]=255}
 const k=o.k||4,g=(a,b)=>H[((b+w)%w)*w+((a+w)%w)];
 for(let y=0;y<w;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,dx=(g(x+1,y)-g(x-1,y))*k,dy=(g(x,y+1)-g(x,y-1))*k,l=Math.hypot(dx,dy,1);nm[i]=(-dx/l*.5+.5)*255;nm[i+1]=(dy/l*.5+.5)*255;nm[i+2]=(1/l*.5+.5)*255;nm[i+3]=255}
 const T=(d,srgb)=>{const[c,g2]=cv2(w,w);g2.putImageData(new ImageData(d,w,w),0,0);const t=new THREE.CanvasTexture(c);t.colorSpace=srgb?THREE.SRGBColorSpace:THREE.NoColorSpace;t.anisotropy=AN;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);t.generateMipmaps=true;t.minFilter=THREE.LinearMipmapLinearFilter;return t},rm=T(rg,0);
 return new THREE.MeshStandardMaterial({map:T(cl,1),normalMap:T(nm,0),normalScale:new THREE.Vector2(o.ns||1,o.ns||1),roughnessMap:rm,roughness:1,metalnessMap:o.m?rm:null,metalness:o.m?1:0,side:THREE.DoubleSide})}
const concFn=(base,st)=>(u,v)=>{const a=N1(u,v,4,5),b=N1(u,v,32,4),p=N1(u,v,128,2),pore=sm(.62,.7,p)*.7,sn=N1(u+.3,v,2,4),f=Math.min(1,Math.min(Math.min(u,1-u),Math.min(v,1-v))*130),agg=sm(.78,.82,N1(u+.1,v,256,1)),rs=sm(.55,.85,TX_fp(u*20,v*2,20,2,3))*(st?.6:.25);
 let c=base*(.6+.7*a)*(.88+.24*b)*(1-pore*.5)*(.55+.45*f)*(1+.12*agg);const cf=Math.abs(N1(u,v,16,5)-.5)<.006?.35:1;c*=cf;
 return[c*1.02+rs*18,c-rs*4,c*.95+(st?sn*8:0)-rs*12,.5*b+.3*a-pore*.4-(1-f)*.4+agg*.05,.92-.1*pore,0]};
const rustFn=(band)=>(u,v)=>{const a=N1(u,v,8,5),b=N1(u,v,64,4),c2=N1(u+.5,v,16,4),r=sm(.38,.62,a*.7+c2*.5),pt=sm(.46,.56,N1(u+.2,v,4,5)+.25*(c2-.5)),pe=sm(.5,.56,N1(u+.2,v,4,5)+.25*(c2-.5))-pt;
 let c=mc([66,60,56],mc([112,52,22],[178,98,42],b),r);c=mc(c,[78,88,66],(1-pt)*(1-r)*.7);
 if(band){const y=(v*8)%1;const l=y<.04||y>.96?.55:1;c=[c[0]*l,c[1]*l,c[2]*l]}c=[c[0]*(.8+.4*b),c[1]*(.8+.4*b),c[2]*(.8+.4*b)];
 return[c[0],c[1],c[2],r*.6+b*.4-(band&&((v*8)%1<.04)?.5:0)+(1-pt)*.15-pe*.1,mx(.38,.92,Math.max(r,(1-pt)*.8)),(1-r*.85)*pt]};
const plasterFn=(u,v)=>{const a=N1(u,v,4,5),b=N1(u,v,64,4),st=N1(u,v*.25,16,4),d=sm(.5,.7,N1(u,v,6,4)),pl=sm(.7,.76,N1(u+.2,v,10,4)),ck=Math.abs(N1(u,v,12,5)-.5)<.004?1:0;let c=mc([164,156,132],[190,182,158],b);c=mc(c,[88,98,66],d*.5);const k=(.6+.6*a)*(.85+.3*st);c=[c[0]*k,c[1]*k,c[2]*k];c=mc(c,[210,205,190],pl*.6);c=mc(c,[40,36,28],ck*.8);
 return[c[0],c[1],c[2],b*.5+a*.3-pl*.6-ck*.5,.93,0]};
const tileFn=(u,v)=>{const T=4,tx=Math.floor(u*T),ty=Math.floor(v*T),fx=u*T-tx,fy=v*T-ty,ed=Math.min(Math.min(fx,1-fx),Math.min(fy,1-fy))*1024/T,gr=sm(2,6,ed+(N1(u,v,64,2)-.5)*3),h1=H1(tx,ty),dirt=N1(u,v,8,5),sc=sm(.9,.95,N1(u,v*.2,128,2)),p=N1(u,v,64,4),ml=sm(.6,.8,N1(u+.4,v,16,4))*(1-gr);
 let c=mc([84,92,80],[116,120,104],h1);const k=(.55+.7*dirt)*(.9+.2*p)*(1-sc*.25);c=[c[0]*k,c[1]*k,c[2]*k];c=mc([30,28,24],c,gr);c=mc(c,[44,52,34],ml*.6);
 return[c[0],c[1],c[2],gr*(.8+.2*p)-sc*.1,mx(.9,.3+.3*dirt,gr*h1),0]};
const BRK=PH(1024,1,1,brickFn(1),{k:6,ns:1.3}),BRK2=PH(1024,1,1,brickFn(0),{k:6,ns:1.3});
const CONC=PH(1024,4,4,concFn(118),{k:5}),CONC2=PH(512,4,4,concFn(70,1),{k:5});
const RUST=PH(512,1,1,rustFn(0),{k:5,m:1}),RUSTP=PH(512,.5,2,rustFn(1),{k:5,m:1}),RUSTBAR=PH(256,1,2,rustFn(1),{k:4,m:1});
const PLASTER=PH(1024,1,1,plasterFn,{k:3});
const TILEF=PH(1024,8,8,tileFn,{k:6});
const GRATE=MT(T2(128,128,(g,w,h)=>{g.fillStyle='#050505';g.fillRect(0,0,w,h);
 for(let i=0;i<8;i++){let q=g.createLinearGradient(i*16,0,i*16+5,0);q.addColorStop(0,'#3a2414');q.addColorStop(.45,'#9a6a3c');q.addColorStop(1,'#32200f');g.fillStyle=q;g.fillRect(i*16,0,5,h);q=g.createLinearGradient(0,i*16,0,i*16+5);q.addColorStop(0,'#3a2414');q.addColorStop(.45,'#8c5e34');q.addColorStop(1,'#32200f');g.fillStyle=q;g.fillRect(0,i*16,w,5)}
 blot(g,w,h,10,10,40,'180,90,30',.4);blot(g,w,h,8,8,30,'20,10,4',.4);grain(g,w,h,900,.3)},4,4),.7,1,.6);
const TX_pc=pix(128,128,(x,y)=>{PQ[0]=PQ[1]=PQ[2]=fbmp(x/16,y/16,8,4)*255;return PQ})[0];
const PUDDLE=new THREE.MeshStandardMaterial({color:0x1b2a2c,roughness:.05,metalness:.6,transparent:true,opacity:.75,normalMap:rpt(nmap(TX_pc,2),3,3),normalScale:new THREE.Vector2(.15,.15)});
const HMAT=new THREE.MeshStandardMaterial({color:0x6f6a2a,roughness:.5,metalness:.2});
const BRICKM=new THREE.MeshStandardMaterial({map:brickTex(0),roughness:.95,color:0xcc9988});
const BRKG=new THREE.BoxGeometry(.22,.07,.105);
const CYL2=new THREE.CylinderGeometry(1,1,1,14);
const BARM=new THREE.MeshStandardMaterial({map:RUST.map,color:0xcc8866,roughness:.7,metalness:.6});

//@@E  ===== Материалы новых комнат: паркет, мебель, офисные материалы =====
const woodFn=(u,v)=>{const P=5,pi=Math.floor(u*P),fx=u*P-pi,vv=v*3+pi*.4,row=Math.floor(vv),fy=vv-row,ed=Math.min(Math.min(fx,1-fx)*1024/P,Math.min(fy,1-fy)*1024/3),gr=sm(1,5,ed),h1=H1(pi,row),g=TX_fp(u*60,v*6,60,6,4),s=N1(u,v,64,3),fib=TX_pn(u*300,v*20,300,20);
 let c=mc([70,44,26],[128,86,52],h1*.7+g*.5);const k=(.7+.5*s)*(.92+.16*fib);c=mc([18,12,8],[c[0]*k,c[1]*k,c[2]*k],gr);return[c[0],c[1],c[2],gr*(.6+.3*g)+fib*.06,.7+.1*(1-gr),0]};
const PARQ=PH(1024,4,4,woodFn,{k:5}),FLZ={corr:TILEF,plaza:TILEF,bed:PARQ,hall:CONC,store:CONC},FL3={meet:PARQ,break:TILEF,srv:CONC,copy:TILEF},
OM=(c,r=.8,m=0,n=0)=>new THREE.MeshStandardMaterial(n?{color:c,roughness:r,metalness:m,normalMap:PLN,normalScale:new THREE.Vector2(n,n)}:{color:c,roughness:r,metalness:m}),
MATT=fabM(0x6c7480),PILL=fabM(0xd8d4c6),LOCK=OM(0x4d5a52,.45,.6,.3),
O_DESK=new THREE.MeshStandardMaterial({color:0xb8987a,map:WT,normalMap:WN,roughness:.55}),O_SCR=OM(0x07090c,.15,.3),O_KEY=OM(0x1c1c20,.5,0,.4),O_CHR=fabM(0x2c3036),O_FAB=fabM(0x6f7f8c),O_WHT=OM(0xe6e6e0,.5,0,.4),
O_PAP=OM(0xf2f0e6,.9),O_PLA=OM(0xd8d0a8,.6,0,.3),O_BIN=OM(0x2f3338,.6,.4,.3),O_GRN=OM(0x2f6a35,.9),O_POT=OM(0x8a4f33,.8,0,.5),O_BLU=OM(0x6fb6e8,.2),
O_RACK=OM(0x16181c,.4,.7,.3),O_CNT=OM(0xb9b3a4,.5,0,.4),O_LG=new THREE.MeshBasicMaterial({color:0x33ff66}),O_LR=new THREE.MeshBasicMaterial({color:0xff3322}),O_LB=new THREE.MeshBasicMaterial({color:0xffaa22});
