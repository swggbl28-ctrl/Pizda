// bridge.js — универсальный мост + установщик модов из ZIP. Положи рядом с index.html:
//   <script type="module" src="bridge.js"></script>
// Мост сам находит scene/camera/renderer. Кнопка 🧩 (справа сверху) или drag&drop .zip — установка модов.
//
// ZIP-мод (без зависимостей, ничего заранее регистрировать не нужно):
//  • mod.json (необязателен): { id, name, version, type, main: "a.js" | [..], html: false | [..] }
//  • .js  — ES-модуль или обычный скрипт. Точки входа = файлы, которые никто не импортирует (или "main").
//           Относительные import работают, 'three' берётся из игры. export init(game, mod) / update(dt, game) / dispose().
//  • .css — подключается (url(...) внутри чинится). .html — вставляется в страницу (скрипты исполняются).
//  • Остальное (png/jpg/glb/mp3/json…) — ЗАМЕНЯЕТ файл игры с тем же путём (fetch, XHR, THREE-лоадеры, img/audio.src)
//    и доступно через mod.url('path') / game.mods.url('path').
//  Всё, что мод добавил в scene / game.onUpdate при init, снимается при выключении мода.
//  Моды хранятся в IndexedDB и подгружаются при каждом запуске.

let THREE = window.THREE;                       // глобальный THREE (script-тег) или модуль 'three'
try { THREE ||= await import('three'); } catch { console.warn('[bridge] "three" не найден: задай game.set({THREE})'); }

// --- ошибки прямо на экране (на Android нет консоли) ---
const report = (e, where = '') => {
  console.error('[bridge]', where, e);
  let el = document.getElementById('bridge-err');
  if (!el) {
    el = document.createElement('pre');
    el.id = 'bridge-err';
    el.style.cssText = 'position:fixed;left:0;right:0;bottom:0;max-height:35%;overflow:auto;margin:0;padding:8px;background:#400d;color:#fcc;font:11px monospace;z-index:99999;white-space:pre-wrap';
    el.onclick = () => el.remove();             // тап — закрыть
    document.body.append(el);
  }
  el.textContent += `[${where}] ${e?.stack || e?.message || e}\n`;
};
addEventListener('error', (ev) => report(ev.error || ev.message, 'error'));
addEventListener('unhandledrejection', (ev) => report(ev.reason, 'promise'));

// --- сам мост ---
const events = {};
let resolveReady; const ready = new Promise((r) => (resolveReady = r));

export const game = window.game = {
  THREE, scene: null, camera: null, renderer: null,
  dt: 0, time: 0,
  velocity: THREE ? new THREE.Vector3() : null, // скорость камеры, считается сама
  onGround: true,                               // поставь сам, если есть физика
  updaters: [],

  onUpdate(fn) { this.updaters.push(fn); return () => this.updaters.splice(this.updaters.indexOf(fn), 1); },
  on(name, fn) { (events[name] ||= []).push(fn); },
  emit(name, data) { (events[name] || []).forEach((f) => { try { f(data); } catch (e) { report(e, 'event:' + name); } }); },
  set(o) { return Object.assign(this, o); },    // ручная подстановка: game.set({ scene, camera })

  // game.use('./skin-manager.js') или game.use(await import('./x.js')) — для сборщиков.
  // Ждёт первый кадр, вызывает export init(game), если он есть. Возвращает модуль.
  async use(modOrPath) {
    await ready;
    const m = typeof modOrPath === 'string' ? await import(/* @vite-ignore */ modOrPath) : modOrPath;
    try { await m.init?.(this); } catch (e) { report(e, 'init'); }
    return m;
  },
};

if (THREE?.WebGLRenderer) {
  const proto = THREE.WebGLRenderer.prototype, render = proto.render;
  const cur = new THREE.Vector3(), prev = new THREE.Vector3(), raw = new THREE.Vector3();
  let fresh = true, last = performance.now(), hasPrev = false;
  const tick = () => { fresh = true; requestAnimationFrame(tick); };
  tick();

  proto.render = function (scene, camera) {
    game.renderer ||= this;
    if (this === game.renderer && fresh) {      // один раз за кадр, основной рендерер
      fresh = false;
      game.scene = scene; game.camera = camera;
      const now = performance.now();
      game.dt = Math.min((now - last) / 1000, 0.1); last = now; game.time += game.dt;

      camera.getWorldPosition(cur);
      if (hasPrev && game.dt > 0) game.velocity.lerp(raw.copy(cur).sub(prev).divideScalar(game.dt), 0.3);
      prev.copy(cur); hasPrev = true;

      for (const fn of game.updaters) { try { fn(game.dt, game); } catch (e) { report(e, 'update'); } }
      resolveReady();
    }
    return render.call(this, scene, camera);
  };
}

// =====================  МОДЫ  =====================
const td = new TextDecoder();
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', svg: 'image/svg+xml', ktx2: 'image/ktx2',
  mp3: 'audio/mpeg', ogg: 'audio/ogg', wav: 'audio/wav', m4a: 'audio/mp4', mp4: 'video/mp4', webm: 'video/webm', json: 'application/json',
  glb: 'model/gltf-binary', gltf: 'model/gltf+json', css: 'text/css', js: 'text/javascript', mjs: 'text/javascript', html: 'text/html',
  txt: 'text/plain', woff: 'font/woff', woff2: 'font/woff2', ttf: 'font/ttf', otf: 'font/otf', wasm: 'application/wasm' };
const ext = (p) => p.split('.').pop().toLowerCase();
const mime = (p) => MIME[ext(p)] || 'application/octet-stream';
const norm = (p) => { const o = []; for (const s of String(p).replace(/\\/g, '/').split('/')) { if (s === '..') o.pop(); else if (s && s !== '.') o.push(s); } return o.join('/'); };
const slug = (s) => String(s || '').toLowerCase().replace(/[^\w.\u0400-\u04ff-]+/g, '-').replace(/^-+|-+$/g, '');
const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' })[c]);
const MANIFESTS = ['mod.json', 'mod.manifest.json', 'manifest.json'];
const RX = /(\bfrom\s*|\bimport\s*\(?\s*)(['"])([^'"]+)\2/g;   // import/export ... from '...'
const readMeta = (f) => { const k = MANIFESTS.find((n) => n in f); try { return k ? JSON.parse(td.decode(f[k])) : {}; } catch { return {}; } };

// --- ZIP без библиотек (stored + deflate через DecompressionStream) ---
async function unzip(buf) {
  const u8 = new Uint8Array(buf), v = new DataView(buf);
  let e = u8.length - 22;
  while (e >= 0 && v.getUint32(e, true) !== 0x06054b50) e--;
  if (e < 0) throw new Error('Это не ZIP-архив');
  let n = v.getUint16(e + 10, true), p = v.getUint32(e + 16, true);
  const tmp = Object.create(null);
  for (; n-- > 0 && v.getUint32(p, true) === 0x02014b50;) {
    const flag = v.getUint16(p + 8, true), method = v.getUint16(p + 10, true), csize = v.getUint32(p + 20, true);
    const nl = v.getUint16(p + 28, true), el = v.getUint16(p + 30, true), cl = v.getUint16(p + 32, true), off = v.getUint32(p + 42, true);
    const raw = td.decode(u8.subarray(p + 46, p + 46 + nl));
    p += 46 + nl + el + cl;
    if (raw.endsWith('/') || /(^|\/)(__MACOSX|\.DS_Store|Thumbs\.db)(\/|$)/.test(raw)) continue;
    if (flag & 1) throw new Error('ZIP зашифрован паролем: ' + raw);
    if (csize === 0xffffffff) throw new Error('ZIP64 не поддерживается');
    const start = off + 30 + v.getUint16(off + 26, true) + v.getUint16(off + 28, true);
    const data = u8.subarray(start, start + csize);
    if (method === 0) tmp[norm(raw)] = data.slice();
    else if (method === 8) {
      if (typeof DecompressionStream === 'undefined') throw new Error('Нет DecompressionStream: обнови Android System WebView');
      tmp[norm(raw)] = new Uint8Array(await new Response(new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))).arrayBuffer());
    } else throw new Error(`Метод сжатия ${method} не поддерживается: ${raw}`);
  }
  const k = Object.keys(tmp), top = k[0]?.split('/')[0];
  const strip = k.length && k.every((x) => x.startsWith(top + '/'));   // единственная папка-обёртка
  const files = Object.create(null);
  for (const x of k) files[strip ? x.slice(top.length + 1) : x] = tmp[x];
  if (!k.length) throw new Error('ZIP пустой');
  return files;
}

// --- хранилище (IndexedDB) ---
const idb = (() => {
  const open = () => new Promise((res, rej) => { const r = indexedDB.open('bridge-mods', 1); r.onupgradeneeded = () => r.result.createObjectStore('mods', { keyPath: 'id' }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  const tx = async (mode, fn) => { try { const d = await open(); return await new Promise((res, rej) => { const t = d.transaction('mods', mode), r = fn(t.objectStore('mods')); t.oncomplete = () => res(r.result); t.onerror = () => rej(t.error); }); } catch (e) { report(e, 'idb'); } };
  return { all: async () => (await tx('readonly', (s) => s.getAll())) || [], put: (v) => tx('readwrite', (s) => s.put(v)), del: (id) => tx('readwrite', (s) => s.delete(id)) };
})();

// --- состояние + подмена файлов игры ---
const recs = new Map();   // id -> запись (в т.ч. выключенные)
const mods = new Map();   // id -> запущенный мод
const ov = new Map();     // путь -> [{ m, p }]  (последний мод побеждает)
let render = () => {};
let shim;

const ovUrl = (u) => {
  if (!ov.size || !u) return null;
  try {
    const x = new URL(String(u), location.href);
    if (x.origin !== location.origin) return null;
    const base = new URL('.', location.href).pathname;
    let p = decodeURIComponent(x.pathname);
    if (p.startsWith(base)) p = p.slice(base.length);
    const e = ov.get(norm(p))?.at(-1);
    return e ? e.m.url(e.p) : null;
  } catch { return null; }
};
{
  const f0 = window.fetch;
  window.fetch = function (i, o) { const r = ovUrl(typeof i === 'string' ? i : i?.href || i?.url); return f0.call(this, r || i, o); };
  const x0 = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (m, u, ...a) { return x0.call(this, m, ovUrl(u) || u, ...a); };
  for (const C of [HTMLImageElement, HTMLMediaElement, HTMLSourceElement]) {
    const d = Object.getOwnPropertyDescriptor(C.prototype, 'src');
    if (d?.set) Object.defineProperty(C.prototype, 'src', { ...d, set(v) { d.set.call(this, ovUrl(v) || v); } });
  }
}
const patchThree = () => {
  const m = game.THREE?.DefaultLoadingManager;
  if (!m || m.__bridge) return;
  m.__bridge = true; const r = m.resolveURL.bind(m); m.resolveURL = (u) => r(ovUrl(u) || u);
};

// --- запуск / остановка мода ---
async function start(rec, files) {
  await when; patchThree();
  const id = rec.id; let m;
  try {
    files ||= await unzip(rec.buf);
    const meta = readMeta(files), names = Object.keys(files);
    m = { id, name: rec.name, version: rec.version, meta, files: names, game, blobs: {}, nodes: [], cleanups: [] };
    mods.set(id, m);
    const url = m.url = (p) => { p = norm(p); return p in files ? (m.blobs[p] ||= URL.createObjectURL(new Blob([files[p]], { type: mime(p) }))) : null; };
    m.get = (p) => files[norm(p)]; m.read = (p) => td.decode(files[norm(p)]); m.json = (p) => JSON.parse(m.read(p)); m.cleanup = (fn) => m.cleanups.push(fn);
    const find = (from, spec) => {
      spec = spec.split(/[?#]/)[0];
      if (!spec || /^([a-z][\w+.-]*:|\/\/)/i.test(spec)) return null;
      for (const b of [spec[0] === '/' ? '' : from.slice(0, from.lastIndexOf('/') + 1), '']) {
        const p = norm(b + spec), f = [p, p + '.js', p + '.mjs', p + '/index.js'].find((c) => c in files);
        if (f) return f;
      }
      return null;
    };
    const jsUrl = (p, stack = []) => {            // ES-модуль с переписанными import → blob-URL
      const key = 'js:' + p;
      if (m.blobs[key]) return m.blobs[key];
      if (stack.includes(p)) return null;
      const src = td.decode(files[p]).replace(RX, (all, pre, q, spec) => {
        let t = null;
        if (spec === 'three' && game.THREE) t = shim ||= URL.createObjectURL(new Blob([`const T=window.game.THREE;export default T;export const {${Object.keys(game.THREE).filter((k) => k !== 'default' && /^[A-Za-z_$][\w$]*$/.test(k)).join(',')}}=T;`], { type: 'text/javascript' }));
        else if (spec[0] === '.' || spec[0] === '/') { const f = find(p, spec); if (f) t = /\.m?js$/i.test(f) ? jsUrl(f, [...stack, p]) : url(f); }
        return t ? pre + q + t + q : all;
      });
      return (m.blobs[key] = URL.createObjectURL(new Blob([src], { type: 'text/javascript' })));
    };

    const scene0 = new Set(game.scene?.children), upd0 = new Set(game.updaters);

    // 1) файлы-замены
    for (const p of names) {
      if (/\.(m?js|css|html?)$/i.test(p) || MANIFESTS.includes(p)) continue;
      for (const k of new Set([p, p.replace(/^assets\//, '')])) { if (!ov.has(k)) ov.set(k, []); ov.get(k).push({ m, p }); }
    }
    // 2) CSS
    for (const p of names.filter((n) => ext(n) === 'css')) {
      const st = document.createElement('style'); st.dataset.mod = id;
      st.textContent = td.decode(files[p]).replace(/url\(\s*(['"]?)([^'")]+)\1\s*\)/g, (a, q, s) => { const f = find(p, s); return f ? `url("${url(f)}")` : a; });
      document.head.append(st); m.nodes.push(st);
    }
    // 3) HTML-фрагменты
    for (const p of Array.isArray(meta.html) ? meta.html.map(norm) : meta.html === false ? [] : names.filter((n) => /\.html?$/i.test(n))) {
      if (!files[p]) throw new Error('нет файла ' + p);
      const d = new DOMParser().parseFromString(td.decode(files[p]), 'text/html'), box = document.createElement('div');
      box.dataset.mod = id; box.append(...d.head.children, ...d.body.childNodes);
      box.querySelectorAll('[src],[href]').forEach((el) => ['src', 'href'].forEach((a) => { const f = el.hasAttribute(a) && find(p, el.getAttribute(a)); if (f) el.setAttribute(a, url(f)); }));
      box.querySelectorAll('script').forEach((s) => { const n = document.createElement('script'); for (const a of s.attributes) n.setAttribute(a.name, a.value); n.textContent = s.textContent; s.replaceWith(n); });
      document.body.append(box); m.nodes.push(box);
    }
    // 4) JS: точки входа
    const jsAll = names.filter((n) => /\.m?js$/i.test(n)), ref = new Set();
    for (const p of jsAll) for (const x of td.decode(files[p]).matchAll(RX)) { const f = /^[./]/.test(x[3]) && find(p, x[3]); if (f) ref.add(f); }
    const entries = meta.main ? [].concat(meta.main).map(norm) : jsAll.filter((p) => !ref.has(p));
    for (const p of entries) {
      if (!files[p]) throw new Error('нет файла ' + p);
      if (/^\s*(import\s*[\w{*'"]|export\s)/m.test(td.decode(files[p]))) {          // ES-модуль
        const ns = await import(/* @vite-ignore */ jsUrl(p));
        const init = ns.init || (typeof ns.default === 'function' ? ns.default : ns.default?.init?.bind(ns.default));
        await init?.(game, m);
        if (ns.update) game.onUpdate(ns.update);
        if (ns.dispose) m.cleanups.push(() => ns.dispose(game, m));
      } else await new Promise((res, rej) => {                                        // обычный скрипт
        const s = document.createElement('script'); s.src = url(p); s.onload = res; s.onerror = () => rej(new Error('ошибка скрипта ' + p));
        document.head.append(s); m.nodes.push(s);
      });
    }
    m.added = (game.scene?.children || []).filter((c) => !scene0.has(c));
    m.upd = game.updaters.filter((f) => !upd0.has(f));
    rec.error = null;
    game.emit('mod:loaded', m);
    if (meta.type) game.emit('mod:' + meta.type, m);
  } catch (e) {
    rec.error = e?.message || String(e); report(e, 'mod:' + id);
    await unload(id);
  }
  render();
}

async function unload(id) {
  const m = mods.get(id); if (!m) return;
  mods.delete(id);
  for (const f of m.cleanups.reverse()) { try { await f(); } catch (e) { report(e, 'dispose'); } }
  (m.upd || []).forEach((f) => { const i = game.updaters.indexOf(f); if (i >= 0) game.updaters.splice(i, 1); });
  (m.added || []).forEach((o) => o.removeFromParent?.());
  m.nodes.forEach((n) => n.remove());
  for (const [k, a] of ov) { const r = a.filter((e) => e.m !== m); r.length ? ov.set(k, r) : ov.delete(k); }
  Object.values(m.blobs).forEach((u) => URL.revokeObjectURL(u));
  game.emit('mod:unloaded', m);
}

// --- публичный API: game.mods ---
const api = game.mods = {
  loaded: mods,
  list: () => [...recs.values()],
  url: (p) => { const e = ov.get(norm(p))?.at(-1); return e ? e.m.url(e.p) : null; },
  async install(src, fname) {                       // File | Blob | ArrayBuffer | URL-строка
    if (typeof src === 'string') { const r = await fetch(src); if (!r.ok) throw new Error(`${src}: ${r.status}`); fname ||= src.split('/').pop(); src = await r.arrayBuffer(); }
    else if (src instanceof Blob) { fname ||= src.name; src = await src.arrayBuffer(); }
    else if (ArrayBuffer.isView(src)) src = src.buffer.slice(src.byteOffset, src.byteOffset + src.byteLength);
    const files = await unzip(src), meta = readMeta(files);
    const id = slug(meta.id || meta.name || String(fname || '').replace(/\.zip$/i, '')) || 'mod-' + Date.now();
    await unload(id);
    const rec = { id, name: meta.name || id, version: meta.version || '', enabled: true, buf: src, time: Date.now() };
    recs.set(id, rec); await idb.put(rec);
    await start(rec, files);
    return mods.get(id);
  },
  async setEnabled(id, on) {
    const r = recs.get(id); if (!r) return;
    r.enabled = on; await idb.put(r);
    on ? await start(r) : await unload(id);
    render();
  },
  async remove(id) { await unload(id); recs.delete(id); await idb.del(id); render(); },
  open: () => ui.open(), ui: (on = true) => (ui.host.style.display = on ? '' : 'none'),
};

// --- интерфейс (кнопка 🧩, shadow DOM, drag&drop) ---
const ui = (() => {
  const host = document.createElement('div'); host.style.cssText = 'position:fixed;top:8px;right:8px;z-index:99998';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
    button{font:inherit;color:#fff;background:#2a2f3a;border:1px solid #556;border-radius:8px;padding:8px 12px}
    #fab{width:40px;height:40px;border-radius:50%;padding:0;opacity:.6;font-size:20px}
    #pan{position:fixed;inset:0;background:#000b;display:none;align-items:center;justify-content:center;font:14px sans-serif;color:#fff}
    #pan.on{display:flex} #box{width:min(440px,94vw);max-height:85vh;overflow:auto;background:#161a22;border-radius:12px;padding:12px}
    .row{display:flex;gap:6px;align-items:center;padding:8px 0;border-top:1px solid #333} .row b{flex:1;overflow:hidden;text-overflow:ellipsis}
    .err{color:#f88;font-size:12px;padding-bottom:6px} small{opacity:.6} p{margin:8px 0;opacity:.8}
  </style><button id="fab">🧩</button><div id="pan"><div id="box"></div></div>
  <input id="file" type="file" accept=".zip,application/zip,application/x-zip-compressed" multiple hidden>`;
  const $ = (s) => root.querySelector(s);
  let msg = '';
  const draw = () => {
    $('#box').innerHTML = `<div class="row" style="border:0"><b>🧩 Моды</b><button data-a="close">✕</button></div>
      <button data-a="pick" style="width:100%">＋ Установить ZIP</button><p>${esc(msg) || 'Или перетащи .zip на экран'}</p>` +
      ([...recs.values()].map((r) => `<div class="row"><b>${esc(r.name)} <small>${esc(r.version)}</small></b>
        <button data-a="tog" data-id="${esc(r.id)}">${r.enabled ? 'Вкл' : 'Выкл'}</button><button data-a="del" data-id="${esc(r.id)}">🗑</button></div>
        ${r.error ? `<div class="err">${esc(r.error)}</div>` : ''}`).join('') || '<p>Нет установленных модов</p>');
  };
  const say = (t) => { msg = t; draw(); };
  const installAll = async (list) => {
    for (const f of list) {
      say(`Установка ${f.name}…`);
      try { await api.install(f); say('Готово: ' + f.name); } catch (e) { say('Ошибка: ' + (e?.message || e)); report(e, 'install'); }
    }
  };
  root.addEventListener('click', async (e) => {
    if (e.target.id === 'fab') { draw(); $('#pan').classList.add('on'); return; }
    if (e.target.id === 'pan') return $('#pan').classList.remove('on');
    const b = e.target.closest('[data-a]'); if (!b) return;
    const { a, id } = b.dataset;
    if (a === 'close') $('#pan').classList.remove('on');
    else if (a === 'pick') $('#file').click();
    else if (a === 'tog') await api.setEnabled(id, !recs.get(id).enabled);
    else if (a === 'del') await api.remove(id);
  });
  $('#file').onchange = (e) => { installAll([...e.target.files]); e.target.value = ''; };
  addEventListener('dragover', (e) => { if (e.dataTransfer?.types?.includes('Files')) e.preventDefault(); });
  addEventListener('drop', (e) => {
    const z = [...(e.dataTransfer?.files || [])].filter((f) => /\.zip$/i.test(f.name) || /zip/.test(f.type));
    if (z.length) { e.preventDefault(); $('#pan').classList.add('on'); installAll(z); }
  });
  document.body.append(host);
  render = () => $('#pan').classList.contains('on') && draw();
  return { host, open: () => { draw(); $('#pan').classList.add('on'); } };
})();

// --- автозагрузка установленных модов ---
const when = THREE?.WebGLRenderer ? Promise.race([ready, new Promise((r) => setTimeout(r, 5000))]) : new Promise((r) => setTimeout(r, 300));
(async () => {
  const all = (await idb.all()).sort((a, b) => a.time - b.time);
  for (const r of all) recs.set(r.id, r);
  for (const r of all) if (r.enabled) await start(r);
  render();
})().catch((e) => report(e, 'mods'));
