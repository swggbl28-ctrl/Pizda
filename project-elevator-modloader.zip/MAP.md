# MAP (генерируется build.js — не править руками)

| Файл | Строк | Что | Верхний уровень |
|---|---|---|---|
| `src/textures/A-base-canvas.js` | 80 | textures/A-base-canvas.js — Канвас-текстуры без PBR-карт: wallTex, carTex, ceilTex, woodTex, metalTex, keysTex, towerTex, lampTex, reflTex + ядро (шум _pn/_fp, _px, _up, _in/_out, _abs, _kc). Грузится раньше остальных секций. | AN, cv2, toTex, blot, grain, TX_NT, TX_pn, TX_fp, TX_h, TX_px, TX_up, TX_in… |
| `src/textures/B-pbr-props.js` | 87 | textures/B-pbr-props.js — Шум/fbm, нормали (nmap), ткань, дерево, металл, пластик, розетки (plateTex), башня ПК (towerTex2), монитор (monTex), клавиатура (keysTex2), шкаф (cabTex), вентиляция, коврик, кружка, часы, постер (posterFx). | NZT, vn, fbm, vnp, fbmp, PQ, pix, nmap, rpt, PLN, FC, fabM… |
| `src/textures/C-floor3-walls-floors.js` | 38 | textures/C-floor3-walls-floors.js — wm(k) — обои этажа 3, fm(k) — полы этажа 3 (используют PAL, WM, FM, mk из игры). | TX_rc, wm, fm |
| `src/textures/D-floor2-lift.js` | 55 | textures/D-floor2-lift.js — Этаж 2 и лифт: PH() (PBR-генератор), brickFn/concFn/rustFn/plasterFn/tileFn, BRK*/CONC*/RUST*/PLASTER/TILEF, GRATE, PUDDLE, BRICKM, BARM. | eC, T2, MT, N1, rustFill, brickFn, brickTex, PH, concFn, rustFn, plasterFn, tileFn… |
| `src/textures/E-rooms-materials.js` | 13 | textures/E-rooms-materials.js — Паркет (PARQ), FLZ/FL3, офисные материалы O_*, MATT, PILL, LOCK. | woodFn, PARQ |
| `src/core/00-imports.js` | 6 | import THREE и заглушка window.mp (мультиплеер-хуки). Всегда первым. |  |
| `src/shaders/body-shadows.js` | 47 | ШЕЙДЕРЫ: гибридные лучевые тени тела игрока (аналитический луч против капсул, на свет и пиксель). Патчит THREE.ShaderChunk.lights_fragment_begin и Material.prototype.onBeforeCompile; uniforms BCU/BBU. Вся GLSL-логика игры только здесь. | BCU |
| `src/core/01-renderer-scene.js` | 11 | $() = getElementById, renderer R, сцена S, камера cam, resize. | $, R, S, cam |
| `src/world/room-base.js` | 28 | Стартовая комната: PMREM-окружение, стены/пол/потолок на текстурах (wallTex, carTex, ceilTex…). Маркер //@TEXTURES:A@ — сюда вставляется секция A из textures. | PBR, shade, BG, rbg, g, p, box, fl, ce, wallP |
| `src/world/materials-kit.js` | 10 | Набор PBR-материалов. Маркер //@TEXTURES:B@ (секция B), хелперы V3/Q4/hp(). | frm, V3 |
| `src/world/props-desk.js` | 22 | Плинтус, реквизит, стол. | tFr, pled, pbtn |
| `src/ui/monitor-screen.js` | 17 | Монитор и интерактивный экран-canvas (drawScreen). | SW, scM, rf, scl, vid, mode, rr, icons, _old |
| `src/ui/desktop-icons.js` | 51 | Векторные иконки рабочего стола ПК и их клики. | icoFloppy, icoVideo, icoSkin, drawIcon, drawWall, taskbar, drawScreen, screenTap |
| `src/world/cassette.js` | 16 | Магнитофон (тап по кнопкам). | cas, reelM, cled, hit |
| `src/world/extra-detail.js` | 23 | Дополнительные мелкие детали комнаты. |  |
| `src/world/lights.js` | 10 | Освещение комнаты. | LAMP, hemi, sun |
| `src/world/weather.js` | 31 | Погода за окном. | bd, N, rg, DN, dg2, GW, bead, nd, drips |
| `src/audio/audio-engine.js` | 135 | ЗВУКИ: процедурный WebAudio — реверб, шторм, ветер, гул ламп, шаги (20 вариантов), гром, стекло, удары, кнопки магнитофона. Всё синтезируется кодом, аудиофайлов нет. | AC, playing, auRnd, aGn, aBq, aLoop, aOut, aBn, aTn, mkNoise, mkIR, mkRain… |
| `src/mechanics/touch-input.js` | 63 | Управление касаниями: джойстик, осмотр, тап по объектам. | ray, act, pick, wf, UA, INJ, HOME, setDoc, load, emu, emuLib, emuStart… |
| `src/ui/video-player.js` | 74 | Видеоплеер на ПК (+ pan/pinch/tap, браузер-окно #web). | drawVid, lw, vFilter, fitK, syncUI, applyV, upd, vpOn, P, wpImg |
| `src/mechanics/camera360.js` | 16 | Камера 360 / гироскоп. | yaw, lp, gReq |
| `src/world/procedural-world.js` | 16 | Бесконечный процедурный мир (этаж 3). Маркер //@TEXTURES:C@ (wm/fm). | dyn, RM |
| `src/mechanics/objects-appliances.js` | 152 | Мелкие предметы, приборы, сохранение состояния (persistence). | tc2, SV, cbMat, CANS, small, washTex, fridgeTex, microTex, GRT, appl, mkShard, kill… |
| `src/mechanics/physics.js` | 94 | Физика твёрдых тел для мелких предметов. | HST, rad, rbInit, regG, wk, wkAbove, iw, effM, app, vAt, kn, insd… |
| `src/mechanics/player-steve.js` | 62 | Тело игрока от первого лица (Steve): модель, анимация, bodyTick. | steveTex, U, mcg, mcb, stv, byd, tp, _t0, _sl, rayBlock, tpBlocked, tpCam… |
| `src/mechanics/adaptive-resolution.js` | 12 | Адаптивное разрешение рендера (120 Гц / высокий dpr). | apr, adapt |
| `src/mechanics/skins.js` | 46 | Скины (только через спавн-ПК), PNG 64x64. | SKL, loadImg, applySkin, skApply, skSave, skinConv, slotXY, fig, drawSkin, skSel, skinTap |
| `src/ui/wallpapers.js` | 42 | Обои на ПК: галерея до 10 штук, хранится между запусками. | icoWall, WPL, wpApply, wpSave, wpMk, drawWps, wpsTap |
| `src/mechanics/walking.js` | 23 | Ходьба. | mv, hitC, IAq, _sq, runOn, walk |
| `src/world/elevator-consts.js` | 8 | Константы этажей (FZ, curFloor). Маркер //@TEXTURES:D@ (секция D: кирпич, бетон, ржавчина, плитка). | FZ |
| `src/audio/elevator-sounds.js` | 17 | ЗВУКИ лифта: скрип, двери, кнопка (elCreak/elDoor/elBtn). | elCreak, elDing, elDoor, elBtn |
| `src/world/elevator.js` | 86 | Лифт: билдер (стена z=0, кабина за стеной), двери, табло этажа, коллизии, тряска камеры; лифт этажа 3. | flrTex, setFlr, ELS, buildElev, hintTxt, setDisp, elCall, ER, elGo, openDoors, shake, elevTick… |
| `src/world/rooms-content.js` | 51 | Материалы и наполнение комнат. Маркер //@TEXTURES:E@ (секция E: паркет, мебель). | FILL2, FILL3 |
| `src/world/layout-factory.js` | 51 | LAYOUT-фабрика: зоны, коридоры, двери (детерминированно по чанкам). | mkLay, zone, zone0, cr, cls, edge, walls, hit, build, LAY2, LAY3 |
| `src/world/floor2-generator.js` | 77 | Процедурный генератор этажа 2: стены, трубы, решётки, лужи, лампы, кирпичи, предметы, спавн лифта. | gen2 |
| `src/mechanics/game-loop.js` | 8 | Главный цикл. | ID, bgDark |
| `src/net/multiplayer.js` | 79 | Мультиплеер: удалённый игрок, синхронизация, скины по сети, индикатор связи. | mpTick, rp, mkTex, rmb, rSkN, rSkin, rSkIn, sendSkin, raTick, lc, ls, label… |
| `src/core/99-ready.js` | 5 | Сигнал window.__gameReady. Всегда последним. |  |

## Имена из textures, которые использует игра (не переименовывать)
AN, BARM, BRICKM, BRK, BRKG, CONC, CYL2, GRATE, PLASTER, PLN, PUDDLE, RUST, TILEF, blot, cabTex, carTex, ceilTex, clockFace, cv2, fabM, fm, grain, keysTex2, lampTex, monTex, mugTex, padTex, plateTex, posterFx, reflTex, toTex, towerTex2, ventTex, vn, wallTex, wm, wood
