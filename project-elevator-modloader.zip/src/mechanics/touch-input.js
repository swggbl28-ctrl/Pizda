//# FILE: mechanics/touch-input.js
//# ЧТО: Управление касаниями: джойстик, осмотр, тап по объектам.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: ray, act, pick, wf, UA, INJ, HOME, setDoc, load, emu, emuLib, emuStart, uq, ytPage, placeWeb, zoom, playVideo, openWeb
// ---------- touch interaction ----------
const ray=new THREE.Raycaster(),pv=new THREE.Vector2();
function act(a,o){initAudio();uiSnd(a);if(o.userData.btn){o.position.y-=.012;setTimeout(()=>o.position.y+=.012,120)}
 if(a==='play'){musicEl.src?musicEl.play().catch(()=>{}):$('af').click()}else if(a==='pause')musicEl.pause();else if(a==='stop'){musicEl.pause();musicEl.currentTime=0}else if(a==='load')$('af').click();
 else if(a==='vm'||a==='vp'){musicVol=Math.min(1,Math.max(0,musicVol+(a==='vp'?.1:-.1)));musicG.gain.value=musicVol}
 else if(a==='power'){power=!power;if(!power)vid.pause();pled.material.emissive.setHex(power?0x00ff00:0);scl.intensity=power?1.5:0}else if(a==='glass')strike();updDisp()}
function pick(x,y){pv.set(x/innerWidth*2-1,-(y/innerHeight)*2+1);ray.setFromCamera(pv,cam);const h=ray.intersectObjects(hit.concat(dyn),false)[0];if(!h)return;if(tp&&tpBlocked(h))return;byd.sw=.35;initAudio();const fn=h.object.userData.fn;if(fn){if(h.point.distanceTo(home)<3.5){fn(h.object,h.point);mp.sync(h.object,h.point)}return}if(h.object===scr)zoomed?screenTap(h.uv):zoom(true);else{act(h.object.userData.act,h.object);mp.sync(h.object)}}
let wf=$('wf'),hist=[],hi=-1,webHost='';
const UA='Mozilla/5.0 (Linux; Android 14; SM-S938B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Mobile Safari/537.36';
const INJ='<script>addEventListener("click",function(e){var a=e.target.closest&&e.target.closest("a[href]");if(!a)return;var h=a.href,r=a.getAttribute("href")||"";if(/^(javascript|mailto|tel):/i.test(h)||r[0]=="#")return;e.preventDefault();parent.postMessage({nav:h},"*")},true);addEventListener("submit",function(e){var f=e.target;e.preventDefault();var p=(f.method||"get").toLowerCase(),d=new URLSearchParams(new FormData(f)).toString(),a=f.action||"";parent.postMessage({nav:p=="get"?a.split("?")[0]+"?"+d:a,post:p=="post"?d:null},"*")},true)<\/script>';
const HOME='<meta name=viewport content="width=device-width,initial-scale=1"><body style="margin:0;background:linear-gradient(160deg,#0b4a6e,#15264a);font-family:sans-serif;color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh"><h1 style="font-weight:300;font-size:42px">🌐 Поиск</h1><form method=get action="https://www.google.com/search" style="width:80%;display:flex"><input type=hidden name=gbv value=1><input name=q autofocus placeholder="Что найти?" style="flex:1;padding:14px;font-size:18px;border:0;border-radius:10px 0 0 10px"><button style="padding:14px 20px;font-size:18px;border:0;background:#3a86ff;color:#fff;border-radius:0 10px 10px 0">Найти</button></form><p style="opacity:.7;margin-top:24px"><a href="https://ru.wikipedia.org" style="color:#9cf">Wikipedia</a> · <a href="https://news.ycombinator.com" style="color:#9cf">Hacker News</a> · <a href="https://www.bing.com" style="color:#9cf">Bing</a> · <a href="https://www.youtube.com" style="color:#9cf">YouTube</a></p>';
function setDoc(h){wf.removeAttribute('src');wf.setAttribute('sandbox','allow-scripts allow-forms');wf.srcdoc=h}
async function load(u,post,nh){u=(u||'').trim();if(!u){setDoc(INJ+HOME);urlI.value='';webHost='Старт';return}
 if(!/^https?:\/\//i.test(u))u=/\S+\.\S+/.test(u)&&!/\s/.test(u)?'https://'+u:'https://www.google.com/search?gbv=1&q='+encodeURIComponent(u);
 const m=u.match(/duckduckgo\.com\/l\/\?.*uddg=([^&]+)/);if(m)u=decodeURIComponent(m[1]);
 const g2=u.match(/google\.[a-z.]+\/url\?(?:.*&)?(?:q|url)=([^&]+)/);if(g2)u=decodeURIComponent(g2[1]);
 if(/^https?:\/\/(www\.)?google\.[a-z.]+\/?$/i.test(u)){load('');return}
 if(/\.(mp4|webm|mkv|m3u8|ogv)(\?|$)/i.test(u)){playVideo(u);return}
 const y=u.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|shorts\/|embed\/))([\w-]{11})/);
 urlI.value=u;try{webHost=new URL(u).hostname}catch(e){}
 if(!nh){hist=hist.slice(0,hi+1);hist.push([u,post]);hi=hist.length-1}
 if(y){wf.removeAttribute('sandbox');wf.removeAttribute('srcdoc');wf.src='https://www.youtube.com/embed/'+y[1]+'?autoplay=1&playsinline=1';return}
 if(/^https?:\/\/(?:www\.|m\.)?youtube\.com\/?(?:results.*|\?.*)?$/i.test(u)){const q=(u.match(/search_query=([^&]+)/)||[])[1];ytPage(decodeURIComponent((q||'').replace(/\+/g,' ')));return}
setDoc('<body style="background:#111;color:#8fb4ff;font:20px sans-serif;display:flex;align-items:center;justify-content:center;height:100vh">Загрузка… '+webHost);
 try{const r=await fetch(u,{method:post?'POST':'GET',headers:Object.assign({'User-Agent':UA,'Accept-Language':'ru,en;q=0.8',Cookie:'CONSENT=YES+1; SOCS=CAI'},post?{'Content-Type':'application/x-www-form-urlencoded'}:{}),body:post||undefined});
  const ct=r.headers.get('content-type')||'';if(/^image\//.test(ct)){setDoc('<body style="margin:0;background:#000"><img src="'+u+'" style="max-width:100%">');return}
  let t=await r.text();t=t.replace(/<meta[^>]+http-equiv=["']?content-security-policy[^>]*>/ig,'');const b='<base href="'+(r.url||u)+'">'+INJ;
  setDoc(/<head[^>]*>/i.test(t)?t.replace(/<head[^>]*>/i,x=>x+b):b+t)}
 catch(e){setDoc(INJ+'<body style="background:#111;color:#f88;font:18px sans-serif;padding:20px">Не удалось загрузить: '+esc(String(e&&e.message||e))+'<br><br>Сайты открываются только в APK (в браузере их блокирует CORS).')}}
let emu=null,emuCv=null,emuMsg='Windows',v86L=null;const V86U='https://copy.sh/v86/';
async function emuLib(){if(v86L)return v86L;emuMsg='Загрузка эмулятора…';const t=await(await fetch(V86U+'build/libv86.js')).text(),sc=document.createElement('script');sc.src=URL.createObjectURL(new Blob([t],{type:'text/javascript'}));await new Promise((ok,no)=>{sc.onload=ok;sc.onerror=no;document.head.appendChild(sc)});
 const w=await(await fetch(V86U+'build/v86.wasm')).arrayBuffer(),bios=await(await fetch(V86U+'bios/seabios.bin')).arrayBuffer(),vga=await(await fetch(V86U+'bios/vgabios.bin')).arrayBuffer();return v86L={wasm:URL.createObjectURL(new Blob([w],{type:'application/wasm'})),bios,vga}}
async function emuStart(f){mode='emu';power=true;zoom(true);emuMsg='Загрузка…';try{const L=await emuLib();if(emu){try{emu.destroy()}catch(e){}}
 const host=document.createElement('div');host.style.cssText='position:fixed;left:-9999px;top:0';host.innerHTML='<div style="white-space:pre;font:14px monospace;line-height:14px"></div><canvas></canvas>';document.body.appendChild(host);emuCv=host.querySelector('canvas');
 const cfg={wasm_path:L.wasm,memory_size:128*1024*1024,vga_memory_size:16*1024*1024,screen_container:host,bios:{buffer:L.bios},vga_bios:{buffer:L.vga},autostart:true,network_relay_url:'wss://relay.widgetry.org/',net_device:{relay_url:'wss://relay.widgetry.org/',type:'ne2k'}};
 if(f){const n=f.name.toLowerCase();if(/\.iso$/.test(n))cfg.cdrom={buffer:f};else if(f.size<3e6)cfg.fda={buffer:f};else cfg.hda={buffer:f}}else{emuMsg='Загрузка KolibriOS…';cfg.fda={buffer:await(await fetch(V86U+'images/kolibri.img')).arrayBuffer()}}
 emuMsg='Запуск… (текстовый режим не виден)';emu=new(window.V86||window.V86Starter)(cfg)}catch(e){emu=null;emuMsg='Ошибка: '+String(e&&e.message||e).slice(0,50)}}
$('emf').onchange=e=>{const f=e.target.files[0];if(f)emuStart(f);e.target.value=''};$('kol').onclick=()=>emuStart();
$('emx').onclick=()=>{try{emu&&emu.destroy()}catch(e){}emu=null;emuCv=null;mode='desk'};
$('kb').onclick=()=>{const p=$('kp');p.style.display=p.style.display==='flex'?'none':'flex';if(p.style.display==='flex')$('kbi').focus()};
$('kbi').oninput=e=>{if(emu&&emu.keyboard_adapter)for(const c of e.target.value)emu.keyboard_adapter.simulate_char(c);e.target.value=''};
$('kp').querySelectorAll('[data-k]').forEach(b=>b.onclick=()=>emu&&emu.keyboard_send_scancodes(b.dataset.k.split(',').map(Number)));
$('rc').onclick=()=>{if(!emu)return;emu.bus.send('mouse-click',[false,false,true]);setTimeout(()=>emu.bus.send('mouse-click',[false,false,false]),70)};
const uq=t=>{try{return JSON.parse('"'+t+'"')}catch(e){return t}},esc=t=>t.replace(/&/g,'&amp;').replace(/</g,'&lt;');
async function ytPage(q){const hd=`<meta name=viewport content="width=device-width,initial-scale=1"><body style="margin:0;background:#0f0f0f;color:#fff;font-family:sans-serif"><form method=get action="https://www.youtube.com/results" style="display:flex;padding:8px;position:sticky;top:0;background:#212121"><input name=search_query value="${esc(q).replace(/"/g,'&quot;')}" placeholder="Поиск на YouTube" style="flex:1;min-width:0;padding:10px;font-size:16px;border:0;border-radius:20px 0 0 20px;background:#121212;color:#fff"><button style="padding:10px 16px;border:0;border-radius:0 20px 20px 0;background:#3a3a3a;color:#fff">🔍</button></form>`;
 if(!q){setDoc(INJ+hd+'<p style="padding:16px;opacity:.7">Введите запрос</p>');return}
 setDoc(INJ+hd+'<p style="padding:16px">Загрузка…</p>');
 try{const r=await fetch('https://www.youtube.com/results?search_query='+encodeURIComponent(q),{headers:{'User-Agent':UA,'Accept-Language':'ru,en;q=0.8',Cookie:'CONSENT=YES+1; SOCS=CAI'}}),t=await r.text(),
  it=t.split('"videoRenderer":{"videoId":"').slice(1,25).map(c=>{const m=c.match(/"title":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"/),o=c.match(/"ownerText":\{"runs":\[\{"text":"((?:[^"\\]|\\.)*)"/);return m&&[c.slice(0,11),m[1],o?o[1]:'']}).filter(Boolean),
  h=it.map(([id,a,o])=>`<a href="https://www.youtube.com/watch?v=${id}" style="display:block;text-decoration:none;color:#fff;margin:10px"><img src="https://i.ytimg.com/vi/${id}/mqdefault.jpg" style="width:100%;border-radius:10px"><div style="font-weight:600;margin-top:4px">${esc(uq(a))}</div><div style="opacity:.6;font-size:13px">${esc(uq(o))}</div></a>`).join('');
  setDoc(INJ+hd+(h||'<p style="padding:16px">Ничего не найдено</p>'))}catch(e){setDoc(INJ+hd+'<p style="padding:16px">Ошибка загрузки (нужен APK с сетью)</p>')}}
addEventListener('message',e=>{if(e.source===wf.contentWindow&&e.data&&e.data.nav)load(e.data.nav,e.data.post)});
function placeWeb(){const w=$('web');if(!(mode==='web'&&power&&zoomed&&zk>.99)){w.style.display='none';return}
 const a=new THREE.Vector3(-.46,.26,-1.368).project(cam),b=new THREE.Vector3(.46,-.26,-1.368).project(cam),x0=(a.x+1)/2*innerWidth,y0=(1-a.y)/2*innerHeight,x1=(b.x+1)/2*innerWidth,y1=(1-b.y)/2*innerHeight;
 Object.assign(w.style,{display:'block',left:x0+'px',top:y0+'px',width:(x1-x0)+'px',height:(y1-y0)*536/576+'px'})}
function zoom(v){zoomed=v;$('zm').textContent=v?'⤺':'🖥'}
function playVideo(u){mode='video';power=true;vid.querySelectorAll('track').forEach(t=>t.remove());vid.src=u;vid.play().catch(()=>{});zoom(true)}
function openWeb(u){mode='web';power=true;zoom(true);hist=[];hi=-1;load(u)}
