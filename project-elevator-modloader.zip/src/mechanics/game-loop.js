//# FILE: mechanics/game-loop.js
//# ЧТО: Главный цикл.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: ID, bgDark
// ---------- loop ----------
const ID=new THREE.Quaternion(),fq=new THREE.Quaternion(),home=new THREE.Vector3(0,1.6,.9),tgt=new THREE.Vector3();
const bgDark=new THREE.Color(0x04060c),bgFl=new THREE.Color(0xe4ecff),clk=new THREE.Clock();let fk=1,fr=0;
