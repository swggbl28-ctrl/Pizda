//# FILE: mechanics/objects-appliances.js
//# ЧТО: Мелкие предметы, приборы, сохранение состояния (persistence).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: tc2, SV, cbMat, CANS, small, washTex, fridgeTex, microTex, GRT, appl, mkShard, kill, shatter, saveCh, applySave, gen, sfxCab, steamTex, hissInit, steamU, gen0
// ---------- small objects / appliances / persistence ----------
function tc2(w,h,f){const[c,g]=cv2(w,h);f(g,w,h);return toTex(c)}
const SV=new Map,
LG=(pts,hy)=>{const g=new THREE.LatheGeometry(pts.map(p=>new THREE.Vector2(p[0],p[1])),28),uv=g.attributes.uv,p=g.attributes.position;for(let i=0;i<uv.count;i++)uv.setY(i,(p.getY(i)+hy)/(2*hy));return g},
CANG=LG([[0,-.06],[.027,-.06],[.031,-.057],[.033,-.054],[.033,.054],[.031,.057],[.027,.06],[.026,.058],[0,.058]],.06),
TING=LG([[0,-.05],[.041,-.05],[.044,-.047],[.0455,-.044],[.0435,-.042],[.0435,-.036],[.045,-.034],[.0435,-.032],[.0435,.032],[.045,.034],[.0435,.036],[.0435,.042],[.0455,.044],[.044,.047],[.041,.05],[.04,.048],[0,.048]],.05),
BOTG=LG([[0,-.085],[.024,-.085],[.03,-.08],[.031,-.07],[.031,0],[.03,.02],[.026,.04],[.017,.058],[.0115,.07],[.0115,.08],[.0135,.083],[.0115,.085],[0,.085]],.085),
LABG=new THREE.CylinderGeometry(.0314,.0314,.055,24,1,true),LIQG=new THREE.CylinderGeometry(.0275,.0265,.1,20),CAPG=new THREE.CylinderGeometry(.0135,.0135,.012,16),SHG=new THREE.CylinderGeometry(1,1,.15,3),
CAPM=new THREE.MeshStandardMaterial({color:0xc9a227,metalness:.9,roughness:.3}),CHR=new THREE.MeshStandardMaterial({color:0xcfcfcf,metalness:1,roughness:.2}),
SHM=new THREE.MeshPhysicalMaterial({color:0xcfe8dd,roughness:.05,metalness:.1,transparent:true,opacity:.6,envMapIntensity:2,side:THREE.DoubleSide});
function cbMat(){const t=tc2(256,256,(g,w,h)=>{g.fillStyle='#9a7648';g.fillRect(0,0,w,h);for(let y=0;y<h;y+=3){g.fillStyle=`rgba(${y%6?'60,40,15':'200,160,100'},.12)`;g.fillRect(0,y,w,1)}blot(g,w,h,14,20,80,'60,40,15',.3);
 g.fillStyle='rgba(215,190,130,.85)';g.fillRect(0,108,w,40);g.fillStyle='rgba(255,255,255,.25)';g.fillRect(0,112,w,5);g.fillStyle='rgba(30,20,10,.8)';g.font='bold 22px sans-serif';g.fillText('FRAGILE ⇧',16,208);g.font='12px monospace';g.fillText('№ 0457 / KG 4.2',150,60);grain(g,w,h,4000,.2)});t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(5,5);return new THREE.MeshStandardMaterial({map:t,roughness:.85})}
const CANS=[['#c8102e','#fff','COLA'],['#0a5bb5','#fff','FIZZ'],['#2e8b3a','#fff','LIME'],['#f2a900','#222','ORANGE'],['#1a1a1e','#ff3b30','ENERGY'],['#7b2c8c','#fff','GRAPE']],
CANM=CANS.map(([bg,fg,nm])=>new THREE.MeshStandardMaterial({roughness:.3,metalness:.7,side:THREE.DoubleSide,map:tc2(512,256,(g,w,h)=>{let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#d8dadc');q.addColorStop(1,'#8d9094');g.fillStyle=q;g.fillRect(0,0,w,h);g.fillStyle=bg;g.fillRect(0,28,w,200);
 q=g.createLinearGradient(0,28,0,228);q.addColorStop(0,'rgba(255,255,255,.28)');q.addColorStop(.5,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(0,0,0,.35)');g.fillStyle=q;g.fillRect(0,28,w,200);
 g.fillStyle=fg;g.globalAlpha=.9;for(const x of[0,256]){g.beginPath();g.moveTo(x,170);g.bezierCurveTo(x+80,120,x+170,230,x+256,150);g.lineTo(x+256,172);g.bezierCurveTo(x+170,250,x+80,140,x,196);g.fill()}g.globalAlpha=1;
 g.font='bold 62px Impact,sans-serif';g.textAlign='center';for(const x of[128,384]){g.fillStyle='rgba(0,0,0,.4)';g.fillText(nm,x+3,103);g.fillStyle=fg;g.fillText(nm,x,100)}
 g.font='13px sans-serif';g.fillText('330 мл',128,128);g.fillText('SUGAR FREE 0%',384,128);g.fillStyle='#fff';g.fillRect(300,176,70,40);g.fillStyle='#000';for(let x=304;x<366;x+=2+Math.random()*3)g.fillRect(x,180,1+Math.random()*2,30);
 g.strokeStyle='rgba(0,0,0,.3)';for(let y=2;y<28;y+=5){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke();g.beginPath();g.moveTo(0,h-y);g.lineTo(w,h-y);g.stroke()}
 for(const x of[60,316]){q=g.createLinearGradient(x,0,x+30,0);q.addColorStop(0,'rgba(255,255,255,0)');q.addColorStop(.5,'rgba(255,255,255,.3)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(x,0,30,h)}
 blot(g,w,h,10,10,50,'30,25,15',.35);grain(g,w,h,2500,.25)})})),
TINS=[['#d9b84a','#7a1d1d','ТУШЁНКА'],['#6aa84f','#fff','ГОРОШЕК'],['#e0a526','#2b3d1a','КУКУРУЗА'],['#2f5d8a','#fff','ШПРОТЫ'],['#c0392b','#fff','ТОМАТЫ'],['#f4efe0','#1b4f9c','СГУЩЁНКА']],
TINM=TINS.map(([bg,fg,nm])=>new THREE.MeshStandardMaterial({roughness:.4,metalness:.6,side:THREE.DoubleSide,map:tc2(512,256,(g,w,h)=>{let q=g.createLinearGradient(0,0,0,h);q.addColorStop(0,'#c9ccd0');q.addColorStop(1,'#7e8286');g.fillStyle=q;g.fillRect(0,0,w,h);g.fillStyle=bg;g.fillRect(0,40,w,176);
 q=g.createLinearGradient(0,40,0,216);q.addColorStop(0,'rgba(255,255,255,.2)');q.addColorStop(1,'rgba(0,0,0,.3)');g.fillStyle=q;g.fillRect(0,40,w,176);
 for(const x of[128,384]){g.fillStyle='rgba(255,255,255,.9)';g.beginPath();g.ellipse(x,120,52,38,0,0,6.3);g.fill();g.fillStyle=fg;g.globalAlpha=.7;for(let i=0;i<9;i++){g.beginPath();g.arc(x+rnd(-32,32),120+rnd(-20,20),rnd(6,13),0,6.3);g.fill()}g.globalAlpha=1;
  g.font='bold 26px serif';g.textAlign='center';g.fillStyle=fg;g.fillText(nm,x,70);g.fillStyle='#222';g.font='11px sans-serif';g.fillText('ГОСТ 5284-84  •  340 г',x,196)}
 g.fillStyle=fg;g.fillRect(0,40,w,5);g.fillRect(0,211,w,5);g.strokeStyle='rgba(0,0,0,.3)';for(let y=3;y<40;y+=4){g.beginPath();g.moveTo(0,y);g.lineTo(w,y);g.stroke();g.beginPath();g.moveTo(0,h-y);g.lineTo(w,h-y);g.stroke()}
 blot(g,w,h,12,10,50,'60,40,15',.35);grain(g,w,h,3000,.25)})})),
BOTM=[[0x2f6b35,0x5a3a10,'#d9c08a','ПИЛЗНЕР'],[0x4a2a10,0x3a1c08,'#e8d9b0','СТАРЫЙ ДУБ'],[0xbfe0ee,0x9fd0e8,'#cfe8f5','РОДНИК']].map(([gc,lc,lb,nm])=>({g:new THREE.MeshPhysicalMaterial({color:gc,roughness:.04,metalness:0,transparent:true,opacity:.5,envMapIntensity:2,clearcoat:1,side:THREE.DoubleSide,depthWrite:false}),q:new THREE.MeshStandardMaterial({color:lc,roughness:.2,transparent:true,opacity:.85}),
 l:new THREE.MeshStandardMaterial({roughness:.7,side:THREE.DoubleSide,map:tc2(256,96,(g,w,h)=>{g.fillStyle=lb;g.fillRect(0,0,w,h);g.strokeStyle='#5a3a10';g.lineWidth=3;g.strokeRect(3,3,w-6,h-6);g.fillStyle='#5a3a10';g.fillRect(0,h-16,w,8);g.font='bold 20px serif';g.textAlign='center';g.fillText(nm,64,44);g.fillText(nm,192,44);g.beginPath();g.arc(64,70,9,0,6.3);g.arc(192,70,9,0,6.3);g.fill();grain(g,w,h,800,.2)})})}));
function small(t,r){let o,H,hh;if(t==0){o=new THREE.Mesh(rbg(.2,.16,.18,.01),CB);H=[.1,.08,.09];hh=.08}
 else if(t==1){o=new THREE.Mesh(CANG,CANM[r()*6|0]);H=[.033,.06,.033];hh=.06;o.rotation.y=r()*6.28}
 else if(t==2){o=new THREE.Mesh(TING,TINM[r()*6|0]);H=[.045,.05,.045];hh=.05;o.rotation.y=r()*6.28}
 else{const b=BOTM[r()*3|0];o=new THREE.Mesh(BOTG,b.g);const l=new THREE.Mesh(LABG,b.l),q=new THREE.Mesh(LIQG,b.q),c=new THREE.Mesh(CAPG,CAPM);l.position.y=-.012;q.position.y=-.02;c.position.y=.082;o.add(q,l,c);H=[.031,.085,.031];hh=.085;o.rotation.y=r()*6.28}
 return o.name=t?'c':'b',[o,H,hh]}
function washTex(col,dry){const hex='#'+col.toString(16).padStart(6,'0');return tc2(512,724,(g,w,h)=>{g.fillStyle=hex;g.fillRect(0,0,w,h);let q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'rgba(0,0,0,.12)');q.addColorStop(.15,'rgba(255,255,255,.08)');q.addColorStop(1,'rgba(0,0,0,.14)');g.fillStyle=q;g.fillRect(0,0,w,h);
 g.fillStyle='rgba(0,0,0,.18)';g.fillRect(0,128,w,3);g.fillStyle='#2a2d33';g.beginPath();g.roundRect(30,22,452,86,10);g.fill();g.fillStyle='#0b1a0b';g.fillRect(190,38,90,52);g.fillStyle='#4f4';g.font='bold 34px monospace';g.textAlign='center';g.fillText(dry?'0:45':'1:20',235,76);
 q=g.createRadialGradient(100,62,4,100,65,34);q.addColorStop(0,'#eee');q.addColorStop(1,'#777');g.fillStyle=q;g.beginPath();g.arc(100,65,32,0,6.3);g.fill();g.strokeStyle='#222';g.lineWidth=3;g.beginPath();g.moveTo(100,65);g.lineTo(112,38);g.stroke();
 for(let i=0;i<12;i++){const a=i/12*6.28;g.fillStyle='#bbb';g.fillRect(100+Math.cos(a)*44-1,65+Math.sin(a)*44-1,3,3)}
 for(let i=0;i<4;i++){g.fillStyle=i==1?'#f93':'#555';g.beginPath();g.arc(320+i*40,56,10,0,6.3);g.fill()}g.fillStyle='#ccc';g.font='12px sans-serif';g.fillText('ВЯТКА-АВТОМАТ',395,98);
 g.fillStyle='rgba(0,0,0,.22)';g.beginPath();g.roundRect(30,150,120,36,5);g.fill();g.fillStyle='rgba(255,255,255,.2)';g.fillRect(36,154,108,3);
 q=g.createRadialGradient(256,430,120,256,430,190);q.addColorStop(0,'rgba(0,0,0,.35)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(40,220,432,420);
 q=g.createRadialGradient(240,410,5,256,430,150);q.addColorStop(0,dry?'#4a5a6e':'#18222c');q.addColorStop(1,'#05080b');g.fillStyle=q;g.beginPath();g.arc(256,430,150,0,6.3);g.fill();
 g.fillStyle='rgba(120,140,160,.35)';for(let r=20;r<130;r+=22)for(let a=0;a<6.28;a+=.42-r/600){g.beginPath();g.arc(256+Math.cos(a+r)*r,430+Math.sin(a+r)*r,2.5,0,6.3);g.fill()}
 if(dry)for(let i=0;i<30;i++){g.fillStyle=`hsla(${Math.random()*360},50%,45%,.6)`;g.beginPath();g.arc(256+rnd(-90,90),470+rnd(-30,60),rnd(10,26),0,6.3);g.fill()}
 g.fillStyle='rgba(255,255,255,.18)';g.beginPath();g.ellipse(210,370,70,30,-.6,0,6.3);g.fill();blot(g,w,h,14,20,90,'70,55,25',.28);blot(g,w,h,8,15,60,'150,80,30',.22);grain(g,w,h,9000,.12)})}
function fridgeTex(col){const hex='#'+col.toString(16).padStart(6,'0');return tc2(512,1024,(g,w,h)=>{g.fillStyle=hex;g.fillRect(0,0,w,h);let q=g.createLinearGradient(0,0,w,0);q.addColorStop(0,'rgba(0,0,0,.12)');q.addColorStop(.2,'rgba(255,255,255,.1)');q.addColorStop(1,'rgba(0,0,0,.14)');g.fillStyle=q;g.fillRect(0,0,w,h);
 g.fillStyle='rgba(0,0,0,.55)';g.fillRect(0,326,w,8);g.fillStyle='rgba(255,255,255,.3)';g.fillRect(0,334,w,2);
 for(const[y0,y1]of[[60,250],[380,700]]){q=g.createLinearGradient(430,0,470,0);q.addColorStop(0,'#555');q.addColorStop(.5,'#ddd');q.addColorStop(1,'#666');g.fillStyle=q;g.fillRect(430,y0,34,y1-y0)}
 g.fillStyle='#b33';g.fillRect(60,50,70,22);g.fillStyle='#fff';g.font='bold 14px sans-serif';g.fillText('ЗИЛ',72,66);
 for(let i=0;i<7;i++){g.fillStyle=`hsl(${rnd(0,360)|0},60%,55%)`;g.fillRect(rnd(60,330),rnd(400,900),rnd(24,50),rnd(24,40))}
 blot(g,w,h,22,20,100,'70,55,25',.28);blot(g,w,h,8,15,60,'150,80,30',.2);grain(g,w,h,12000,.12)})}
function microTex(){return tc2(512,384,(g,w,h)=>{g.fillStyle='#1d1f24';g.fillRect(0,0,w,h);g.strokeStyle='#888';g.lineWidth=6;g.strokeRect(20,26,330,332);let q=g.createLinearGradient(24,30,344,350);q.addColorStop(0,'#2b323a');q.addColorStop(1,'#07090c');g.fillStyle=q;g.fillRect(24,30,322,324);
 g.strokeStyle='rgba(120,130,140,.35)';g.lineWidth=1;for(let x=24;x<346;x+=8){g.beginPath();g.moveTo(x,30);g.lineTo(x,354);g.stroke()}for(let y=30;y<354;y+=8){g.beginPath();g.moveTo(24,y);g.lineTo(346,y);g.stroke()}
 g.fillStyle='rgba(200,210,220,.35)';g.beginPath();g.ellipse(185,330,120,12,0,0,6.3);g.fill();g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.moveTo(30,36);g.lineTo(150,36);g.lineTo(30,200);g.fill();
 q=g.createLinearGradient(360,0,500,0);q.addColorStop(0,'#aaa');q.addColorStop(.5,'#ddd');q.addColorStop(1,'#999');g.fillStyle=q;g.fillRect(360,20,132,344);g.fillStyle='#0b1a0b';g.fillRect(372,34,108,44);g.fillStyle='#4f4';g.font='bold 30px monospace';g.textAlign='center';g.fillText('12:00',426,68);
 for(let i=0;i<9;i++){g.fillStyle='#444';g.beginPath();g.roundRect(374+(i%3)*37,92+(i/3|0)*34,32,26,4);g.fill();g.fillStyle='#ddd';g.font='13px sans-serif';g.fillText(i+1,390+(i%3)*37,110+(i/3|0)*34)}
 q=g.createRadialGradient(426,270,3,426,272,34);q.addColorStop(0,'#eee');q.addColorStop(1,'#555');g.fillStyle=q;g.beginPath();g.arc(426,275,32,0,6.3);g.fill();g.fillStyle='#222';g.fillRect(424,246,4,22);g.fillStyle='#222';g.font='bold 14px sans-serif';g.fillText('MICRO 800W',426,340);
 blot(g,w,h,8,15,60,'80,70,40',.25);grain(g,w,h,5000,.12)})}
const GRT=tc2(256,256,(g,w,h)=>{g.fillStyle='#ddd';g.fillRect(0,0,w,h);blot(g,w,h,40,20,90,'90,80,50',.35);grain(g,w,h,5000,.2)});
function appl(ch,G,r,cx,cz,ov){const k=r()*3|0,W=[.6,.65,.6][k],Hh=[.85,1.75,.85][k],D=.62,x=cx+(r()-.5)*5,z=cz+(r()-.5)*5,ro=r()*4|0,sw=ro&1,hw=(sw?D:W)/2,hd=(sw?W:D)/2;if(ov(x,z,Math.max(hw,hd)+.25))return;
 const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=ro*Math.PI/2;G.add(g);const col=[0xe8e6df,0xd8d2c0,0xbfc4c6][r()*3|0],sd=new THREE.MeshStandardMaterial({color:col,roughness:.35,metalness:.25,map:GRT}),fr=new THREE.MeshStandardMaterial({map:k==1?fridgeTex(col):washTex(col,k==2),roughness:.3,metalness:.2});
 const b=new THREE.Mesh(new THREE.BoxGeometry(W,Hh,D),[sd,sd,sd,sd,fr,sd]);b.position.y=Hh/2;g.add(b);
 if(k!=1){const ring=new THREE.Mesh(new THREE.TorusGeometry(.18,.02,16,40),CHR);ring.position.set(0,.345,D/2+.004);g.add(ring);const gl=new THREE.Mesh(new THREE.CircleGeometry(.165,32),new THREE.MeshStandardMaterial({color:0x223344,roughness:.05,metalness:.3,transparent:true,opacity:.5}));gl.position.set(0,.345,D/2+.006);g.add(gl);
  [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([a,c])=>{const f=new THREE.Mesh(CYL,dark);f.scale.set(.025,.02,.025);f.position.set(a*(W/2-.04),.01,c*(D/2-.04));g.add(f)});
  if(k==0&&r()<.6){const ms=new THREE.MeshStandardMaterial({color:0x1d1f24,roughness:.4,metalness:.4}),mw=new THREE.Mesh(new THREE.BoxGeometry(.46,.28,.35),[ms,ms,ms,ms,new THREE.MeshStandardMaterial({map:microTex(),roughness:.25,metalness:.3}),ms]);mw.position.set(0,Hh+.14,.105);g.add(mw);
   const sn=Math.round(Math.sin(ro*Math.PI/2)),cs=Math.round(Math.cos(ro*Math.PI/2)),mx=x+.105*sn,mz=z+.105*cs,a=(sw?.35:.46)/2,c=(sw?.46:.35)/2;ch.st.push([mx-a,mx+a,Hh,Hh+.28,mz-c,mz+c])}}
 else{[[.9,.5],[1.45,.3]].forEach(([y,l])=>{const h=new THREE.Mesh(new THREE.BoxGeometry(.02,l,.03),CHR);h.position.set(W/2-.075,y+.1,D/2+.02);g.add(h)})}
 const c=[x-hw,x+hw,z-hd,z+hd,Hh];ch.cols.push(c);ch.sh.push(c);ch.st.push([c[0],c[1],0,Hh,c[2],c[3]])}
function mkShard(ch,x,y,z,ry,sx,sz,vel){const o=new THREE.Mesh(SHG,SHM);o.scale.set(sx,.02,sz);o.position.set(x,y,z);o.rotation.y=ry;ch.g.add(o);const m=Math.max(sx,sz)*.7,u=o.userData={ch,sh:1,h:[m,.003,m],wp:new THREE.Vector3(x,y,z),sx,sz};ch.sd.push(o);if(vel){u.aw=1;u.v=vel;u.w=new THREE.Vector3(rnd(-12,12),0,rnd(-12,12));ch.ph.add(o)}return o}
function kill(ch,o){o.parent&&o.parent.remove(o);const k=ch.it.indexOf(o);if(k>=0)ch.it.splice(k,1);dyn=dyn.filter(x=>x!==o)}
function shatter(c,o){const u=o.userData,p=u.wp,v=u.v,n=16+(Math.random()*8|0);for(let i=0;i<n;i++){const a=rnd(0,6.28),sp=rnd(.3,2);mkShard(c,p.x+rnd(-.02,.02),p.y+rnd(-.06,.06),p.z+rnd(-.02,.02),rnd(0,6.28),rnd(.008,.026),rnd(.008,.026),new THREE.Vector3(Math.cos(a)*sp+v.x*.3,rnd(.2,2.2),Math.sin(a)*sp+v.z*.3))}wkAbove(u);c.ph.delete(o);kill(c,o);c.br.push(u.id);crash()}
function saveCh(c){const it=[];c.it.forEach(o=>{const u=o.userData;if(u.moved)it.push([u.id,u.wp.x,u.wp.y,u.wp.z,u.q.x,u.q.y,u.q.z,u.q.w])});SV.set(c.i+','+c.j,{it,br:c.br,sd:c.sd.map(o=>[o.position.x,o.position.y,o.position.z,o.rotation.y,o.userData.sx,o.userData.sz])})}
function applySave(ch){const sv=SV.get(ch.i+','+ch.j);if(!sv)return;ch.br=sv.br.slice();sv.br.forEach(id=>{const o=ch.it.find(q=>q.userData.id==id);if(o)kill(ch,o)});
 sv.it.forEach(([id,x,y,z,a,b,c2,d2])=>{const o=ch.it.find(q=>q.userData.id==id);if(!o)return;const u=o.userData;o.parent&&o.parent.remove(o);ch.g.add(o);o.position.set(x,y,z);if(b===undefined)o.rotation.set(0,a,0);else o.quaternion.set(a,b,c2,d2);u.q.copy(o.quaternion);u.wp.set(x,y,z);u.moved=1;if(u.c)u.c.off=true});
 sv.sd.forEach(a=>mkShard(ch,a[0],a[1],a[2],a[3],a[4],a[5]))}
function gen(i,j){if(j>=400){gen2(i,j);return}gen0(i,j);const c=CH.get(i+','+j);if(c.o)HP.forEach(o=>{const H=o.userData.H0;c.g.add(o);o.userData={fn:kn,ch:c,H0:H};regG(c,o,H)});applySave(c)}

function sfxCab(k){if(!AC)return;try{if(k==0)aBn({type:'bandpass',f:420,q:3,a:.02,d:.35,g:.18,send:.2});else if(k==1)aBn({type:'lowpass',f:260,q:1,a:.03,d:.3,g:.25,send:.2});else{aTn({f:2200,f2:900,d:.025,g:.12});aBn({type:'highpass',f:3000,a:.001,d:.03,g:.15})}}catch(e){}}
function steamTex(){if(steamTex.t)return steamTex.t;const[c,g]=cv2(128,128),q=g.createRadialGradient(64,64,0,64,64,64);q.addColorStop(0,'rgba(255,255,255,.85)');q.addColorStop(.35,'rgba(240,244,248,.45)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,128,128);for(let i=0;i<14;i++){const x=40+Math.random()*48,y=40+Math.random()*48,r=10+Math.random()*18,w=g.createRadialGradient(x,y,0,x,y,r);w.addColorStop(0,'rgba(255,255,255,.25)');w.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=w;g.fillRect(0,0,128,128)}return steamTex.t=toTex(c)}
function hissInit(H){const b=AC.createBuffer(1,AC.sampleRate*2,AC.sampleRate),d=b.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=Math.random()*2-1;const s=AC.createBufferSource();s.buffer=b;s.loop=true;const f=AC.createBiquadFilter();f.type='bandpass';f.frequency.value=5200;f.Q.value=.5;const g=AC.createGain();g.gain.value=0;s.connect(f);f.connect(g);g.connect(AC.destination);s.start();H.g=g;A.push({u:dt=>{H.g.gain.value+=(H.lv*.12-H.g.gain.value)*Math.min(1,dt*6);H.lv=0}})}
function steamU(v,dt){const H=steamU.h||(steamU.h={g:null,lv:0}),G=v.ch.g,d=Math.hypot(home.x-v.x,home.z-v.z),op=v.leak&&(Math.round(v.t/Math.PI)&1);v.s+=((op?1:0)-v.s)*Math.min(1,dt*2);
 if(v.s>.02&&d<16){if(!v.ps){const m0=steamTex();v.ps=[];for(let n=0;n<40;n++){const q=new THREE.Sprite(new THREE.SpriteMaterial({map:m0,color:0xdfe4e8,transparent:true,depthWrite:false,opacity:0}));q.visible=false;G.add(q);v.ps.push({s:q,l:9,m:1,vx:0,vy:0,vz:0,rv:0})}}
  v.acc+=dt*(d<9?40:15)*v.s;while(v.acc>=1){v.acc--;const p=v.ps.find(q=>q.l>=q.m);if(!p)break;p.l=0;p.m=1.4+Math.random()*1.3;p.s.position.set(v.x+(Math.random()-.5)*.04,v.y+(Math.random()-.5)*.04,v.z+(Math.random()-.5)*.04);p.vx=v.ex*(.5+Math.random()*.7)+(Math.random()-.5)*.4;p.vy=.1+Math.random()*.5;p.vz=v.zs*(.5+Math.random()*.9);p.rv=(Math.random()-.5)*1.2;p.s.visible=true}}
 if(v.ps)for(const p of v.ps){if(p.l>=p.m)continue;p.l+=dt;const k=p.l/p.m,q=p.s;if(k>=1){q.visible=false;q.material.opacity=0;continue}const dr=1-Math.min(1,dt*1.1);p.vx*=dr;p.vz*=dr;p.vy=p.vy*dr+dt*.5;q.position.x+=p.vx*dt;q.position.y=Math.min(2.75,q.position.y+p.vy*dt);q.position.z+=p.vz*dt;q.scale.setScalar(.12+k);q.material.rotation+=p.rv*dt;q.material.opacity=.5*Math.pow(1-k,1.4)*Math.min(1,p.l*6)}
 if(v.s>.02&&AC){if(!H.g)hissInit(H);H.lv=Math.max(H.lv,v.s*Math.max(0,1-d/9))}}
function gen0(i,j){const ch={i,j,g:new THREE.Group(),cols:[],ph:new Set,lit:true,n:0,sd:[],br:[],wl:[],st:[],it:[],sh:[],lt:[],o:i==0&&j==0},cx=i*CS,cz=j*CS,r=mk(hs(i,j,9)),G=ch.g;CH.set(i+','+j,ch);S.add(G);
 const B=(w,h,d,x,y,z,m,p=G,rr)=>{const o=box(w,h,d,x,y,z,m,p,rr);o.castShadow=o.receiveShadow=false;return o},
 hb=(w,h,d,x,y,z,p,fn)=>{const o=new THREE.Mesh(gb(w,h,d),HM);o.position.set(x,y,z);o.userData={fn,ch,sid:ch.hc=(ch.hc|0)+1};p.add(o);dyn.push(o);return o},
 col=(x0,x1,z0,z1,h=2.8)=>{const c=[x0,x1,z0,z1,h];ch.cols.push(c);return c},
 wake=(o,vx,vy,vz)=>{wk(o);o.userData.v.set(vx,vy,vz)},
knock=(o,pt)=>kn(o,pt),_=(ch.wk=wake),
reg=(o,p,H)=>{const u=o.userData;u.h=p.rotation.y?[H[2],H[1],H[0]]:H;u.id=ch.n++;ch.it.push(o);dyn.push(o);rbInit(o,H)},
ov=(x,z,a)=>ch.sh.some(s=>x>s[0]-a&&x<s[1]+a&&z>s[2]-a&&z<s[3]+a)||ch.it.some(q=>Math.abs(q.userData.wp.x-x)<a+.1&&Math.abs(q.userData.wp.z-z)<a+.1),
item=(x,y,z,p)=>{const t=r()*4|0,q=small(t,r),o=q[0];o.position.set(x,y+q[2],z);p.add(o);o.userData={fn:knock,ch,hh:q[2],gl:t==3};reg(o,p,q[1])},
  edge=(ax,fd)=>{const e=ax=='e',ni=i+e,nj=j+!e,q=mk(hs(i,j,e?1:2)),t=q(),EL=LAY3.edge(i,j,e),ty=fd!=null?1:vd(i,j)||vd(ni,nj)?0:EL.t0<0?0:EL.t0,d=fd??EL.d,ex=cx+(e?4:0),ez=cz+(e?0:4),wg=new THREE.Group(),h=ty==1?2.1:2.3,k=hs(i,j,e?3:4)%50;
  if(EL.t0<0&&fd==null&&!vd(i,j)&&!vd(ni,nj))return;
  wg.position.set(ex,0,ez);wg.rotation.y=e?-Math.PI/2:0;G.add(wg);
  const pts=ty?[[-4,0],[d-.45,0],[d-.45,h],[d+.45,h],[d+.45,0],[4,0],[4,2.8],[-4,2.8]]:[[-4,0],[4,0],[4,2.8],[-4,2.8]],sh=new THREE.Shape();pts.forEach((p,n)=>n?sh.lineTo(p[0],p[1]):sh.moveTo(p[0],p[1]));
  const gm=new THREE.ShapeGeometry(sh),pp=gm.attributes.position,uv=gm.attributes.uv;gm.userData.own=1;for(let n=0;n<pp.count;n++)uv.setXY(n,(pp.getX(n)+4)/8,pp.getY(n)/2.8);wg.add(new THREE.Mesh(gm,wm(k)));
  const W=(lx,lz)=>e?[ex-lz,ez+lx]:[ex+lx,ez+lz],wc=(a,b,w)=>{const c=col(...(e?[ex-w,ex+w,ez+a,ez+b]:[ex+a,ex+b,ez-w,ez+w]));ch.wl.push(c);return c};
  if(!ty){wc(-4,4,.12)}else{wc(-4,d-.45,.12);wc(d+.45,4,.12);ch.lt.push(e?[ex-.12,ex+.12,ez+d-.45,ez+d+.45,2.8,h]:[ex+d-.45,ex+d+.45,ez-.12,ez+.12,2.8,h]);
   B(.06,h+.04,.16,d-.48,(h+.04)/2,0,frm,wg);B(.06,h+.04,.16,d+.48,(h+.04)/2,0,frm,wg);B(.96,.06,.16,d,h+.03,0,frm,wg);
   if(ty==1){const c=wc(d-.45,d+.45,.07),pv=new THREE.Group(),lv=new THREE.Group(),dir0=q()<.5?-1:1,dr={ch,a:0,t:0,tn:0,q:null,dir:dir0};pv.position.set(d-.45,0,0);wg.add(pv);B(.9,h-.02,.05,.45,(h-.02)/2,0,wood,pv,.01);lv.position.set(.78,1,0);pv.add(lv);
    [-1,1].forEach(s=>{B(.14,.025,.03,-.05,0,s*.055,metal,lv);B(.05,.05,.015,.02,0,s*.04,metal,lv)});
    const tgl=()=>{const m=W(d,0);if(Math.hypot(home.x-m[0],home.z-m[1])>1.8)return;byd.sw=0;dr.pt=performance.now();dr.t=dr.t?0:1};
    hb(.3,.3,.3,.75,1,0,pv,tgl);hb(.9,h-.1,.7,d,(h-.1)/2,0,wg,tgl);
    const SG=z=>{const th=z*1.75*dr.dir,p1=W(d-.45,0),p2=W(d-.45+.9*Math.cos(th),-.9*Math.sin(th));c[0]=Math.min(p1[0],p2[0])-.07;c[1]=Math.max(p1[0],p2[0])+.07;c[2]=Math.min(p1[1],p2[1])-.07;c[3]=Math.max(p1[1],p2[1])+.07;c.sg=[p1[0],p1[1],p2[0],p2[1]];pv.rotation.y=th};
    dr.u=dt=>{const a=dr.a;if(!dt){SG(a);lv.rotation.z=0;return}
     if(a!=dr.t){let na=a+(dr.t-a)*Math.min(1,dt*4.5);if(Math.abs(dr.t-na)<.004)na=dr.t;SG(na);const q=_sq(home.x,home.z,c.sg),dd=q[0];
      if(dd<.3){const pe=.3-dd+.004,px=home.x+q[1]*pe,pz=home.z+q[2]*pe;if(hitC(px,pz,c)){SG(a);na=a}else{home.x=px;home.z=pz}}
      dr.a=na}
     lv.rotation.z=-Math.sin(Math.min(1,(performance.now()-dr.pt)/450)*Math.PI)*.7};
    dr.pt=-1e4;dr.u(0);A.push(dr)}}
  if(ty<2&&!ch.o&&!vd(i,j)){const sx=d>0?-2.6:2.6,sg=e?1:-1;B(.07,.11,.015,sx,1.2,sg*.02,plm,wg);const rk=B(.035,.06,.02,sx,1.2,sg*.03,metal,wg),sy=()=>{rk.rotation.x=sg*(ch.lit?.4:-.4)};sy();hb(.25,.3,.2,sx,1.2,sg*.06,wg,()=>{ch.lit=!ch.lit;if(ch.lm)ch.lm.emissiveIntensity=ch.lit?2.2:0;sy();sfxCab(2);if(ch.lit&&typeof flick=='function')flick()});
   B(.18,.22,.005,sx+.35,1.5,sg*.01,PAP,wg);hb(.25,.3,.1,sx+.35,1.5,sg*.06,wg,()=>{hintEl.textContent=NT[k%NT.length];hintEl.style.opacity=1;clearTimeout(ch.ht);ch.ht=setTimeout(()=>hintEl.style.opacity=0,4000)})}};
 if(!(i+1==0&&j==0))edge('e',ch.o?-2.6:null);if(!(i==0&&j+1==0)&&!ch.o)edge('s');
 if(!ch.o&&!vd(i,j)){const Z=LAY3.zone(i,j),K=LAY3.K(Z),PU=(x,z,w,d,h,m,y0=0,sl=1)=>{const o=B(w,h,d,x,y0+h/2,z,m);if(sl){const c=col(x-w/2,x+w/2,z-d/2,z+d/2,y0+h);ch.sh.push(c);ch.st.push([c[0],c[1],0,y0+h,c[2],c[3]]);if(sl==2)ch.wl.push(c)}return o},CY=(x,z,rd,h,m)=>{const o=new THREE.Mesh(CYL,m);o.scale.set(rd,h,rd);o.position.set(x,h/2,z);G.add(o);const c=col(x-rd,x+rd,z-rd,z+rd,h);ch.sh.push(c);ch.st.push([c[0],c[1],0,h,c[2],c[3]])};
  LAY3.build(ch,i,j,cx,cz,r,PU,CY,ov,wm(hs(i,j,8)%50),Z,(x,y,z)=>item(x,y,z,G));
  const fl=new THREE.Mesh(PG,FL3[Z.t]||fm(r()*12|0)),cl=new THREE.Mesh(PG,ce.material);fl.rotation.x=-Math.PI/2;fl.rotation.z=(r()*4|0)*Math.PI/2;cl.rotation.x=Math.PI/2;cl.position.y=2.8;fl.position.set(cx,0,cz);cl.position.x=cx;cl.position.z=cz;G.add(fl,cl);
  ch.lm=LAMP.clone();B(1.2,.05,.4,cx,2.77,cz,ch.lm);
  if(r()<.5){const z=cz+(r()<.5?-3.55:3.55),m=r()<.55?RM:PM,p=new THREE.Mesh(CYL,m);p.rotation.z=Math.PI/2;p.scale.set(.07,8,.07);p.position.set(cx,2.5,z);G.add(p);
   for(let x=-3;x<=3;x+=2){const f=new THREE.Mesh(TOR,m);f.scale.setScalar(.1);f.position.set(cx+x,2.5,z);f.rotation.y=Math.PI/2;G.add(f)}
   const w=new THREE.Group(),wr=new THREE.Mesh(TOR,cm),sp={ch,t:0,s:0,acc:0,ps:null,ex:hs(i,j,5)&1?1:-1,x:cx+(hs(i,j,5)&1?3.9:-3.9),y:2.5,z:z+(z>cz?-.1:.1),zs:z>cz?-1:1,leak:hs(i,j,6)%4>0};wr.scale.setScalar(.09);w.add(wr);B(.16,.015,.015,0,0,0,cm,w);B(.015,.16,.015,0,0,0,cm,w);w.position.set(cx+(r()-.5)*4*K[0],2.5,z+(z>cz?-.1:.1));G.add(w);
   sp.u=dt=>{w.rotation.z+=(sp.t-w.rotation.z)*Math.min(1,dt*6);steamU(sp,dt)};A.push(sp);hb(.4,.4,.3,0,0,0,w,()=>{sp.t+=Math.PI;sfxCab(2)})}
  if(r()<.7){const sx=cx+(r()-.5)*4*K[0],sz=cz+(r()-.5)*4*K[1],al=r()<.5,L=1.6,Dp=.45,sg=new THREE.Group();sg.position.set(sx,0,sz);if(!al)sg.rotation.y=Math.PI/2;G.add(sg);
   const sb=(lx,ly,lz,w,h,d)=>ch.st.push(al?[sx+lx-w/2,sx+lx+w/2,ly-h/2,ly+h/2,sz+lz-d/2,sz+lz+d/2]:[sx+lz-d/2,sx+lz+d/2,ly-h/2,ly+h/2,sz-lx-w/2,sz-lx+w/2]);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([a,b])=>{B(.04,2,.04,a*L/2,1,b*Dp/2,metal,sg);sb(a*L/2,1,b*Dp/2,.04,2,.04)});
   [.3,.8,1.3,1.8].forEach(y=>{B(L,.03,Dp,0,y,0,PM,sg);sb(0,y,0,L,.03,Dp);for(let n=0;n<3;n++)item((n-1)*.5+(r()-.5)*.1,y+.015,(r()-.5)*.15,sg)});
   ch.sh.push(col(...(al?[sx-L/2,sx+L/2,sz-Dp/2,sz+Dp/2]:[sx-Dp/2,sx+Dp/2,sz-L/2,sz+L/2]),2))}
  if(r()<.6){const wd=r()<.5,W=wd?1:.55,H=wd?1.9:.65,D=wd?.5:.42,x=cx+(r()-.5)*5*K[0],z=cz+(r()-.5)*5*K[1],ro=r()*4|0,sw=ro&1,hw=(sw?D:W)/2,hd=(sw?W:D)/2;
   if(!ov(x,z,Math.max(hw,hd)+.6)){const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=ro*Math.PI/2;G.add(g);const t=.03,F=D/2,dm=[CB,cm,PAP,wood];
    B(t,H,D,-W/2+t/2,H/2,0,wood,g);B(t,H,D,W/2-t/2,H/2,0,wood,g);B(W,t,D,0,H-t/2,0,wood,g);B(W,t,D,0,t/2+.05,0,wood,g);B(W,H,.012,0,H/2,-F+.006,wood,g);
    const c=[x-hw,x+hw,z-hd,z+hd,H];ch.cols.push(c);ch.sh.push(c);ch.st.push([c[0],c[1],0,H,c[2],c[3]]);
    const stuff=(y,w)=>{for(let n=0,m=1+(r()*3|0);n<m;n++){const a=.1+r()*.12,b=.08+r()*.14;B(a,b,.2,(n-(m-1)/2)*(w/(m+.5)),y+b/2,-F*.35,dm[r()*4|0],g)}},
    door=(px,py,w,h,s)=>{const pv=new THREE.Group(),o={ch,a:0,t:0};pv.position.set(px,py,F);g.add(pv);B(w-.01,h,.025,s*w/2,0,.0125,wood,pv);B(.03,.03,.03,s*(w-.05),0,.04,metal,pv);
     hb(w,h,.1,s*w/2,0,.03,pv,()=>{o.t=o.t?0:1;sfxCab(0)});o.u=dt=>{if(o.a!=o.t){o.a+=(o.t-o.a)*Math.min(1,dt*6);if(Math.abs(o.t-o.a)<.003)o.a=o.t;pv.rotation.y=-s*1.9*o.a}};A.push(o)},
    drawer=(py,w,h)=>{const dg=new THREE.Group(),o={ch,a:0,t:0};dg.position.set(0,py,0);g.add(dg);B(w-.02,h-.02,.02,0,0,F+.01,wood,dg);B(.12,.02,.025,0,0,F+.03,metal,dg);
     B(w-.07,.012,D-.06,0,-h/2+.03,0,wood,dg);B(.012,h-.08,D-.06,-(w-.07)/2,0,0,wood,dg);B(.012,h-.08,D-.06,(w-.07)/2,0,0,wood,dg);B(w-.07,h-.08,.012,0,0,-F+.04,wood,dg);
     for(let n=0,m=r()*3|0;n<m;n++){const a=.08+r()*.1,b=.04+r()*.06;B(a,b,.12,(n-(m-1)/2)*.15,-h/2+.036+b/2,0,dm[r()*4|0],dg)}
     hb(w,h,.1,0,0,F+.03,dg,()=>{o.t=o.t?0:1;sfxCab(1)});o.u=dt=>{if(o.a!=o.t){o.a+=(o.t-o.a)*Math.min(1,dt*6);if(Math.abs(o.t-o.a)<.003)o.a=o.t;dg.position.z=o.a*D*.75}};A.push(o)};
    if(wd){drawer(.18,W-2*t,.22);drawer(.41,W-2*t,.22);const h=1.33,py=.54+h/2;door(-(W/2-t),py,(W-2*t)/2,h,1);door(W/2-t,py,(W-2*t)/2,h,-1);
     [.33,.66].forEach(f=>{const y=.54+h*f;B(W-2*t,t,D-.04,0,y,-.01,wood,g);stuff(y+t/2,W-2*t)});stuff(.54+t/2,W-2*t)}
    else if(r()<.6){drawer(.05+.1425+.285,W-2*t,.285);drawer(.05+.1425,W-2*t,.285)}
    else{drawer(.05+.4275,W-2*t,.285);door(-(W/2-t),.05+.1425,W-2*t,.27,1);stuff(.065,W-2*t)}}}
  if(r()<.45)appl(ch,G,r,cx,cz,ov);
  for(let n=r()*3|0;n>=0;n--){const x=cx+(r()-.5)*6*K[0],z=cz+(r()-.5)*6*K[1];if(ov(x,z,.35))continue;const o=B(.4,.3,.35,x,.15,z,CB,G,.015);o.userData={fn:knock,ch,hh:.15,c:col(x-.25,x+.25,z-.25,z+.25,.3)};reg(o,G,[.2,.15,.175])}
  for(let n=r()*4|0;n>0;n--){const x=cx+(r()-.5)*6*K[0],z=cz+(r()-.5)*6*K[1];if(ov(x,z,.15))continue;const t=1+(r()*3|0),q=small(t,r),o=q[0];o.position.set(x,q[2],z);o.userData={fn:knock,ch,hh:q[2],gl:t==3};G.add(o);reg(o,G,q[1])}}}
