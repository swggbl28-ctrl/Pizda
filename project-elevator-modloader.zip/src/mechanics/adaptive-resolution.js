//# FILE: mechanics/adaptive-resolution.js
//# ЧТО: Адаптивное разрешение рендера (120 Гц / высокий dpr).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: apr, adapt
// ---------- adaptive resolution (S25 Ultra: 120Hz / high dpr) ----------
let apr=R.getPixelRatio(),aft=8.3,acn=-240,gd=0,hold=960,lu=0;const MPR=apr;
function adapt(dt){aft+=(dt*1000-aft)*.08;if(++acn<30)return;acn=0;
 const hz=window.NativeApp&&NativeApp.hz?NativeApp.hz():60,tg=1000/hz;let n=apr;
 if(aft>tg*1.2&&apr>.75){n=Math.max(.75,apr-.125);if(performance.now()-lu<5000)hold=Math.min(hold*2,15360);gd=0}
 else if(aft<tg*1.08&&apr<MPR){gd+=30;if(gd>=hold){n=Math.min(MPR,apr+.125);gd=0;lu=performance.now()}}
 if(n!==apr){apr=n;R.setPixelRatio(n);R.setSize(innerWidth,innerHeight)}}
