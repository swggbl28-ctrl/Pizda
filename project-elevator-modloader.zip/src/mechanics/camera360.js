//# FILE: mechanics/camera360.js
//# ЧТО: Камера 360 / гироскоп.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: yaw, lp, gReq
// ---------- camera 360 ----------
let yaw=0,pitch=0,devQ=new THREE.Quaternion(),hasGyro=false,gyroOn=true;const tq=new THREE.Quaternion(),q1=new THREE.Quaternion(-Math.sqrt(.5),0,0,Math.sqrt(.5)),eu=new THREE.Euler(),zz=new THREE.Vector3(0,0,1),q0=new THREE.Quaternion();
addEventListener('deviceorientation',e=>{if(e.alpha==null)return;hasGyro=true;const r=Math.PI/180,o=(screen.orientation?screen.orientation.angle:window.orientation||0)*r;
 eu.set(e.beta*r,e.alpha*r,-e.gamma*r,'YXZ');devQ.setFromEuler(eu).multiply(q1).multiply(q0.setFromAxisAngle(zz,-o))});
let lp=null,down=null;const cv=R.domElement;
cv.addEventListener('pointerdown',e=>{down={x:e.clientX,y:e.clientY,t:performance.now()};lp=[e.clientX,e.clientY];initAudio();reqGyro()});
addEventListener('pointerup',e=>{if(down&&e.target===cv&&Math.hypot(e.clientX-down.x,e.clientY-down.y)<12&&performance.now()-down.t<500)pick(e.clientX,e.clientY);down=null;lp=null});
cv.addEventListener('pointermove',e=>{if(lp&&zoomed&&mode==='emu'&&emu){emu.bus.send('mouse-delta',[(e.clientX-lp[0])*2,-(e.clientY-lp[1])*2]);lp=[e.clientX,e.clientY];return}if(!lp||zoomed)return;yaw+=(e.clientX-lp[0])*.005;pitch=Math.max(-1.3,Math.min(1.3,pitch+(e.clientY-lp[1])*.005));lp=[e.clientX,e.clientY]});
let gReq=false;function reqGyro(){if(gReq)return;gReq=true;if(window.DeviceOrientationEvent&&DeviceOrientationEvent.requestPermission)DeviceOrientationEvent.requestPermission().catch(()=>{})}
$('ctr').onclick=()=>{if(tp){yaw=byd.yaw;pitch=.2;return}if(hasGyro&&gyroOn){eu.setFromQuaternion(devQ,'YXZ');yaw=-eu.y;pitch=0}else{yaw=0;pitch=-.1}};
$('gy').onchange=e=>{gyroOn=e.target.checked;if(gyroOn){yaw=0;pitch=0}};
