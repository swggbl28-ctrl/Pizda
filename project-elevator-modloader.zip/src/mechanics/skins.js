//# FILE: mechanics/skins.js
//# ЧТО: Скины (только через спавн-ПК), PNG 64x64.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: SKL, loadImg, applySkin, skApply, skSave, skinConv, slotXY, fig, drawSkin, skSel, skinTap
// ---------- skins (only via the spawn PC) ----------
const SKL=[];let SKS=-1,skMsg='';
const loadImg=u=>new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=no;i.src=u});
function applySkin(cv,slim){const t=new THREE.CanvasTexture(cv);t.colorSpace=THREE.SRGBColorSpace;t.magFilter=THREE.NearestFilter;t.anisotropy=AN;if(SM.map)SM.map.dispose();SM.map=t;SM.needsUpdate=true;
 const w=slim?3:4;[[aR,40,16],[aL,32,48]].forEach(([a,x,y])=>{a.geometry.dispose();a.userData.f.geometry.dispose();a.geometry=mcg(w,6,4,x,y,1,0);a.userData.f.geometry=mcg(w,6,4,x,y,1,1)});aR.position.x=(4+w/2)*U;aL.position.x=-(4+w/2)*U}
const skApply=()=>{SKS>=0?applySkin(SKL[SKS].cv,SKL[SKS].slim):applySkin(STC,false);mp.skin&&mp.skin()};
function skSave(){try{localStorage.setItem('skins',JSON.stringify({sel:SKS,l:SKL.map(s=>({n:s.n,d:s.cv.toDataURL('image/png'),s:s.slim?1:0}))}))}catch(e){skMsg='Не удалось сохранить'}}
function skinConv(im){const k=im.width/64,full=im.height>=im.width,[c,g]=cv2(64,64),[t,tg]=cv2(im.width,im.height);tg.drawImage(im,0,0);
 const slim=full&&tg.getImageData(55*k|0,25*k|0,1,1).data[3]===0&&tg.getImageData(54*k|0,25*k|0,1,1).data[3]===0;
 g.fillStyle='rgb(198,146,112)';g.fillRect(0,0,64,64);g.imageSmoothingEnabled=k>1;
 const cp=(sx,sy,w,h,dx,dy)=>g.drawImage(im,sx*k,sy*k,w*k,h*k,dx,dy,w,h);
 cp(0,0,64,full?64:32,0,0);cp(32,0,32,16,0,0);
 if(full){cp(16,32,24,16,16,16);cp(40,32,16,16,40,16);cp(0,32,16,16,0,16);cp(48,48,16,16,32,48);cp(0,48,16,16,16,48)}
 else{g.imageSmoothingEnabled=false;const mir=(sx,sy,dx,dy)=>[[4,0,4,4,4,0],[8,0,4,4,8,0],[8,4,4,12,0,4],[4,4,4,12,4,4],[0,4,4,12,8,4],[12,4,4,12,12,4]].forEach(([a,b,w,h,x2,y2])=>{g.save();g.translate(dx+x2+w,dy+y2);g.scale(-1,1);g.drawImage(c,sx+a,sy+b,w,h,0,0,w,h);g.restore()});mir(40,16,32,48);mir(0,16,16,48)}
 return{cv:c,slim}}
$('skf').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;let u;
 try{u=URL.createObjectURL(f);const im=await loadImg(u);
  if(im.width<64||im.width%64||(im.height!==im.width&&im.height*2!==im.width))skMsg='Нужен PNG скин Minecraft 64×64 или 64×32';
  else if(SKL.length>=10)skMsg='Максимум 10 скинов — удалите лишний';
  else{const r=skinConv(im);SKL.push({n:f.name.replace(/\.[^.]+$/,'').slice(0,14),cv:r.cv,slim:r.slim});SKS=SKL.length-1;skApply();skSave();skMsg='Скин добавлен и надет'}}
 catch(x){skMsg='Не удалось загрузить файл'}finally{u&&URL.revokeObjectURL(u)}drawScreen()};
(async()=>{try{const o=JSON.parse(localStorage.getItem('skins')||'null');if(!o)return;for(const s of(o.l||[]).slice(0,10)){const im=await loadImg(s.d),[c,g]=cv2(64,64);g.drawImage(im,0,0);SKL.push({n:s.n,cv:c,slim:!!s.s})}
 SKS=Math.min(o.sel??-1,SKL.length-1);if(SKS>=0)skApply()}catch(e){}})();
const slotXY=i=>[10+(i%6)*168,70+(i/6|0)*222];
function fig(g,c,x,y,s,slim){g.imageSmoothingEnabled=false;const d=(sx,sy,w,h,dx,dy)=>g.drawImage(c,sx,sy,w,h,x+dx*s,y+dy*s,w*s,h*s),aw=slim?3:4;
 d(8,8,8,8,4,0);d(20,20,8,12,4,8);d(44,20,aw,12,4-aw,8);d(36,52,aw,12,12,8);d(4,20,4,12,4,20);d(20,52,4,12,8,20);g.imageSmoothingEnabled=true}
function drawSkin(g){g.fillStyle='#14161c';g.fillRect(0,0,SW,SH-40);g.textAlign='left';g.fillStyle='#fff';g.font='bold 26px sans-serif';icoSkin(g,14,6,44);g.fillText('Скины Minecraft ('+SKL.length+'/10)',68,38);
 g.fillStyle='#9ab';g.font='16px sans-serif';g.fillText(skMsg||'Тап — надеть, ✕ — удалить. Загрузка PNG-скина с телефона',20,60);
 for(let i=0;i<12;i++){const[x,y]=slotXY(i),sel=i<11&&(i==0?SKS<0:SKS==i-1),o=i>0&&i<11?SKL[i-1]:null;
  g.fillStyle=sel?'#1f3a2a':'#222733';rr(x,y,160,210,14);g.fill();g.strokeStyle=sel?'#4caf50':'#3b4150';g.lineWidth=sel?4:2;g.stroke();g.textAlign='center';
  if(i==11){g.fillStyle='#4caf50';g.font='64px sans-serif';g.fillText('＋',x+80,y+112);g.fillStyle='#fff';g.font='bold 18px sans-serif';g.fillText(SKL.length>=10?'Лимит 10':'Загрузить',x+80,y+190)}
  else if(i>0&&!o){g.fillStyle='#3b4150';g.font='18px sans-serif';g.fillText('пусто',x+80,y+110)}
  else{fig(g,o?o.cv:STC,x+48,y+24,4,o&&o.slim);g.fillStyle='#fff';g.font='bold 17px sans-serif';g.fillText(o?o.n:'Стив',x+80,y+190);
   if(o){g.fillStyle='#c0392b';rr(x+124,y+6,30,30,8);g.fill();g.fillStyle='#fff';g.font='bold 18px sans-serif';g.fillText('✕',x+139,y+27)}}
  g.textAlign='left'}}
function skSel(n){SKS=n;skApply();skSave()}
function skinTap(x,y){skMsg='';for(let i=0;i<12;i++){const[sx,sy]=slotXY(i);if(x>sx&&x<sx+160&&y>sy&&y<sy+210){
  if(i==11){if(SKL.length>=10)skMsg='Максимум 10 — удалите лишний';else $('skf').click()}
  else if(i==0)skSel(-1);
  else{const o=SKL[i-1];if(!o)break;if(x>sx+120&&y<sy+40){SKL.splice(i-1,1);if(SKS==i-1)SKS=-1;else if(SKS>i-1)SKS--;skApply();skSave()}else skSel(i-1)}
  break}}drawScreen()}
