//# FILE: mechanics/walking.js
//# ЧТО: Ходьба.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: mv, hitC, IAq, _sq, runOn, walk
// ---------- walking ----------
const mv={x:0,y:0},qo=new THREE.Quaternion(),fw=new THREE.Vector3(),cols=[[-1.1,1.1,-1.6,-.8,.85],[-.3,.3,-.7,-.08,1.1],[-3.78,-3.2,-3.92,-3.26,1.35],[2.84,2.96,-2.73,-.27,1.5],[.5,2.96,-2.76,-2.64,1.5],[-4.12,-3.88,-4.1,4.1,2.8],[-4.1,4.1,-4.12,-3.88,2.8],[-4.1,1.6,3.88,4.12,2.8],[2.8,4.1,3.88,4.12,2.8]];let bob=0;
const hitC=(x,z,ex)=>{const f=c=>{if(c.off||c===ex)return 0;if(c.sg)return _sq(x,z,c.sg)[0]<.3;const dx=x-Math.max(c[0],Math.min(x,c[1])),dz=z-Math.max(c[2],Math.min(z,c[3]));return dx*dx+dz*dz<.0625};return cols.some(f)||dcols.some(f)};
let IAq=null,ARM=null;const _lp=new THREE.Vector3(),_dn=new THREE.Vector3(0,-1,0),_qa=new THREE.Quaternion(),_qb=new THREE.Quaternion(),_sa=[0,0,0],_ss=x=>(x=Math.max(0,Math.min(1,x)))*x*(3-2*x);
function _sq(x,z,s){const ex=s[2]-s[0],ez=s[3]-s[1],t=Math.max(0,Math.min(1,((x-s[0])*ex+(z-s[1])*ez)/(ex*ex+ez*ez||1))),dx=x-s[0]-ex*t,dz=z-s[1]-ez*t,d=Math.hypot(dx,dz);_sa[0]=d;_sa[1]=d>1e-4?dx/d:1;_sa[2]=d>1e-4?dz/d:0;return _sa}
let runOn=false,stam=100,sd=0,rk=0;const sbE=$('sb'),sfE=$('sf');
$('rn').onclick=()=>{if(runOn)runOn=false;else if(stam>20)runOn=true;$('rn').style.background=runOn?'#8a7e3add':''};
function walk(dt){if(IAq&&!A.includes(IAq.dr))IAq=ARM=null;const m=Math.hypot(mv.x,mv.y),mvg=!zoomed&&m>=.05&&!IAq,run=runOn&&mvg&&stam>0;
 if(run){stam=Math.max(0,stam-20*dt);sd=1;if(!stam){runOn=false;$('rn').style.background=''}}else{sd=Math.max(0,sd-dt);if(!sd)stam=Math.min(100,stam+(mvg?12:18)*dt)}
 rk+=((run?1:0)-rk)*Math.min(1,dt*5);sfE.style.width=stam+'%';sfE.style.background=stam<25?'#d4552a':'#ece3a0';sbE.style.opacity=stam>=99.5&&!runOn?0:1;
 if(!mvg)return;fw.set(0,0,-1).applyQuaternion(fq);fw.y=0;if(fw.lengthSq()<1e-4)return;fw.normalize();
 const s=(run?3.3:1.7)*Math.min(1,m)*dt,dx=(fw.x*mv.y-fw.z*mv.x)*s,dz=(fw.z*mv.y+fw.x*mv.x)*s,nx=home.x+dx,nz=home.z+dz,st=hitC(home.x,home.z);
 if(st||!hitC(nx,home.z))home.x=nx;if(st||!hitC(home.x,nz))home.z=nz;bob+=s*(run?5:7);home.y=1.6+Math.sin(bob)*.012*(1+rk*1.5);sdist+=s;if(sdist>=(run?1.05:.72)){sdist=0;if(AC)footstep(run,m)}}
{const j=$('joy'),k=$('kn'),M=45;let id=null;
 const set=e=>{const b=j.getBoundingClientRect();let dx=e.clientX-b.left-b.width/2,dy=e.clientY-b.top-b.height/2;const l=Math.hypot(dx,dy);if(l>M){dx*=M/l;dy*=M/l}k.style.transform=`translate(${dx}px,${dy}px)`;mv.x=dx/M;mv.y=-dy/M;if(zoomed&&l>8)zoom(false)};
 j.onpointerdown=e=>{id=e.pointerId;j.setPointerCapture(id);initAudio();reqGyro();set(e)};j.onpointermove=e=>{if(e.pointerId===id)set(e)};
 j.onpointerup=j.onpointercancel=()=>{id=null;mv.x=mv.y=0;k.style.transform=''}}

