//# FILE: mechanics/physics.js
//# ЧТО: Физика твёрдых тел для мелких предметов.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: HST, rad, rbInit, regG, wk, wkAbove, iw, effM, app, vAt, kn, insd, mkC, solve, phys, pushItems, physS, procTick, STC
// ---------- rigid-body physics: small objects ----------
const HST=[[-1.1,1.1,.72,.78,-1.6,-.8],[-.87,-.63,.03,.49,-1.45,-.95],[.56,1,.22,.72,-1.51,-.89],[-3.75,-3.25,0,1.3,-3.9,-3.3],[-.2,.2,.78,.8,-1.525,-1.275],[-.06,.06,.8,1,-1.45,-1.35],[-.5,.5,.92,1.52,-1.43,-1.37],[-.25,.25,.46,.54,-.65,-.15],[-4.1,-3.98,0,2.8,-4.1,4.1],[-4.1,4.1,0,2.8,-4.1,-3.98],[-4.1,1.6,0,2.8,3.98,4.1],[2.8,4.1,0,2.8,3.98,4.1],[-1e3,1e3,2.8,60,-1e3,1e3],[-1e3,1e3,-1,0,-1e3,1e3]],
BOTP=[[-.085,.03],[-.07,.031],[.02,.031],[.04,.026],[.058,.017],[.07,.0115],[.085,.0115]],BOTY=[-.085,0,.04,.07,.085],MU=.55,
Zq=new Q4,Zqi=new Q4,Zr=new V3,Zx=new V3,Zr2=new V3,Zx2=new V3,Zn=new V3,Zlp=new V3,Zva=new V3,Zvb=new V3,Zvr=new V3,Zt1=new V3,Zt2=new V3,ZJ=new V3,ZT=new V3,
NX=[-1,1,0,0,0,0],NY=[0,0,-1,1,0,0],NZ=[0,0,0,0,-1,1];let hpx=0,hpz=0;
function rad(u,y){const f=u.pf;if(!f)return u.d[0];for(let i=1;i<f.length;i++)if(y<=f[i][0]){const a=f[i-1],b=f[i],t=(y-a[0])/(b[0]-a[0]||1);return a[1]+(b[1]-a[1])*Math.max(0,Math.min(1,t))}return f[f.length-1][1]}
function rbInit(o,H){const u=o.userData,cy=o.name=='c',m=cy?Math.PI*H[0]*H[0]*2*H[1]*800:8*H[0]*H[1]*H[2]*(H[0]>.15?25:40);
 u.o=o;u.d=H;u.cy=cy;u.im=1/m;u.v=new V3;u.w=new V3;u.dp=new V3;u.aw=0;u.st=0;u.wp=o.getWorldPosition(new V3);u.q=o.getWorldQuaternion(new Q4);
 u.ii=cy?new V3(12/(m*(3*H[0]*H[0]+4*H[1]*H[1])),2/(m*H[0]*H[0]),12/(m*(3*H[0]*H[0]+4*H[1]*H[1]))):new V3(3/(m*(H[1]*H[1]+H[2]*H[2])),3/(m*(H[0]*H[0]+H[2]*H[2])),3/(m*(H[0]*H[0]+H[1]*H[1])));
 if(cy&&o.geometry===BOTG)u.pf=BOTP;
 const P=u.P=[];
 if(cy){(u.pf?BOTY:[-H[1],0,H[1]]).forEach(y=>{const R=rad(u,y);for(let i=0;i<12;i++){const a=i*Math.PI/6;P.push(new V3(Math.cos(a)*R,y,Math.sin(a)*R))}});[-H[1],H[1]].forEach(y=>{const R=rad(u,y)*.5;for(let i=0;i<6;i++){const a=i*Math.PI/3;P.push(new V3(Math.cos(a)*R,y,Math.sin(a)*R))}P.push(new V3(0,y,0))})}
 else for(let a=-1;a<2;a++)for(let b=-1;b<2;b++)for(let c=-1;c<2;c++)if(a||b||c)P.push(new V3(a*H[0],b*H[1],c*H[2]));
 u.br=cy?Math.hypot(H[0],H[1]):Math.hypot(H[0],H[1],H[2])}
function regG(c,o,H){const u=o.userData;u.h=H;u.id=c.n++;c.it.push(o);dyn.push(o);rbInit(o,H)}
function wk(o){const u=o.userData;if(u.aw)return;u.aw=1;u.moved=1;u.st=0;u.ch.g.attach(o);o.position.copy(u.wp);o.quaternion.copy(u.q);if(u.c)u.c.off=true;u.ch.ph.add(o);wkAbove(u)}
function wkAbove(u){const c=u.ch;for(let a=-1;a<2;a++)for(let b=-1;b<2;b++){const g=CH.get((c.i+a)+','+(c.j+b));g&&g.it.forEach(k=>{const e=k.userData;if(!e.aw&&e!==u&&e.wp.y>u.wp.y-.02&&e.wp.y-u.wp.y<e.br+u.br+.03&&Math.hypot(e.wp.x-u.wp.x,e.wp.z-u.wp.z)<e.br+u.br+.03)wk(k)})}}
function iw(u,x,out){return out.copy(x).applyQuaternion(Zqi.copy(u.q).invert()).multiply(u.ii).applyQuaternion(u.q)}
function effM(u,r,n){Zt1.copy(r).cross(n);iw(u,Zt1,Zt2);Zt2.cross(r);return u.im+Zt2.dot(n)}
function app(u,r,J,s){u.v.addScaledVector(J,u.im*s);Zt1.copy(r).cross(J);iw(u,Zt1,Zt2);u.w.addScaledVector(Zt2,s)}
function vAt(u,r,out){return out.copy(u.w).cross(r).add(u.v)}
function kn(o,pt){const u=o.userData,d=ray.ray.direction;if(AC)hitSnd(u.im,u.gl);wk(o);ZJ.set(d.x,.4+Math.max(0,d.y),d.z).normalize().multiplyScalar(2.6/u.im);Zr.copy(pt||u.wp).sub(u.wp);app(u,Zr,ZJ,1)}
function insd(e,x){const H=e.d;Zlp.copy(x).sub(e.wp).applyQuaternion(Zqi.copy(e.q).invert());let pen,nx=0,ny=0,nz=0;
 if(e.cy){const y=Zlp.y,rr=Math.hypot(Zlp.x,Zlp.z),R=rad(e,y);if(Math.abs(y)>=H[1]||rr>=R)return 0;const pa=H[1]-Math.abs(y),pr=R-rr;if(pa<pr){pen=pa;ny=y>0?1:-1}else{pen=pr;if(rr>1e-6){nx=Zlp.x/rr;nz=Zlp.z/rr}else nx=1}}
 else{const a=H[0]-Math.abs(Zlp.x),b=H[1]-Math.abs(Zlp.y),c=H[2]-Math.abs(Zlp.z);if(a<=0||b<=0||c<=0)return 0;if(a<=b&&a<=c){pen=a;nx=Zlp.x>0?1:-1}else if(b<=c){pen=b;ny=Zlp.y>0?1:-1}else{pen=c;nz=Zlp.z>0?1:-1}}
 Zn.set(nx,ny,nz).applyQuaternion(e.q);return pen}
function mkC(a,b,r,rb,n,pen){const k={a,b,r,rb,n,pen,jn:0,jt:new V3};vAt(a,r,Zva);b?vAt(b,rb,Zvb):Zvb.set(0,0,0);const vn=Zva.sub(Zvb).dot(n);k.vn0=vn;k.e=vn<-1?.3:0;if(vn<0){a.imp=Math.max(a.imp||0,-vn);if(b)b.imp=Math.max(b.imp||0,-vn)}a.dp.set(0,0,0);b&&b.dp.set(0,0,0);return k}
function solve(k){const a=k.a,b=k.b,n=k.n;
 vAt(a,k.r,Zva);b?vAt(b,k.rb,Zvb):Zvb.set(0,0,0);Zvr.copy(Zva).sub(Zvb);
 const den=effM(a,k.r,n)+(b?effM(b,k.rb,n):0),jn=Math.max(0,k.jn+(k.e*-k.vn0-Zvr.dot(n))/den),dj=jn-k.jn;k.jn=jn;
 if(dj){ZJ.copy(n).multiplyScalar(dj);app(a,k.r,ZJ,1);b&&app(b,k.rb,ZJ,-1);vAt(a,k.r,Zva);b?vAt(b,k.rb,Zvb):Zvb.set(0,0,0);Zvr.copy(Zva).sub(Zvb)}
 ZT.copy(Zvr).addScaledVector(n,-Zvr.dot(n));const tl=ZT.length();
 if(tl>1e-6){ZT.multiplyScalar(-1/tl);const d2=effM(a,k.r,ZT)+(b?effM(b,k.rb,ZT):0);ZJ.copy(k.jt).addScaledVector(ZT,tl/d2);const mx=MU*k.jn,l=ZJ.length();if(l>mx)ZJ.multiplyScalar(mx/l);ZJ.sub(k.jt);k.jt.add(ZJ);app(a,k.r,ZJ,1);b&&app(b,k.rb,ZJ,-1)}}
function phys(c,o,dt){
 const u=o.userData,p=u.wp,v=u.v,w=u.w,q=u.q,P=u.P,N=Math.min(18,Math.ceil(dt*360)),h=dt/N,R=u.br+.1+(v.length()+w.length()*u.br)*dt,bs=[],ot=[],ci=Math.round(p.x/CS),cj=Math.round(p.z/CS);
 const nr=b=>p.x>b[0]-R&&p.x<b[1]+R&&p.y>b[2]-R&&p.y<b[3]+R&&p.z>b[4]-R&&p.z<b[5]+R;
 HST.forEach(b=>nr(b)&&bs.push(b));
 for(let a=-1;a<2;a++)for(let b=-1;b<2;b++){const g=CH.get((ci+a)+','+(cj+b));if(!g)continue;
  g.st.forEach(s=>nr(s)&&bs.push(s));g.wl.forEach(s=>{if(s.off)return;const bb=[s[0],s[1],0,2.8,s[2],s[3]];nr(bb)&&bs.push(bb)});
  g.it.forEach(k=>{if(k===o)return;const e=k.userData,d=e.wp;if(Math.hypot(d.x-p.x,d.y-p.y,d.z-p.z)<R+e.br)ot.push(k)})}
 let ct=0;const inv=new Set;
 for(let s=0;s<N;s++){
  if(!u.hold)v.y-=9.8*h;w.multiplyScalar(1-h*(ct?3:.15));const vl=v.length();if(vl>14)v.multiplyScalar(14/vl);
  p.addScaledVector(v,h);Zq.set(w.x,w.y,w.z,0).multiply(q);q.set(q.x+.5*h*Zq.x,q.y+.5*h*Zq.y,q.z+.5*h*Zq.z,q.w+.5*h*Zq.w).normalize();
  const cs=[];
  for(let i=0;i<P.length;i++){
   Zr.copy(P[i]).applyQuaternion(q);Zx.copy(Zr).add(p);
   for(const b of bs)if(Zx.x>b[0]&&Zx.x<b[1]&&Zx.y>b[2]&&Zx.y<b[3]&&Zx.z>b[4]&&Zx.z<b[5]){
    const d=[Zx.x-b[0],b[1]-Zx.x,Zx.y-b[2],b[3]-Zx.y,Zx.z-b[4],b[5]-Zx.z];let m=0;for(let k=1;k<6;k++)if(d[k]<d[m])m=k;
    cs.push(mkC(u,null,Zr.clone(),null,new V3(NX[m],NY[m],NZ[m]),d[m]))}
   for(const k of ot){const e=k.userData;if(Math.hypot(e.wp.x-p.x,e.wp.y-p.y,e.wp.z-p.z)>=u.br+e.br)continue;
    const pen=insd(e,Zx);if(pen>0){if(!e.aw)wk(k);cs.push(mkC(u,e,Zr.clone(),Zx.clone().sub(e.wp),Zn.clone(),pen))}}}
  for(const k of ot){const e=k.userData;if(Math.hypot(e.wp.x-p.x,e.wp.y-p.y,e.wp.z-p.z)>=u.br+e.br)continue;
   for(let i=0;i<e.P.length;i++){Zr2.copy(e.P[i]).applyQuaternion(e.q);Zx2.copy(Zr2).add(e.wp);
    const pen=insd(u,Zx2);if(pen>0){if(!e.aw)wk(k);cs.push(mkC(e,u,Zr2.clone(),Zx2.clone().sub(p),Zn.clone(),pen))}}}
  if(cs.length){
   for(let it=0;it<6;it++)for(const k of cs)solve(k);
   const bd=new Set;cs.forEach(k=>{bd.add(k.a);k.b&&bd.add(k.b)});
   for(let it=0;it<3;it++)for(const k of cs){const ia=k.a.im,ib=k.b?k.b.im:0,pen=k.pen-(k.a.dp.dot(k.n)-(k.b?k.b.dp.dot(k.n):0));if(pen>.0005){const cr=(pen-.0005)*.8/(ia+ib);k.a.dp.addScaledVector(k.n,cr*ia);k.b&&k.b.dp.addScaledVector(k.n,-cr*ib)}}
   bd.forEach(e=>{e.wp.add(e.dp);if(e!==u)inv.add(e)})}
  ct=cs.length}
 o.position.copy(p);o.quaternion.copy(q);inv.forEach(e=>{e.o.position.copy(e.wp)});
 if(u.gl&&u.imp>2.2){shatter(c,o);return}
 u.imp=0;
 if(!u.hold&&ct&&v.lengthSq()<.004&&w.lengthSq()<.1){u.st+=dt;if(u.st>.4){c.ph.delete(o);u.aw=0;v.set(0,0,0);w.set(0,0,0)}}else u.st=0}
function pushItems(dt){const d=Math.max(dt,.001),vx=(home.x-hpx)/d,vz=(home.z-hpz)/d;hpx=home.x;hpz=home.z;const sp=Math.hypot(vx,vz);if(zoomed||sp<.15||sp>6)return;
 const ci=Math.round(home.x/CS),cj=Math.round(home.z/CS);
 for(let a=-1;a<2;a++)for(let b=-1;b<2;b++){const g=CH.get((ci+a)+','+(cj+b));g&&g.it.forEach(k=>{const e=k.userData,dx=e.wp.x-home.x,dz=e.wp.z-home.z,dd=Math.hypot(dx,dz);
  if(dd>=.28+e.br*.85||dd<1e-4||e.wp.y-e.br>1.4||e.wp.y+e.br<.05)return;
  const nx=dx/dd,nz=dz/dd,s=vx*nx+vz*nz;if(s<.05)return;wk(k);const cur=e.v.x*nx+e.v.z*nz,t=s*1.15;if(cur<t){e.v.x+=nx*(t-cur);e.v.z+=nz*(t-cur)}e.w.x+=nz*s*1.5;e.w.z-=nx*s*1.5})}}
function physS(c,o,dt){const u=o.userData,v=u.v,p=u.wp,w=u.w,[hx,hy,hz]=u.h,bx=[[-1e3,1e3,-1,0,-1e3,1e3]];let gr=0,ct=0;
 for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const n=CH.get((c.i+a)+','+(c.j+b));if(n){n.st.forEach(s=>bx.push(s));n.wl.forEach(s=>bx.push([s[0],s[1],0,2.8,s[2],s[3]]))}}
 const res=(b,o2)=>{const ox=Math.min(p.x+hx-b[0],b[1]-p.x+hx),oy=Math.min(p.y+hy-b[2],b[3]-p.y+hy),oz=Math.min(p.z+hz-b[4],b[5]-p.z+hz);if(ox<=0||oy<=0||oz<=0)return;
  const a=oy<=ox&&oy<=oz?'y':oz<ox?'z':'x',i=a=='x'?0:a=='y'?2:4,pen=a=='x'?ox:a=='y'?oy:oz,sg=p[a]>(b[i]+b[i+1])/2?1:-1,top=a=='y'&&sg>0,q=o2&&o2.userData;ct=1;if(top)gr=1;
  if(q&&q.aw&&!top){p[a]+=sg*pen/2;q.wp[a]-=sg*pen/2;const va=v[a],vb=q.v[a];u.imp=Math.max(u.imp||0,Math.abs(va-vb));v[a]=(.6*va+1.4*vb)/2;q.v[a]=(1.4*va+.6*vb)/2;return}
  p[a]+=sg*pen;const m=Math.max(0,-v[a]*sg);u.imp=Math.max(u.imp||0,m);
  if(q&&!q.aw&&!top){c.wk(o2,0,0,0);q.imp=Math.max(q.imp||0,m*.8);q.v[a]=-sg*m*.6;v[a]+=sg*m*1.1}else if(m>0)v[a]+=sg*m*(m>.7?1.3:1);
  if(a=='y'){v.x*=.92;v.z*=.92}};
 for(let s=0;s<4;s++){const h=dt/4;v.y-=9.8*h;p.addScaledVector(v,h);bx.forEach(b=>res(b));if(!u.sh)c.it.forEach(q=>{if(q!==o){const k=q.userData,e=k.wp;res([e.x-k.h[0],e.x+k.h[0],e.y-k.h[1],e.y+k.h[1],e.z-k.h[2],e.z+k.h[2]],q)}})}
 if(ct){w.multiplyScalar(.6);o.rotation.x*=.7;o.rotation.z*=.7}else{o.rotation.x+=w.x*dt;o.rotation.z+=w.z*dt}
 o.position.copy(p);if(u.gl&&u.imp>2.2){shatter(c,o);return}u.imp=0;if(gr&&v.length()<.3){c.ph.delete(o);u.aw=0;o.rotation.x=o.rotation.z=0;v.set(0,0,0)}}
function procTick(dt){const ci=Math.round(home.x/CS),cj=Math.round(home.z/CS),k=ci+','+cj;
 if(k!==lk){lk=k;for(let a=ci-2;a<=ci+2;a++)for(let b=cj-2;b<=cj+2;b++)if(!CH.has(a+','+b))gen(a,b);
  for(const[q,c]of[...CH])if(Math.abs(c.i-ci)>3||Math.abs(c.j-cj)>3){saveCh(c);S.remove(c.g);c.g.traverse(o=>{if(o.geometry&&o.geometry.userData.own)o.geometry.dispose()});dyn=dyn.filter(o=>o.userData.ch!==c);A=A.filter(a=>a.ch!==c);CH.delete(q)}
  dcols.length=0;dlt.length=0;CH.forEach(c=>{dcols.push(...c.cols);dlt.push(...c.lt)})}
 A.forEach(a=>a.u(dt));
 pushItems(dt);CH.forEach(c=>{for(const o of c.ph)(o.userData.sh?physS:phys)(c,o,dt)});
 const cc=CH.get(k);ply.position.set(home.x,2.3,home.z);ply.intensity+=((cc&&!cc.o?cc.lit?14:1.2:0)-ply.intensity)*.15}
let STC;
