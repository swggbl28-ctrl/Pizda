//# FILE: mechanics/player-steve.js
//# ЧТО: Тело игрока от первого лица (Steve): модель, анимация, bodyTick.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: steveTex, U, mcg, mcb, stv, byd, tp, _t0, _sl, rayBlock, tpBlocked, tpCam, bodyTick, bodyCaps
// ---------- Steve (first-person body) ----------
function steveTex(){const[c,g]=cv2(64,64),K=[198,146,112],H=[66,44,26],T=[0,168,172],Pn=[58,62,164],Sh=[100,100,106],
 P=(x,y,w,h,q)=>{for(let i=0;i<w;i++)for(let j=0;j<h;j++){const k=.92+Math.random()*.16;g.fillStyle=`rgb(${q[0]*k|0},${q[1]*k|0},${q[2]*k|0})`;g.fillRect(x+i,y+j,1,1)}};
 P(0,0,64,64,K);P(8,0,8,8,H);P(0,8,32,8,K);P(0,8,32,2,H);P(0,10,4,2,H);P(20,10,4,2,H);P(24,8,8,8,H);P(8,9,2,1,H);P(14,9,2,1,H);
 P(9,12,1,1,[240,240,240]);P(10,12,1,1,[70,50,150]);P(13,12,1,1,[70,50,150]);P(14,12,1,1,[240,240,240]);P(11,13,2,1,[170,118,88]);P(10,14,4,1,[120,70,58]);P(9,15,6,1,[92,60,42]);
 P(16,20,24,12,T);P(20,16,16,4,T);P(22,20,4,1,K);
 P(44,16,4,4,T);P(48,16,4,4,K);P(40,20,16,4,T);P(40,24,16,8,K);
 P(4,16,4,4,Pn);P(8,16,4,4,Sh);P(0,20,16,10,Pn);P(0,30,16,2,Sh);P(20,48,4,4,Pn);P(24,48,4,4,Sh);P(16,52,16,10,Pn);P(16,62,16,2,Sh);P(36,48,4,4,T);P(40,48,4,4,K);P(32,52,16,4,T);P(32,56,16,8,K);
 STC=c;const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.magFilter=THREE.NearestFilter;t.anisotropy=AN;return t}
const U=1.8/32,SM=new THREE.MeshStandardMaterial({map:steveTex(),roughness:.85});SM.onBeforeCompile=s=>{s.fragmentShader='#define NO_BCAP\n'+s.fragmentShader};SM.customProgramCacheKey=()=>'steve';
function mcg(w,h,d,ox,oy,piv,P){const g=new THREE.BoxGeometry(w*U,h*U,d*U),uv=g.attributes.uv;
 [[ox,oy+d,d,h],[ox+d+w,oy+d,d,h],[ox+d,oy,w,d],[ox+d+w,oy,w,d],[ox+2*d+w,oy+d,w,h],[ox+d,oy+d,w,h]].forEach(([x,y,a,b],f)=>{if(P!==undefined&&(f<2||f>3))y+=P*h;const u0=x/64,u1=(x+a)/64,v1=1-y/64,v0=1-(y+b)/64;uv.setXY(f*4,u0,v1);uv.setXY(f*4+1,u1,v1);uv.setXY(f*4+2,u0,v0);uv.setXY(f*4+3,u1,v0)});
 if(piv)g.translate(0,-h*U/2,0);return g}
function mcb(w,h,d,ox,oy,piv,P){const m=new THREE.Mesh(mcg(w,h,d,ox,oy,piv,P),SM);m.receiveShadow=true;return m}
const stv=new THREE.Group(),spine=new THREE.Group(),sp2=(w,x,y)=>{const u=mcb(w,6,4,x,y,1,0),l=mcb(w,6,4,x,y,1,1);l.position.y=-6*U;u.add(l);u.userData.f=l;return u},
torso=mcb(8,12,4,16,16),head=mcb(8,8,8,0,0),aR=sp2(4,40,16),aL=sp2(4,32,48),lR=sp2(4,0,16),lL=sp2(4,16,48),aRf=aR.userData.f,aLf=aL.userData.f,lRf=lR.userData.f,lLf=lL.userData.f;
spine.position.y=12*U;torso.position.y=6*U;head.position.y=16*U;aR.position.set(6*U,12*U,0);aL.position.set(-6*U,12*U,0);lR.position.set(2*U,12*U,0);lL.position.set(-2*U,12*U,0);
spine.add(torso,head,aR,aL);stv.add(spine,lR,lL);S.add(stv);head.rotation.order='YXZ';
const byd={lean:0,yaw:0,ph:0,amp:0,sw:0,hx:null,hz:0},cpd=[[torso,0,.28,0,0,-.28,0,.19],[head,0,.05,0,0,-.05,0,.23],[aR,0,-.1,0,0,-.58,0,.1],[aL,0,-.1,0,0,-.58,0,.1],[lR,0,-.12,0,0,-.58,0,.105],[lL,0,-.12,0,0,-.58,0,.105]],tv=new THREE.Vector3(),f3=new THREE.Vector3(),u3=new THREE.Vector3(),_he=new THREE.Euler(0,0,0,'YXZ'),_hl=new THREE.Quaternion(),_hp=new THREE.Quaternion(),_hs=new THREE.Quaternion(),_up=new THREE.Vector3(0,1,0);
let tp=false,tpd=2.6;const camBase=new THREE.Vector3();
let _t0=0,_t1=0;
function _sl(o,d,a,b){if(Math.abs(d)<1e-7)return o>a&&o<b;let u=(a-o)/d,v=(b-o)/d;if(u>v){const w=u;u=v;v=w}if(u>_t0)_t0=u;if(v<_t1)_t1=v;return _t0<=_t1}
function rayBlock(ox,oy,oz,dx,dy,dz,L,m){let best=L;
 const f=c=>{if(c.off)return;const x0=c[0]-m,x1=c[1]+m,y0=(c[5]||0)-m,y1=(c[4]||2.8)+m,z0=c[2]-m,z1=c[3]+m;
  if(ox>x0&&ox<x1&&oy>y0&&oy<y1&&oz>z0&&oz<z1)return;
  _t0=0;_t1=best;if(_sl(ox,dx,x0,x1)&&_sl(oy,dy,y0,y1)&&_sl(oz,dz,z0,z1)&&_t0<best)best=_t0};
 cols.forEach(f);dcols.forEach(f);dlt.forEach(f);return best}
function tpBlocked(h){const o=ray.ray.origin,d=ray.ray.direction,L=Math.max(0,h.distance-.3);return rayBlock(o.x,o.y,o.z,d.x,d.y,d.z,L,0)<L-.001}
function tpCam(dt){if(!tp){camBase.copy(home);return}
 f3.set(0,0,-1).applyQuaternion(fq);const py=1.55,L=2.6;let t=L;
 if(py-f3.y*L<.12)t=Math.min(t,(py-.12)/f3.y);else if(py-f3.y*L>2.65)t=Math.min(t,(2.65-py)/-f3.y);
 t=Math.max(.05,Math.min(t,rayBlock(home.x,py,home.z,-f3.x,-f3.y,-f3.z,L,.2)));
 tpd=t<tpd?t:tpd+(t-tpd)*Math.min(1,dt*5);camBase.set(home.x-f3.x*tpd,py-f3.y*tpd,home.z-f3.z*tpd)}
$('tp').onclick=()=>{if(zoomed)zoom(false);const c=byd.cy||0;tp=!tp;$('tp').textContent=tp?'👁':'🧍';
 if(tp){eu.setFromQuaternion(fq,'YXZ');yaw=eu.y;pitch=Math.max(-1.2,Math.min(.9,eu.x));tpd=2.6}
 else if(hasGyro&&gyroOn){eu.setFromQuaternion(devQ,'YXZ');yaw=c-eu.y;pitch=0}};
function bodyTick(dt){f3.set(0,0,-1).applyQuaternion(fq);let hx=f3.x,hz=f3.z;if(hx*hx+hz*hz<.04){u3.set(0,1,0).applyQuaternion(fq);const s=f3.y<0?1:-1;hx=u3.x*s;hz=u3.z*s}
 const cy=Math.atan2(-hx,-hz);byd.cy=cy;if(byd.hx===null){byd.hx=home.x;byd.hz=home.z;byd.yaw=cy}
 const mx=home.x-byd.hx,mz=home.z-byd.hz,sp=Math.hypot(mx,mz)/Math.max(dt,1e-3);byd.hx=home.x;byd.hz=home.z;
 byd.amp+=(Math.min(1.5,sp/1.7)-byd.amp)*Math.min(1,dt*10);byd.ph+=sp*dt*4.2;
 let d=(tp?(sp>.15?Math.atan2(-mx,-mz):byd.yaw):cy)-byd.yaw;d=Math.atan2(Math.sin(d),Math.cos(d));const k=Math.min(1,dt*(tp?12:9));
 if(sp>.15)byd.yaw+=d*k;else if(!tp&&Math.abs(d)>.9)byd.yaw+=(d-Math.sign(d)*.9)*k;
 if(ARM){let bz=ARM.yw-byd.yaw;byd.yaw+=Math.atan2(Math.sin(bz),Math.cos(bz))*Math.min(1,dt*10)}const o=tp?0:.14;stv.position.set(home.x+Math.sin(byd.yaw)*o,0,home.z+Math.cos(byd.yaw)*o);stv.rotation.y=byd.yaw;
 const a=byd.amp,ph=byd.ph,w=a*.8,fL=ph+Math.PI,gt=f=>Math.sin(f)+.22*Math.sin(2*f+.6),kn=f=>{const c=Math.max(0,Math.cos(f-.35));return .1+c*c*1.05},p=byd.sw>0?Math.sin(Math.PI*(1-byd.sw/.35)):0,br=Math.sin(performance.now()*.0017)*.012;byd.sw=Math.max(0,byd.sw-dt);
 byd.lean+=(Math.min(1,a)*.12-byd.lean)*Math.min(1,dt*6);
 lR.rotation.x=gt(ph)*w;lL.rotation.x=gt(fL)*w;lRf.rotation.x=-kn(ph)*a;lLf.rotation.x=-kn(fL)*a;
 aL.rotation.x=.1+gt(ph-.45)*w;aR.rotation.x=.1+gt(fL-.45)*w+p*1.5;
 aLf.rotation.x=.2+a*(.25+.3*Math.sin(ph+1.2));aRf.rotation.x=.2+a*(.25+.3*Math.sin(fL+1.2))+p*.9;
 aR.rotation.z=.05+a*.05*Math.sin(ph);aL.rotation.z=-.05+a*.05*Math.sin(ph);
 spine.rotation.set(byd.lean+br,-Math.sin(ph)*.14*a,Math.cos(ph)*.05*a);
  if(ARM&&ARM.ak>.003){const ar=ARM.arm;ar.parent.updateMatrixWorld(true);ARM.lv.getWorldPosition(tv);ar.parent.worldToLocal(tv);tv.y-=ARM.tn*.07;tv.sub(ar.position);const l=tv.length();if(l>1e-3){_qa.setFromUnitVectors(_dn,tv.divideScalar(l));_qb.setFromEuler(ar.rotation);ar.quaternion.copy(_qb).slerp(_qa,ARM.ak)}}
 head.visible=tp?tpd>.6:zk>.45;
 _he.setFromQuaternion(fq,'YXZ');_he.z=0;_hl.setFromEuler(_he);_hp.setFromAxisAngle(_up,byd.yaw).multiply(_hs.setFromEuler(spine.rotation));head.quaternion.copy(_hp.invert()).multiply(_hl)}
function bodyCaps(){stv.updateMatrixWorld(true);cam.matrixWorldInverse.copy(cam.matrixWorld).invert();const a=BCU.value;
 cpd.forEach((c,i)=>{const o=c[0];tv.set(c[1],c[2],c[3]).applyMatrix4(o.matrixWorld).applyMatrix4(cam.matrixWorldInverse);a[i*8]=tv.x;a[i*8+1]=tv.y;a[i*8+2]=tv.z;a[i*8+3]=c[7];
  tv.set(c[4],c[5],c[6]).applyMatrix4(o.matrixWorld).applyMatrix4(cam.matrixWorldInverse);a[i*8+4]=tv.x;a[i*8+5]=tv.y;a[i*8+6]=tv.z});
 tv.set(stv.position.x,.9,stv.position.z).applyMatrix4(cam.matrixWorldInverse);BBU.value.set(tv.x,tv.y,tv.z,1)}
