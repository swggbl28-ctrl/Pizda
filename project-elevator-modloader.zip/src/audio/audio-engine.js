//# FILE: audio/audio-engine.js
//# ЧТО: ЗВУКИ: процедурный WebAudio — реверб, шторм, ветер, гул ламп, шаги (20 вариантов), гром, стекло, удары, кнопки магнитофона. Всё синтезируется кодом, аудиофайлов нет.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: AC, playing, auRnd, aGn, aBq, aLoop, aOut, aBn, aTn, mkNoise, mkIR, mkRain, mkSteps, initAudio, startEnv, envLevel, envTick, evTick, creak, thud, flick, thunder, crash, footstep, breath, hitSnd, uiSnd, thunderLater, t0, strike…
// ---------- audio (procedural: reverb, layered storm ambience, foley) ----------
let AC,master,musicG,ambG,thG,musicEl,ambEl,noiseBuf,thVol=1,sfxG,rev,envG,humG,tapeG,rainG,rainG2,windG,windF,whisG,whF,pinkB,brownB,rainB,bedG,stepB,lastStep=-1,ambOwn=false,gust=0,wl=.5,rl=.6,sdist=0,stepSide=0;
const playing=()=>musicEl&&!musicEl.paused&&!musicEl.ended;
const auRnd=(a,b)=>a+Math.random()*(b-a);
const aGn=v=>{const g=AC.createGain();g.gain.value=v;return g};
const aBq=(ty,f,q)=>{const n=AC.createBiquadFilter();n.type=ty;n.frequency.value=f;if(q)n.Q.value=q;return n};
function aLoop(b,rate,off){const s=AC.createBufferSource();s.buffer=b;s.loop=true;s.playbackRate.value=rate||1;s.start(0,off||0);return s}
function aOut(n,pan,send,dest){let o=n;if(pan){const p=AC.createStereoPanner();p.pan.value=pan;o.connect(p);o=p}o.connect(dest||sfxG);
 if(send){const w=dest===envG&&envG?Math.min(1,envG.gain.value/.8):1,s=aGn(send*w);o.connect(s);s.connect(rev)}}
function aBn(o){const t=o.t==null?AC.currentTime:o.t,s=AC.createBufferSource(),f=aBq(o.type||'bandpass',o.f,o.q||1),g=aGn(0),a=o.a||.003;s.buffer=o.buf||pinkB;
 f.frequency.setValueAtTime(o.f,t);if(o.f2)f.frequency.exponentialRampToValueAtTime(o.f2,t+a+o.d);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(o.g,t+a);g.gain.exponentialRampToValueAtTime(.0005,t+a+o.d);
 s.connect(f);f.connect(g);aOut(g,o.pan,o.send,o.dest);s.start(t,auRnd(0,6));s.stop(t+a+o.d+.05)}
function aTn(o){const t=o.t==null?AC.currentTime:o.t,s=AC.createOscillator(),g=aGn(0),a=o.a||.002;s.type=o.type||'sine';s.frequency.setValueAtTime(o.f,t);if(o.f2)s.frequency.exponentialRampToValueAtTime(o.f2,t+a+o.d);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(o.g,t+a);g.gain.exponentialRampToValueAtTime(.0005,t+a+o.d);
 s.connect(g);aOut(g,o.pan,o.send,o.dest);s.start(t);s.stop(t+a+o.d+.05)}
function mkNoise(sec,br){const sr=AC.sampleRate,N=sr*sec|0,X=sr*.25|0,b=AC.createBuffer(2,N,sr);
 for(let c=0;c<2;c++){const d=b.getChannelData(c),g=new Float32Array(N+X);let b0=0,b1=0,b2=0,b3=0,b4=0,b5=0,b6=0,l=0;
  for(let i=0;i<N+X;i++){const w=Math.random()*2-1;
   if(br){l=(l+.02*w)/1.02;g[i]=l*3.5}else{b0=.99886*b0+w*.0555179;b1=.99332*b1+w*.0750759;b2=.969*b2+w*.153852;b3=.8665*b3+w*.3104856;b4=.55*b4+w*.5329522;b5=-.7616*b5-w*.016898;g[i]=(b0+b1+b2+b3+b4+b5+b6+w*.5362)*.11;b6=w*.115926}}
  for(let i=0;i<N;i++)d[i]=i<X?g[i]*Math.sqrt(i/X)+g[N+i]*Math.sqrt(1-i/X):g[i]}
 return b}
function mkIR(rt,pre){const sr=AC.sampleRate,L=sr*rt*1.15|0,P=sr*pre|0,b=AC.createBuffer(2,L,sr);
 for(let c=0;c<2;c++){const d=b.getChannelData(c);let lp=0;
  for(let i=P;i<L;i++){const t=(i-P)/sr,a=Math.min(.93,.45+t*.35);lp=lp*a+(Math.random()*2-1)*(1-a);d[i]=lp*Math.pow(10,-3*t/rt)*Math.min(1,(i-P)/(sr*.004))*2.2}
  for(let k=0;k<10;k++){const i=P+(sr*(.004+k*.007+Math.random()*.006)|0);if(i<L)d[i]+=(Math.random()<.5?-1:1)*(.5-k*.04)}}
 return b}
// далёкий дождь за стенами: только шум (морось из тысяч крошечных капель), без отдельных капель и тональных звуков, бесшовный цикл
function mkRain(){const sr=AC.sampleRate,N=sr*12|0,b=AC.createBuffer(2,N,sr);
 for(let c=0;c<2;c++){const d=b.getChannelData(c);
  for(let k=0;k<13000;k++){const i0=Math.random()*N|0,A=.05+.25*Math.random()*Math.random(),L=sr*auRnd(.002,.007)|0,lc=auRnd(.25,.7),dec=L/3;let lp=0;
   for(let j=0;j<L;j++){lp+=lc*((Math.random()*2-1)-lp);d[(i0+j)%N]+=A*lp*Math.exp(-j/dec)*Math.min(1,j/8)}}
 }
 return b}
// 20 вариантов глухого топота: каждый шаг = один случайный из них
function mkSteps(){const sr=AC.sampleRate,L=sr*.3|0,TP=6.2831853,out=[];
 for(let n=0;n<20;n++){const b=AC.createBuffer(1,L,sr),d=b.getChannelData(0),f0=auRnd(62,98),f1=f0*auRnd(.55,.75),dk=sr*auRnd(.03,.055),lc=auRnd(.03,.08),nz=auRnd(3,7),t2=sr*auRnd(.055,.11)|0,a2=auRnd(.25,.55),nA=new Float32Array(L);let lp=0,pk=0;
  for(let i=0;i<L;i++){lp+=lc*((Math.random()*2-1)-lp);nA[i]=lp*nz}
  const imp=j=>{if(j<0)return 0;const t=j/sr;return(Math.sin(TP*(f1*t+(f0-f1)/40*(1-Math.exp(-40*t))))*.8+nA[j]*.5)*Math.exp(-j/dk)*Math.min(1,j/(sr*.003))};
  for(let i=0;i<L;i++){d[i]=imp(i)+a2*imp(i-t2);pk=Math.max(pk,Math.abs(d[i]))}
  for(let i=0;i<L;i++)d[i]=d[i]/pk*Math.min(1,(L-i)/(sr*.02));
  out.push(b)}
 return out}
function initAudio(){if(AC){AC.resume();return}AC=new(window.AudioContext||window.webkitAudioContext)();
 master=AC.createGain();master.gain.value=.9;const cp=AC.createDynamicsCompressor();cp.threshold.value=-16;cp.knee.value=18;cp.ratio.value=5;cp.attack.value=.004;cp.release.value=.3;master.connect(cp);cp.connect(AC.destination);
 sfxG=aGn(1);sfxG.connect(master);
 rev=AC.createConvolver();rev.buffer=mkIR(1.5,.012);const rg=aGn(.8);rev.connect(rg);rg.connect(master);
 musicEl=new Audio();musicG=aGn(musicVol);AC.createMediaElementSource(musicEl).connect(musicG);musicG.connect(master);const ms=aGn(.07);musicG.connect(ms);ms.connect(rev);
 ambEl=new Audio();ambEl.loop=true;ambG=aGn(+$('amv').value);AC.createMediaElementSource(ambEl).connect(ambG);ambG.connect(master);
 thG=aGn(thVol);thG.connect(master);const ts=aGn(.4);thG.connect(ts);ts.connect(rev);
 pinkB=mkNoise(10,0);brownB=mkNoise(8,1);noiseBuf=pinkB;rainB=mkRain();stepB=mkSteps();
 startEnv();
 musicEl.onplay=musicEl.onpause=musicEl.onended=()=>{cled.material.emissive.setHex(playing()?0xff2020:0);tapeG.gain.setTargetAtTime(playing()?.0045:0,AC.currentTime,.15);updDisp()}}
function startEnv(){
 envG=aGn(0);envG.connect(master);
 // далёкий тихий дождь за стенами: морось + мягкий фон-«шум воды» + глухой гул
 rainG=aGn(.1);aLoop(rainB,1,0).connect(aBq('lowpass',2400,.5)).connect(aBq('highpass',180)).connect(rainG);rainG.connect(envG);
 rainG2=aGn(.06);aLoop(rainB,.8,5.3).connect(aBq('lowpass',1200,.5)).connect(rainG2);rainG2.connect(envG);
 bedG=aGn(.05);aLoop(pinkB,.9,2).connect(aBq('highpass',250)).connect(aBq('lowpass',1800,.5)).connect(bedG);bedG.connect(envG);
 [[.17,.25],[.043,.2]].forEach(([f,dp])=>{const o=AC.createOscillator();o.frequency.value=f;o.connect(aGn(.05*dp)).connect(bedG.gain);o.start()});
 const rum=aGn(.04);aLoop(brownB,1,1).connect(aBq('lowpass',170)).connect(rum);rum.connect(envG);
 // ветер + свист в щелях рамы
 windF=aBq('bandpass',280,.9);windG=aGn(.08);aLoop(pinkB,.9,5).connect(windF);windF.connect(windG);windG.connect(envG);
 whF=aBq('bandpass',860,22);whisG=aGn(0);aLoop(pinkB,1.1,7).connect(whF);whF.connect(whisG);whisG.connect(envG);
 // гул люминесцентных ламп (100 Гц + гармоники, биения, дроссель)
 humG=aGn(1);const hm=aGn(.008);humG.connect(hm);hm.connect(envG);
 [[100,.5,'sine'],[100.37,.35,'sine'],[200,.22,'sine'],[300,.14,'triangle'],[400,.07,'sine'],[50,.2,'sine']].forEach(([f,v,ty])=>{const o=AC.createOscillator();o.type=ty;o.frequency.value=f;o.connect(aGn(v)).connect(humG);o.start()});
 const bz=aGn(.012);aLoop(pinkB,1.3,4).connect(aBq('bandpass',7200,8)).connect(bz);bz.connect(humG);
 // тон помещения: вентиляция, воздуховод, кулер системника
 const rt=aGn(.05);aLoop(brownB,.7,3).connect(aBq('lowpass',140)).connect(rt);rt.connect(envG);
 const l1=AC.createOscillator();l1.frequency.value=.07;l1.connect(aGn(.025)).connect(rt.gain);l1.start();
 const dc=aGn(.012);aLoop(pinkB,.8,1).connect(aBq('bandpass',1300,.5)).connect(dc);dc.connect(envG);
 const l2=AC.createOscillator();l2.frequency.value=.11;l2.connect(aGn(.006)).connect(dc.gain);l2.start();
 const fo=AC.createOscillator();fo.type='triangle';fo.frequency.value=121;fo.connect(aGn(.0022)).connect(envG);fo.start();
 const fn=aGn(.01);aLoop(pinkB,1.2,6).connect(aBq('bandpass',2600,2.5)).connect(fn);fn.connect(envG);
 // шипение плёнки магнитофона (включается при воспроизведении)
 tapeG=aGn(0);aLoop(pinkB,2,0).connect(aBq('highpass',4500)).connect(tapeG);tapeG.connect(master);
 setInterval(envTick,450);evTick();envLevel()}
function envLevel(){if(!envG)return;envG.gain.setTargetAtTime($('amt').checked?+$('amv').value*1.6*(ambOwn?.4:1):0,AC.currentTime,.15)}
function envTick(){if(!AC||AC.state!=='running')return;const t=AC.currentTime;gust*=.9;
 wl=Math.min(1,Math.max(.1,wl+auRnd(-.18,.18)+(.5-wl)*.08));if(Math.random()<.03)wl=1;rl=Math.min(1,Math.max(.35,rl+auRnd(-.06,.06)+(.6-rl)*.05));
 rainG.gain.setTargetAtTime(.1*(.7+.5*rl+gust*.35),t,.6);rainG2.gain.setTargetAtTime(.06*(.7+.5*rl+gust*.35),t,.6);bedG.gain.setTargetAtTime(.05*(.7+.5*rl+gust*.35),t,.6);
 windG.gain.setTargetAtTime(.015+.09*wl+gust*.03,t,.9);windF.frequency.setTargetAtTime(180+wl*420+auRnd(-30,30),t,.8);
 whF.frequency.setTargetAtTime(700+wl*400,t,.8);whisG.gain.setTargetAtTime(Math.max(0,wl-.55)*.04,t,.7)}
function evTick(){setTimeout(evTick,auRnd(2200,8500));if(!AC||AC.state!=='running'||!envG||envG.gain.value<.01)return;const r=Math.random();
 if(r<.35)creak();else if(r<.65)thud();else if(r<.85)flick();else wl=1}
function creak(){const t=AC.currentTime,D=auRnd(.6,1.6),o=AC.createOscillator(),f=aBq('bandpass',auRnd(350,900),4),g=aGn(0);o.type='sawtooth';o.frequency.setValueAtTime(auRnd(30,50),t);o.frequency.linearRampToValueAtTime(auRnd(20,70),t+D);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.12,t+D*.4);g.gain.linearRampToValueAtTime(0,t+D);o.connect(f);f.connect(g);aOut(g,auRnd(-.8,.8),.5,envG);o.start(t);o.stop(t+D+.05)}
function thud(){const p=auRnd(-.8,.8);aTn({f:62,f2:38,d:.4,g:.22,pan:p,send:.8,dest:envG});aBn({type:'lowpass',f:220,d:.25,g:.3,pan:p,send:.8,dest:envG})}
function flick(){if(!AC||!humG)return;const t=AC.currentTime;humG.gain.cancelScheduledValues(t);humG.gain.setValueAtTime(1,t);
 for(let i=0;i<4;i++){humG.gain.setValueAtTime(auRnd(.1,.5),t+i*.07);humG.gain.setValueAtTime(1.4,t+i*.07+.035)}humG.gain.setTargetAtTime(1,t+.3,.1);
 for(let i=0;i<3;i++)aBn({t:t+i*.07,type:'highpass',f:4000,d:.01,g:.08,pan:auRnd(-.5,.5),dest:envG})}
// гром: трескучий разряд + перекатывающийся рокот + суббас + дребезг стекла; d: 0 рядом … 1 далеко
function thunder(d){if(!AC||AC.state!=='running')return;d=d==null?.5:d;const t=AC.currentTime,nr=1-d,D=2.8+d*5,fl=thG;gust=Math.max(gust,.5+nr);
 if(nr>.25){aBn({t,f:5200,f2:600,q:.5,a:.0008,d:.1+nr*.12,g:3.2*nr*nr,dest:fl,pan:auRnd(-.5,.5)});
  for(let i=0;i<6;i++)aBn({t:t+auRnd(.03,.45),f:auRnd(1200,4200),f2:250,q:.8,d:auRnd(.06,.2),g:auRnd(.4,1.3)*nr,dest:fl,pan:auRnd(-.8,.8)})}
 const s=aLoop(pinkB,auRnd(.85,1.05),auRnd(0,7)),f=aBq('lowpass',720-d*470,.8),g=aGn(0),p=AC.createStereoPanner(),pk=.7+nr*1.6,a=auRnd(-.6,.6);
 f.frequency.setValueAtTime(720-d*470,t);f.frequency.exponentialRampToValueAtTime(42,t+D);
 g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(pk,t+.04+d*.7);
 for(let x=.2+d*.7;x<D;x+=auRnd(.1,.4))g.gain.setTargetAtTime(pk*Math.exp(-x/D*3)*auRnd(.3,1.15),t+x,.1);
 g.gain.setTargetAtTime(0,t+D*.8,.5);p.pan.setValueAtTime(a,t);p.pan.linearRampToValueAtTime(-a*.5,t+D);
 s.connect(f);f.connect(g);g.connect(p);p.connect(fl);s.stop(t+D+3);
 aTn({t,f:60,f2:30,d:2.2+nr,g:.5+nr*.7,a:.03,dest:fl});if(nr>.2)aTn({t,f:90,f2:45,d:.6,g:.8*nr,a:.005,dest:fl});
 if(nr>.35){for(let i=0;i<7;i++)aBn({t:t+.15+i*auRnd(.06,.14),f:auRnd(170,330),q:10,d:.14,g:3*nr,pan:auRnd(-.7,.7),send:.2,dest:fl});aBn({t:t+.2,type:'highpass',f:5000,d:.5,g:.04*nr,pan:auRnd(-.6,.6),dest:fl})}}
// разбитое стекло: удар, осколки-звоны по всему спектру, хвост
function crash(){if(!AC)return;const t=AC.currentTime;aBn({t,type:'highpass',f:2500,q:.7,a:.0008,d:.12,g:1,send:.4});aTn({t,f:140,f2:60,d:.2,g:.5});
 for(let i=0;i<46;i++){const x=Math.pow(Math.random(),1.8)*1.3,p=auRnd(-.8,.8);aTn({t:t+.01+x,f:auRnd(2200,9500),d:auRnd(.05,.28),g:auRnd(.04,.16)*(1-x/1.8),pan:p,send:.35,a:.001});
  if(i%3==0)aBn({t:t+.01+x,f:auRnd(3000,8000),q:auRnd(8,30),d:auRnd(.04,.15),g:.5,pan:p,send:.3})}}
// глухой еле слышный топот: один шаг = один случайный из 20 сэмплов
function footstep(run,m){const sd=(stepSide^=1)?-.15:.15,v=(run?1.4:1)*(.55+.45*Math.min(1,m));let i;do{i=Math.random()*20|0}while(i===lastStep);lastStep=i;
 const s=AC.createBufferSource(),g=aGn(.06*v*auRnd(.8,1.15));s.buffer=stepB[i];s.playbackRate.value=auRnd(.93,1.07);s.connect(g);aOut(g,sd,.12);s.start();
 if(run&&stam<40&&(stepSide&1))breath()}
function breath(){const t=AC.currentTime;aBn({t,f:1500,q:.9,a:.22,d:.32,g:.35,send:.15,pan:-.1});aBn({t:t+.5,f:950,q:.8,a:.1,d:.5,g:.3,send:.15,pan:.1})}
// удар по предмету: масса → высота и вес удара; стекло → звон
function hitSnd(m,gl){if(!AC)return;const k=Math.min(2.2,Math.max(.4,m||1)),p=auRnd(-.3,.3);
 if(gl){const f=auRnd(2200,3600);aTn({f,d:.5,g:.18,pan:p,send:.3});aTn({f:f*2.32,d:.3,g:.08,pan:p,send:.3});aTn({f:f*3.9,d:.2,g:.04,pan:p});aBn({type:'highpass',f:3000,d:.02,g:.25,pan:p,send:.3});return}
 const f=auRnd(90,170)/Math.sqrt(k);aTn({f:f*1.4,f2:f,d:.12,g:.4*Math.sqrt(k),pan:p,send:.15});aBn({type:'lowpass',f:auRnd(500,1200),d:.07,g:.9*k,pan:p});
 aBn({f:auRnd(1500,3200),q:2,d:.04,g:.5,pan:p,send:.2});aTn({t:AC.currentTime+.01,f:auRnd(220,520),d:.08,g:.07,type:'triangle',pan:p,send:.2})}
// кнопки магнитофона и выключатель монитора
function uiSnd(a){if(!AC)return;const t=AC.currentTime;
 if(a==='power'){aBn({t,f:1800,q:2,d:.02,g:1.2,send:.2});aTn({t,f:140,f2:90,d:.07,g:.3});aBn({t:t+.06,f:2600,q:3,d:.015,g:.6});aTn({t:t+.08,f:7800,f2:5200,d:.4,g:.012,type:'sine',send:.3})}
 else if(a==='vm'||a==='vp'){aBn({t,f:2400,q:2,d:.018,g:.9,send:.1});aTn({t,f:220,f2:150,d:.04,g:.15})}
 else{aBn({t,f:900,q:1.2,d:.035,g:1.6,send:.15});aTn({t,f:180,f2:110,d:.06,g:.35});aBn({t:t+.09,f:2200,q:2,d:.02,g:.9});
  if(a==='play'||a==='load')aBn({t:t+.05,f:300,f2:700,q:3,a:.2,d:.5,g:.6,send:.1});if(a==='stop'||a==='pause')aTn({t:t+.04,f:110,f2:70,d:.08,g:.25})}}
function thunderLater(d){setTimeout(()=>thunder(d),(.1+d*2.6)*1000)}
let t0=-1e9,next=performance.now()+5000;
function strike(d=Math.pow(Math.random(),.7)){t0=performance.now();initAudio();flick();thunderLater(d)}
function flashEnv(){const d=(performance.now()-t0)/1000;if(d<.08)return 1;if(d<.14)return .15;if(d<.22)return .95;if(d<.3)return .3;return Math.max(0,.9*Math.exp(-(d-.3)*5))}
function updDisp(){const g=dg;g.fillStyle='#10200f';g.fillRect(0,0,256,64);g.fillStyle='#7f7';g.font='16px monospace';g.fillText((playing()?'▶ ':'■ ')+(trackName||'NO TAPE').slice(0,22),6,22);const t=musicEl?musicEl.currentTime|0:0;g.fillText((t/60|0)+':'+String(t%60).padStart(2,'0'),6,50);for(let i=0;i<10;i++){g.fillStyle=i<musicVol*10-.01?'#7f7':'#243';g.fillRect(120+i*12,38,9,14)}dT.needsUpdate=true}
setInterval(updDisp,500);updDisp();
