//# FILE: audio/elevator-sounds.js
//# ЧТО: ЗВУКИ лифта: скрип, двери, кнопка (elCreak/elDoor/elBtn).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: elCreak, elDing, elDoor, elBtn
// --- audio: reusable creaky mechanical sounds ---
function elCreak(dur,vol=.3){if(!AC)return;const t=AC.currentTime,k=vol/.3;
 [[46,.35],[92,.5],[138,.25],[184,.1]].forEach(([f,a])=>{const o=AC.createOscillator(),g=aGn(0);o.type='sine';o.frequency.setValueAtTime(f*.88,t);o.frequency.linearRampToValueAtTime(f,t+1.4);o.frequency.setValueAtTime(f,t+dur-1.4);o.frequency.linearRampToValueAtTime(f*.88,t+dur);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.1*a*k,t+.9);g.gain.setValueAtTime(.1*a*k,t+dur-.9);g.gain.linearRampToValueAtTime(0,t+dur);o.connect(g);aOut(g,0,.25);o.start(t);o.stop(t+dur+.1)});
 aBn({t,type:'lowpass',f:240,q:.5,a:1,d:dur,g:.22*k,send:.3});
 aBn({t,type:'bandpass',f:700,q:.8,a:1.2,d:dur,g:.03*k,send:.4});
 for(let u=.6;u<dur-.3;u+=1.1+Math.random()*1.2)aBn({t:t+u,type:'bandpass',f:500+Math.random()*300,q:1.5,a:.002,d:.07,g:.05*k,send:.4,pan:Math.random()*.4-.2});
 aTn({t:t+.1,f:75,f2:48,d:.35,g:.22*k,send:.4})}
function elDing(){if(!AC)return;const t=AC.currentTime;aTn({t,f:880,d:2.2,g:.12,send:.7});aTn({t,f:1760,d:1.2,g:.04,send:.7});aTn({t,f:2430,d:.5,g:.015,send:.6});aBn({t,type:'highpass',f:3000,q:.7,a:.001,d:.03,g:.04,send:.3})}
function elDoor(open,dur){if(!AC)return;const t=AC.currentTime;aBn({t,type:'lowpass',f:420,q:.6,a:.35,d:dur,g:.16,send:.4});aBn({t,type:'bandpass',f:1300,q:1.2,a:.5,d:dur*.8,g:.035,send:.3});aTn({t,f:55,f2:70,d:dur,g:.05,type:'sine',send:.3});
 aTn({t:t+dur*.92,f:82,f2:52,d:.28,g:.26,send:.5});aBn({t:t+dur*.92,type:'lowpass',f:700,a:.002,d:.14,g:.18,send:.4});aBn({t:t+dur*.92,type:'bandpass',f:2200,q:3,a:.001,d:.05,g:.04,send:.4})}
function elBtn(){if(!AC)return;aTn({f:1500,f2:900,d:.04,g:.12});aBn({type:'highpass',f:2500,a:.001,d:.04,g:.12})}
