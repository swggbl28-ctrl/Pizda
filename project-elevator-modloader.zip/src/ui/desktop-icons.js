//# FILE: ui/desktop-icons.js
//# ЧТО: Векторные иконки рабочего стола ПК и их клики.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: icoFloppy, icoVideo, icoSkin, drawIcon, drawWall, taskbar, drawScreen, screenTap
// ---------- desktop icons (vector) ----------
function icoFloppy(g,x,y,s){const k=s/140;g.save();g.translate(x,y);g.scale(k,k);g.shadowColor='rgba(0,0,0,.55)';g.shadowBlur=18;g.shadowOffsetY=8;
 let q=g.createLinearGradient(0,0,0,140);q.addColorStop(0,'#3b82e0');q.addColorStop(1,'#1a478f');g.fillStyle=q;g.beginPath();g.moveTo(14,6);g.lineTo(112,6);g.lineTo(134,28);g.lineTo(134,126);g.quadraticCurveTo(134,134,126,134);g.lineTo(14,134);g.quadraticCurveTo(6,134,6,126);g.lineTo(6,14);g.quadraticCurveTo(6,6,14,6);g.fill();g.shadowColor='transparent';
 q=g.createLinearGradient(0,6,0,52);q.addColorStop(0,'#f4f6f8');q.addColorStop(1,'#a9b0b8');g.fillStyle=q;g.fillRect(34,6,70,46);g.fillStyle='#2a2f38';g.fillRect(80,14,16,30);g.fillStyle='rgba(255,255,255,.5)';g.fillRect(80,14,16,3);
 g.fillStyle='#f6f3e8';g.fillRect(20,66,100,62);g.fillStyle='#d6322e';g.fillRect(20,66,100,12);g.fillStyle='#8a93a6';[88,100,112].forEach(yy=>g.fillRect(28,yy,84,3));
 q=g.createLinearGradient(0,6,0,70);q.addColorStop(0,'rgba(255,255,255,.35)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(6,6,128,64);g.restore()}
function icoVideo(g,x,y,s){const k=s/140;g.save();g.translate(x,y);g.scale(k,k);g.shadowColor='rgba(0,0,0,.55)';g.shadowBlur=18;g.shadowOffsetY=8;
 let q=g.createLinearGradient(0,0,0,140);q.addColorStop(0,'#3a3f4b');q.addColorStop(1,'#14161c');g.fillStyle=q;g.beginPath();g.roundRect(4,16,132,108,16);g.fill();g.shadowColor='transparent';
 g.fillStyle='#e9ecf1';for(let i=0;i<7;i++){g.beginPath();g.roundRect(10,24+i*14.5,9,8,2);g.fill();g.beginPath();g.roundRect(121,24+i*14.5,9,8,2);g.fill()}
 q=g.createLinearGradient(0,26,0,114);q.addColorStop(0,'#ff8a3d');q.addColorStop(1,'#e0301e');g.fillStyle=q;g.beginPath();g.roundRect(26,26,88,88,8);g.fill();
 g.fillStyle='rgba(255,255,255,.95)';g.beginPath();g.arc(70,70,28,0,6.3);g.fill();g.fillStyle='#e0301e';g.beginPath();g.moveTo(62,56);g.lineTo(62,84);g.lineTo(86,70);g.closePath();g.fill();
 q=g.createLinearGradient(0,16,0,70);q.addColorStop(0,'rgba(255,255,255,.25)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.beginPath();g.roundRect(4,16,132,54,16);g.fill();g.restore()}
function icoSkin(g,x,y,s){const k=s/140;g.save();g.translate(x,y);g.scale(k,k);const cv=SKS>=0&&SKL[SKS]?SKL[SKS].cv:STC,r=g.createRadialGradient(70,70,10,70,70,70);r.addColorStop(0,'rgba(120,230,120,.5)');r.addColorStop(1,'rgba(120,230,120,0)');g.fillStyle=r;g.fillRect(0,0,140,140);
 const L=56,c=.866,A=[c*L,.5*L],B=[c*L,-.5*L],C=[0,L],P=[70-c*L,70-L/2];g.shadowColor='rgba(0,0,0,.5)';g.shadowBlur=16;g.shadowOffsetY=8;g.imageSmoothingEnabled=false;
 const face=(o,u,v,sx,sy,shade)=>{g.save();g.transform(u[0]/8,u[1]/8,v[0]/8,v[1]/8,o[0],o[1]);g.drawImage(cv,sx,sy,8,8,0,0,8,8);g.fillStyle=shade;g.fillRect(0,0,8,8);g.restore();g.shadowColor='transparent'};
 face(P,A,C,8,8,'rgba(0,0,0,0)');face([P[0]+A[0],P[1]+A[1]],B,C,16,8,'rgba(0,0,0,.38)');face(P,A,B,8,0,'rgba(255,255,255,.18)');
 g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=1.5;g.beginPath();g.moveTo(P[0]+A[0],P[1]+A[1]);g.lineTo(P[0]+A[0],P[1]+A[1]+L);g.moveTo(P[0],P[1]);g.lineTo(P[0]+A[0],P[1]+A[1]);g.lineTo(P[0]+A[0]+B[0],P[1]+A[1]+B[1]);g.stroke();g.imageSmoothingEnabled=true;g.restore()}
function drawIcon(g,id,l,x,y){({video:icoVideo,emu:icoFloppy,skin:icoSkin,wall:icoWall})[id](g,x,y,140);g.save();g.textAlign='center';g.font='bold 24px sans-serif';g.shadowColor='rgba(0,0,0,.8)';g.shadowBlur=6;g.shadowOffsetY=2;g.fillStyle='#fff';g.fillText(l,x+70,y+176);g.restore()}
function drawWall(g){const W=SW,H=SH-40;let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#2a78d6');q.addColorStop(.55,'#8cc4f0');q.addColorStop(1,'#d9efff');g.fillStyle=q;g.fillRect(0,0,W,H);
 const r=g.createRadialGradient(760,110,0,760,110,300);r.addColorStop(0,'rgba(255,255,230,.8)');r.addColorStop(1,'rgba(255,255,230,0)');g.fillStyle=r;g.fillRect(0,0,W,H);
 for(let i=0;i<7;i++){const cx=120+i*150,cy=70+(i*37%90);g.fillStyle='rgba(255,255,255,.55)';[[0,0,60,22],[40,8,48,18],[-40,10,44,16]].forEach(([dx,dy,rx,ry])=>{g.beginPath();g.ellipse(cx+dx,cy+dy,rx,ry,0,0,6.3);g.fill()})}
 q=g.createLinearGradient(0,260,0,H);q.addColorStop(0,'#6fc64a');q.addColorStop(1,'#2d7a22');g.fillStyle=q;g.beginPath();g.moveTo(0,330);g.bezierCurveTo(250,230,520,300,W*.6,290);g.bezierCurveTo(W*.8,280,W*.9,250,W,270);g.lineTo(W,H);g.lineTo(0,H);g.fill();
 q=g.createLinearGradient(0,330,0,H);q.addColorStop(0,'#58b03a');q.addColorStop(1,'#1f5e1a');g.fillStyle=q;g.beginPath();g.moveTo(0,420);g.bezierCurveTo(300,340,620,450,W,380);g.lineTo(W,H);g.lineTo(0,H);g.fill()}
function taskbar(g){const y=SH-40;let q=g.createLinearGradient(0,y,0,y+36);q.addColorStop(0,'#4fae4a');q.addColorStop(1,'#2a7a2a');g.fillStyle=q;rr(6,y+4,170,32,16);g.fill();
 [['#f25022',16,y+9],['#7fba00',27,y+9],['#00a4ef',16,y+20],['#ffb900',27,y+20]].forEach(([c,a,b])=>{g.fillStyle=c;g.fillRect(a,b,9,9)});g.fillStyle='#fff';g.font='bold 19px sans-serif';g.fillText('Рабочий стол',46,y+27);
 g.fillStyle='#3b4150';rr(186,y+4,60,32,6);g.fill();g.fillStyle='#fff';if(vid.paused){g.beginPath();g.moveTo(206,y+11);g.lineTo(206,y+29);g.lineTo(224,y+20);g.fill()}else{g.fillRect(205,y+11,6,18);g.fillRect(217,y+11,6,18)}
 g.strokeStyle='#cfd6e6';g.lineWidth=2.5;g.lineCap='round';[6,11,16].forEach(r=>{g.beginPath();g.arc(SW-176,y+30,r,-2.3,-.85);g.stroke()});g.lineCap='butt';g.fillStyle='#cfd6e6';g.beginPath();g.arc(SW-176,y+30,2,0,6.3);g.fill();
 g.beginPath();g.moveTo(SW-146,y+16);g.lineTo(SW-140,y+16);g.lineTo(SW-132,y+10);g.lineTo(SW-132,y+30);g.lineTo(SW-140,y+24);g.lineTo(SW-146,y+24);g.closePath();g.fill();g.font='20px sans-serif';g.fillText(new Date().toTimeString().slice(0,5),SW-110,y+27)}
function drawScreen(){const g=sg;if(!power){g.fillStyle='#030303';g.fillRect(0,0,SW,SH);scT.needsUpdate=true;return}
 if(mode==='video')drawVid(g);
 else if(mode==='emu'){g.fillStyle='#000';g.fillRect(0,0,SW,SH-40);if(emuCv&&emuCv.width>1){const k=Math.min(SW/emuCv.width,(SH-40)/emuCv.height),w=emuCv.width*k,h=emuCv.height*k;g.drawImage(emuCv,(SW-w)/2,(SH-40-h)/2,w,h)}else{g.fillStyle='#8f8';g.font='26px monospace';g.textAlign='center';g.fillText(emuMsg,SW/2,SH/2);g.textAlign='left'}}
 else if(mode==='skin')drawSkin(g);
 else if(mode==='wps')drawWps(g);
 else{drawWall(g);
  
  if(wpImg){const iw=wpImg.width,ih=wpImg.height,k=Math.max(SW/iw,(SH-40)/ih);g.save();g.beginPath();g.rect(0,0,SW,SH-40);g.clip();g.drawImage(wpImg,(SW-iw*k)/2,(SH-40-ih*k)/2,iw*k,ih*k);g.restore()}
  if(mode==='web'){g.fillStyle='#10131a';rr(60,50,SW-120,SH-150,14);g.fill();g.fillStyle='#8fb4ff';g.font='bold 34px sans-serif';g.textAlign='center';g.fillText('🌐 Браузер',SW/2,SH/2-30);g.fillStyle='#aab';g.font='24px sans-serif';g.fillText(webHost||'—',SW/2,SH/2+10);g.fillText('Приблизьтесь к монитору (кнопка 🖥)',SW/2,SH/2+50);g.textAlign='left'}
  else icons.forEach(([id,l],i)=>drawIcon(g,id,l,60+i*210,70))}
 const tb=g.createLinearGradient(0,SH-40,0,SH);tb.addColorStop(0,'#2b303c');tb.addColorStop(1,'#171a22');g.fillStyle=tb;g.fillRect(0,SH-40,SW,40);taskbar(g);scT.needsUpdate=true}
function screenTap(uv){if(!power)return;const x=uv.x*SW,y=(1-uv.y)*SH;
 if(y>SH-40){if(x<176)mode='desk';else if(x<246)vid.paused?vid.play():vid.pause();return}
 if(mode==='emu'){if(emu){emu.bus.send('mouse-click',[true,false,false]);setTimeout(()=>emu&&emu.bus.send('mouse-click',[false,false,false]),70)}return}
 if(mode==='video'){if(y>SH-56&&vid.duration)vid.currentTime=vid.duration*x/SW;else vid.paused?vid.play():vid.pause();return}
 if(mode==='skin'){skinTap(x,y);return}
 if(mode==='wps'){wpsTap(x,y);return}
 icons.forEach(([id],i)=>{const ix=40+i*210;if(x>ix&&x<ix+190&&y>50&&y<280){if(id==='video')$('vf').click();else if(id==='skin'){mode='skin';skMsg='';drawScreen()}else if(id==='wall'){mode='wps';wpMsg='';drawScreen()}else if(id==='emu'){if(emu){mode='emu'}else $('emf').click()}}})}
