//# FILE: ui/monitor-screen.js
//# ЧТО: Монитор и интерактивный экран-canvas (drawScreen).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: SW, scM, rf, scl, vid, mode, rr, icons, _old
// monitor + interactive screen canvas
{const mt=monTex(),mf=new THREE.MeshStandardMaterial({map:mt,bumpMap:mt,bumpScale:1.5,roughness:.48});box(1.0,.6,.06,0,1.22,-1.4,[beige,beige,beige,beige,mf,beige]);box(.12,.2,.1,0,.9,-1.4,beige);box(.4,.02,.25,0,.79,-1.4,beige);box(.5,.35,.1,0,1.22,-1.45,beige)}
box(.006,.006,.003,.44,.935,-1.369,new THREE.MeshStandardMaterial({color:0x06f,emissive:0x0066ff,emissiveIntensity:3}));[.40,.37].forEach(x=>box(.015,.008,.003,x,.935,-1.369,metal));
const SW=1024,SH=576,[sc,sg]=cv2(SW*2,SH*2),scT=toTex(sc);sg.scale(2,2);
const scM=new THREE.MeshBasicMaterial({map:scT,toneMapped:false}),scr=new THREE.Mesh(new THREE.PlaneGeometry(.92,.52),scM);scr.position.set(0,1.22,-1.368);scr.userData.act='screen';S.add(scr);
const rf=new THREE.Mesh(new THREE.PlaneGeometry(.92,.52),new THREE.MeshBasicMaterial({map:reflTex(),transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}));rf.position.set(0,1.22,-1.366);S.add(rf);
const scl=new THREE.PointLight(0x9fc0ff,1.5,3.5);scl.position.set(0,1.2,-1.0);S.add(scl);
const vid=document.createElement('video');vid.playsInline=true;vid.crossOrigin='anonymous';vid.loop=true;
let mode='desk',power=true,sf=0;
const rr=(x,y,w,h,r)=>{sg.beginPath();sg.roundRect(x,y,w,h,r)};
const icons=[['video','Видео'],['emu','Windows'],['skin','Скины'],['wall','Обои']];
const _old=[['video','🎞','Видео','#e5533d','#a02a1c'],['web','🌐','Интернет','#3da5e5','#1c62a0'],['yt','▶','YouTube','#ff3030','#a00000'],['ddg','🔎','Google','#e58c3d','#a0561c'],['wall','🖼','Обои','#8e44ad','#5b2a73'],['emu','💾','Windows','#2d7dd2','#1a4a8a'],['skin','🧑','Скины','#4caf50','#2e7d32']];
