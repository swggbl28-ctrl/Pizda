//# FILE: ui/menu-net.js
//# ЧТО: ОБЫЧНЫЙ <script> (не модуль, вне игры): настройки (localStorage.gs), P2P через PeerJS (window.Net), главное меню #gm и boot() — загрузка textures.js, подстановка //@TEXTURES:X@ в код игры и запуск его как модуля.
//# ВАЖНО: единственное место, знающее формат textures.js (разделитель //@@X). Не ломай boot().
(() => {
  // ---------- Настройки ----------
  let S = { vol: 0.8, name: '' };
  try { Object.assign(S, JSON.parse(localStorage.gs || '{}')); } catch (e) {}
  const saveS = () => {
    localStorage.gs = JSON.stringify(S);
    document.dispatchEvent(new CustomEvent('game:settings', { detail: S }));
  };
  window.GameSettings = S;

  // ---------- P2P (WebRTC через PeerJS, сервер только для рукопожатия) ----------
  const PFX = 'elv-', ABC = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const Net = window.Net = {
    peer: null, conn: null, isHost: false,
    onOpen() {}, onData() {}, onClose() {},
    send(d) { if (this.conn && this.conn.open) this.conn.send(d); },
    setup(c) {
      this.conn = c;
      c.on('open', () => this.onOpen(this.isHost));
      c.on('data', d => this.onData(d));
      c.on('close', () => this.onClose());
    },
    close() {
      try { this.conn && this.conn.close(); this.peer && this.peer.destroy(); } catch (e) {}
      this.conn = this.peer = null;
    },
    create(cb) {
      this.close(); this.isHost = true;
      const code = Array.from({ length: 4 }, () => ABC[Math.random() * ABC.length | 0]).join('');
      const p = this.peer = new Peer(PFX + code);
      p.on('open', () => cb(code));
      p.on('error', e => e.type === 'unavailable-id' ? this.create(cb) : cb(null));
      p.on('connection', c => this.conn ? c.close() : this.setup(c));
    },
    join(code, fail) {
      this.close(); this.isHost = false;
      const p = this.peer = new Peer();
      p.on('open', () => {
        this.setup(p.connect(PFX + code.toUpperCase(), { reliable: false, serialization: 'json' }));
        setTimeout(() => { if (this.conn && !this.conn.open) fail(); }, 12000);
      });
      p.on('error', fail);
    }
  };

  // ---------- Меню ----------
  const st = document.createElement('style');
  st.textContent = `
#gm{position:fixed;inset:0;z-index:99999;display:flex;align-items:center;justify-content:center;background:#0b0d12;color:#fff;font-family:system-ui,sans-serif}
#gm .p{display:none;flex-direction:column;gap:14px;width:min(80vw,320px);text-align:center}
#gm .p.on{display:flex}
#gm h1{margin:0 0 12px}
#gm button,#gm input{font:inherit;padding:16px;border-radius:12px;border:0;background:#2a3142;color:#fff;text-align:center}
#gm button:active{background:#3d4760}
#gm #gm-info{white-space:pre-line;font-size:20px}`;
  document.head.appendChild(st);

  const g = document.createElement('div');
  g.id = 'gm';
  g.innerHTML = `
<div class="p on" id="gm-main"><h1></h1>
  <input id="gm-name" placeholder="Ваш ник" maxlength="16">
  <button data-a="play">Играть</button>
  <button data-a="mp">Мультиплеер</button>
  <button data-a="set">Настройки</button></div>
<div class="p" id="gm-mp"><h1>Мультиплеер</h1>
  <button data-a="create">Создать комнату</button>
  <input id="gm-code" placeholder="Код комнаты" maxlength="4" autocapitalize="characters">
  <button data-a="join">Подключиться</button>
  <button data-a="back">Назад</button></div>
<div class="p" id="gm-lobby"><div id="gm-info"></div><button data-a="cancel">Отмена</button></div>
<div class="p" id="gm-set"><h1>Настройки</h1>
  <label>Громкость<input id="gm-vol" type="range" min="0" max="1" step="0.05" style="width:100%"></label>
  <button data-a="back">Назад</button></div>`;
  document.body.appendChild(g);

  const $ = s => g.querySelector(s);
  $('#gm-main h1').textContent = document.title || 'Игра';
  $('#gm-name').value = S.name;
  $('#gm-vol').value = S.vol;
  $('#gm-name').oninput = e => { S.name = e.target.value.trim(); saveS(); };
  $('#gm-vol').oninput = e => { S.vol = +e.target.value; saveS(); };

  const show = id => g.querySelectorAll('.p').forEach(p => p.classList.toggle('on', p.id === id));
  const info = t => $('#gm-info').textContent = t;
  const boot = () => window.__gl ||= new Promise(async ok => {
    window.__gameReady = ok;
    let code = document.getElementById('gsrc').textContent;
    try {
      const r = await fetch('textures.js'); if (!r.ok) throw new Error(r.status);
      const p = (await r.text()).split(/^\/\/@@(\w+).*$/m), T = {};
      for (let i = 1; i < p.length; i += 2) T[p[i]] = p[i + 1].replace(/^\n|\n+$/g, '');
      code = code.replace(/\/\/@TEXTURES:(\w+)@/g, (m, k) => T[k] ?? m);
    } catch (e) { info('Не найден textures.js: ' + e.message); throw e; }
    const s = document.createElement('script');
    s.type = 'module'; s.textContent = code;
    document.body.appendChild(s);
  });
  const start = async d => {
    show('gm-lobby'); info('Загрузка игры…');
    await boot();
    g.style.display = 'none'; document.body.classList.add('in');
    document.dispatchEvent(new CustomEvent('game:start', { detail: d }));
  };

  Net.onOpen = host => start({ mode: 'mp', host });
  Net.onClose = () => {
    Net.close(); document.body.classList.remove('in');
    document.dispatchEvent(new CustomEvent('game:stop'));
    g.style.display = 'flex'; show('gm-main');
  };

  const A = {
    play: () => start({ mode: 'single' }),
    mp: () => show('gm-mp'),
    set: () => show('gm-set'),
    back: () => show('gm-main'),
    create: () => {
      show('gm-lobby'); info('Создаю комнату…');
      Net.create(c => info(c ? 'Код комнаты:\n' + c + '\n\nЖдём второго игрока…' : 'Ошибка сети'));
    },
    join: () => {
      const c = $('#gm-code').value.trim();
      if (c.length < 4) return;
      show('gm-lobby'); info('Подключаюсь…');
      Net.join(c, () => info('Не удалось подключиться'));
    },
    cancel: () => { Net.close(); show('gm-mp'); }
  };
  ['touchstart','touchmove','touchend','pointerdown','pointermove','pointerup','mousedown','mouseup','keydown','keyup','wheel'].forEach(t => g.addEventListener(t, e => e.stopPropagation()));
  g.onclick = e => { const f = A[e.target.dataset.a]; if (f) f(); };
})();
