//# FILE: ui/video-player.js
//# ЧТО: Видеоплеер на ПК (+ pan/pinch/tap, браузер-окно #web).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: drawVid, lw, vFilter, fitK, syncUI, applyV, upd, vpOn, P, wpImg
// ---------- video player ----------
let drawVid,placeVp;
{const DEF={b:100,c:100,s:100,h:0,bl:0,sp:0,gr:0,inv:0,z:1,px:0,py:0,rot:0,fl:0,fit:'contain',r:1,lp:0},VS={...DEF},
SL=[['r','Скорость',.25,4,.05,'×'],['b','Яркость',0,300,1,'%'],['c','Контраст',0,300,1,'%'],['s','Насыщенность',0,300,1,'%'],['h','Оттенок',-180,180,1,'°'],['sp','Сепия',0,100,1,'%'],['gr','Ч/Б',0,100,1,'%'],['bl','Размытие',0,10,.1,'px'],['z','Масштаб',.5,6,.01,'×'],['px','Сдвиг X',-1.5,1.5,.01,''],['py','Сдвиг Y',-1.5,1.5,.01,'']],
FIT={contain:'Вписать',cover:'Заполнить',fill:'Растянуть'},vp=$('vp'),vsE=$('vs'),vset=$('vsett'),clampZ=z=>Math.min(6,Math.max(.5,z));
let lw=0,lh=0,idT=0;
const vFilter=()=>{const f=[];VS.b!=100&&f.push(`brightness(${VS.b}%)`);VS.c!=100&&f.push(`contrast(${VS.c}%)`);VS.s!=100&&f.push(`saturate(${VS.s}%)`);VS.h&&f.push(`hue-rotate(${VS.h}deg)`);VS.bl>0&&f.push(`blur(${VS.bl}px)`);VS.sp&&f.push(`sepia(${VS.sp}%)`);VS.gr&&f.push(`grayscale(${VS.gr}%)`);VS.inv&&f.push('invert(100%)');return f.join(' ')||'none'};
const fitK=(rw,rh,W,H)=>VS.fit==='fill'?[W/rw,H/rh]:(k=>[k,k])((VS.fit==='cover'?Math.max:Math.min)(W/rw,H/rh));
vset.innerHTML=SL.map(([k,n])=>`<label class="s">${n}<output id="o_${k}"></output><input type="range" data-k="${k}" min="${SL.find(a=>a[0]==k)[2]}" max="${SL.find(a=>a[0]==k)[3]}" step="${SL.find(a=>a[0]==k)[4]}"></label>`).join('')+'<div class="vbt"><button id="vrot">⟳ Поворот</button><button id="vfl">⇋ Зеркало</button><button id="vinv">◐ Инверсия</button><button id="vfit"></button><button id="vlp">🔁 Цикл</button><button id="vpip">⧉ PiP</button><label class="b">CC субтитры<input type="file" id="vsub" accept=".vtt,.srt" hidden></label><button id="vrs">Сброс</button></div>';
function syncUI(){SL.forEach(([k,,,,,u])=>{const i=vset.querySelector(`[data-k="${k}"]`);i.value=VS[k];$('o_'+k).textContent=Math.round(VS[k]*100)/100+u});$('vfit').textContent='▭ '+FIT[VS.fit];[['vinv','inv'],['vlp','lp'],['vfl','fl']].forEach(([i,k])=>$(i).classList.toggle('act',!!VS[k]))}
function applyV(){const W=vsE.clientWidth,H=vsE.clientHeight;if(!W)return;lw=W;lh=H;const o=VS.rot&1,cw=o?H:W,ch=o?W:H;
 Object.assign(vid.style,{position:'absolute',width:cw+'px',height:ch+'px',left:(W-cw)/2+'px',top:(H-ch)/2+'px',objectFit:VS.fit,filter:vFilter(),transform:`translate(${VS.px*W}px,${VS.py*H}px) rotate(${VS.rot*90}deg) scale(${VS.fl?-VS.z:VS.z},${VS.z})`});vid.playbackRate=VS.r;vid.loop=!!VS.lp}
const upd=()=>{applyV();syncUI()};
vsE.appendChild(vid);syncUI();
drawVid=g=>{const W=SW,H=SH-40;g.fillStyle='#000';g.fillRect(0,0,W,H);if(vid.readyState>1){g.save();g.beginPath();g.rect(0,0,W,H);g.clip();const o=VS.rot&1,cw=o?H:W,ch=o?W:H,vw=vid.videoWidth||cw,vh=vid.videoHeight||ch,[kx,ky]=fitK(vw,vh,cw,ch);
 g.translate(W/2+VS.px*W,H/2+VS.py*H);g.rotate(VS.rot*Math.PI/2);g.scale(VS.fl?-VS.z:VS.z,VS.z);g.beginPath();g.rect(-cw/2,-ch/2,cw,ch);g.clip();g.filter=vFilter();try{g.drawImage(vid,-vw*kx/2,-vh*ky/2,vw*kx,vh*ky)}catch(e){}g.restore()}
 g.fillStyle='#444';g.fillRect(0,H-6,W,6);if(vid.duration){g.fillStyle='#e33';g.fillRect(0,H-6,W*vid.currentTime/vid.duration,6)}};
const vpOn=()=>mode==='video'&&power&&zoomed&&zk>.99,tgl=()=>vid.paused?vid.play().catch(()=>{}):vid.pause(),
 seek=d=>{vid.currentTime=Math.max(0,Math.min(vid.duration||1e9,vid.currentTime+d))},
 wake=()=>{vp.classList.remove('idle');clearTimeout(idT);idT=setTimeout(()=>{if(!vid.paused&&!vset.classList.contains('on'))vp.classList.add('idle')},3000)},
 fs=()=>{const on=!vp.classList.contains('vfull');vp.classList.toggle('vfull',on);if(on)vp.requestFullscreen&&vp.requestFullscreen().catch(()=>{});else document.fullscreenElement&&document.exitFullscreen();setTimeout(upd,50)},
 tf=s=>{s=isFinite(s)?s:0;const h=s/3600|0,m=s/60%60|0;return(h?h+':'+String(m).padStart(2,'0'):m)+':'+String(s%60|0).padStart(2,'0')},
 tm=()=>{const d=vid.duration;$('vt').textContent=tf(vid.currentTime)+' / '+tf(d);if(document.activeElement!==$('vseek')&&d)$('vseek').value=vid.currentTime/d*1000};
addEventListener('fullscreenchange',()=>{if(!document.fullscreenElement)vp.classList.remove('vfull');setTimeout(upd,50)});
placeVp=()=>{const on=vpOn();if(!on){if(vp.style.display==='block'){vp.style.display='none';vp.classList.remove('vfull');document.fullscreenElement&&document.exitFullscreen()}return}
 if(vp.style.display!=='block'){vp.style.display='block';wake();upd()}
 const a=new THREE.Vector3(-.46,.26,-1.368).project(cam),b=new THREE.Vector3(.46,-.26,-1.368).project(cam),x0=(a.x+1)/2*innerWidth,y0=(1-a.y)/2*innerHeight,x1=(b.x+1)/2*innerWidth,y1=(1-b.y)/2*innerHeight;
 Object.assign(vp.style,{left:x0+'px',top:y0+'px',width:(x1-x0)+'px',height:(y1-y0)*536/576+'px'});if(vsE.clientWidth!==lw||vsE.clientHeight!==lh)upd()};
['timeupdate','durationchange'].forEach(n=>vid.addEventListener(n,tm));vid.addEventListener('loadedmetadata',upd);
vid.addEventListener('play',()=>{$('vpl').textContent='⏸';wake()});vid.addEventListener('pause',()=>{$('vpl').textContent='▶';wake()});
vid.addEventListener('volumechange',()=>{$('vmu').textContent=vid.muted||!vid.volume?'🔇':'🔊';$('vvol').value=vid.muted?0:vid.volume});
$('vpl').onclick=tgl;$('vb').onclick=()=>seek(-10);$('vfw').onclick=()=>seek(10);$('vmu').onclick=()=>{vid.muted=!vid.muted};$('vvol').oninput=e=>{vid.muted=false;vid.volume=+e.target.value};
$('vseek').oninput=e=>{if(vid.duration)vid.currentTime=vid.duration*e.target.value/1000};
$('vset').onclick=()=>{vset.classList.toggle('on');wake()};$('vfs').onclick=fs;$('vcl').onclick=()=>{vid.pause();mode='desk';drawScreen()};
vset.oninput=e=>{const k=e.target.dataset.k;if(k){VS[k]=+e.target.value;upd()}};
$('vrot').onclick=()=>{VS.rot=(VS.rot+1)%4;upd()};$('vfl').onclick=()=>{VS.fl^=1;upd()};$('vinv').onclick=()=>{VS.inv^=1;upd()};$('vlp').onclick=()=>{VS.lp^=1;upd()};
$('vfit').onclick=()=>{VS.fit=VS.fit==='contain'?'cover':VS.fit==='cover'?'fill':'contain';upd()};$('vrs').onclick=()=>{Object.assign(VS,DEF);upd()};
if(!document.pictureInPictureEnabled)$('vpip').style.display='none';$('vpip').onclick=()=>{document.pictureInPictureElement?document.exitPictureInPicture():vid.requestPictureInPicture&&vid.requestPictureInPicture().catch(()=>{})};
$('vsub').onchange=async e=>{const f=e.target.files[0];if(!f)return;let t=(await f.text()).replace(/\r/g,'');if(!/^\uFEFF?WEBVTT/.test(t))t='WEBVTT\n\n'+t.replace(/(\d+:\d+:\d+),(\d+)/g,'$1.$2');vid.querySelectorAll('track').forEach(x=>x.remove());const tr=document.createElement('track');tr.kind='subtitles';tr.default=true;tr.src=URL.createObjectURL(new Blob([t],{type:'text/vtt'}));vid.appendChild(tr);tr.track.mode='showing'};
// pan / pinch / tap
const P=new Map();let mvd=0,pd=0,tapT=0,tapId=0;const dist=()=>{const[a,b]=[...P.values()];return Math.hypot(a[0]-b[0],a[1]-b[1])};
vsE.onpointerdown=e=>{vsE.setPointerCapture(e.pointerId);P.set(e.pointerId,[e.clientX,e.clientY]);if(P.size===1)mvd=0;pd=P.size>1?dist():0};
vsE.onpointermove=e=>{const o=P.get(e.pointerId);if(!o)return;const n=[e.clientX,e.clientY];P.set(e.pointerId,n);
 if(P.size===1){mvd+=Math.abs(n[0]-o[0])+Math.abs(n[1]-o[1]);if(mvd>8&&VS.z>1){VS.px+=(n[0]-o[0])/vsE.clientWidth;VS.py+=(n[1]-o[1])/vsE.clientHeight;upd()}}
 else if(P.size===2){mvd=99;const d=dist();if(pd){VS.z=clampZ(VS.z*d/pd);upd()}pd=d}};
vsE.onpointerup=vsE.onpointercancel=e=>{if(!P.delete(e.pointerId))return;if(!P.size&&mvd<=8&&e.type==='pointerup'){const t=performance.now();if(t-tapT<300){clearTimeout(tapId);tapT=0;fs()}else{tapT=t;tapId=setTimeout(()=>{tapT=0;tgl()},260)}}pd=0};
vsE.addEventListener('wheel',e=>{e.preventDefault();VS.z=clampZ(VS.z*(e.deltaY<0?1.1:1/1.1));upd()},{passive:false});
vp.addEventListener('pointermove',wake);vp.addEventListener('pointerdown',wake);
vp.addEventListener('pointerup',()=>setTimeout(()=>{const a=document.activeElement;a&&vp.contains(a)&&a.blur()},0));
addEventListener('keydown',e=>{if(!vpOn()||e.target.type==='text'||e.ctrlKey||e.metaKey)return;wake();const k=e.key;let h=1;
 if(k===' '||k==='k')tgl();else if(k==='ArrowLeft')seek(-5);else if(k==='ArrowRight')seek(5);else if(k==='j')seek(-10);else if(k==='l')seek(10);
 else if(k==='ArrowUp'){vid.muted=false;vid.volume=Math.min(1,vid.volume+.05)}else if(k==='ArrowDown')vid.volume=Math.max(0,vid.volume-.05);
 else if(k==='m')vid.muted=!vid.muted;else if(k==='f')fs();else if(k==='r'){VS.rot=(VS.rot+1)%4;upd()}
 else if(k==='+'||k==='='){VS.z=clampZ(VS.z*1.1);upd()}else if(k==='-'){VS.z=clampZ(VS.z/1.1);upd()}else if(k==='0'){VS.z=1;VS.px=VS.py=0;upd()}
 else if(k==='['){VS.r=Math.max(.25,VS.r-.25);upd()}else if(k===']'){VS.r=Math.min(4,VS.r+.25);upd()}
 else if(k===','&&vid.paused)seek(-1/30);else if(k==='.'&&vid.paused)seek(1/30);else h=0;h&&e.preventDefault()});
}
$('vf').onchange=e=>{const f=e.target.files[0];if(f)playVideo(URL.createObjectURL(f))};
$('af').onchange=e=>{const f=e.target.files[0];if(!f)return;initAudio();trackName=f.name;musicEl.src=URL.createObjectURL(f);musicEl.play().catch(()=>{});updDisp()};
$('go').onclick=()=>load(urlI.value);urlI.onkeydown=e=>{if(e.key==='Enter')load(urlI.value)};
$('bk').onclick=()=>{if(hi>0){hi--;load(hist[hi][0],hist[hi][1],true)}};
$('wx').onclick=()=>{mode='desk';wf.removeAttribute('srcdoc');wf.src='about:blank'};
$('zm').onclick=()=>zoom(!zoomed);
$('st').onclick=()=>{initAudio();const p=$('pan');p.style.display=p.style.display==='flex'?'none':'flex'};
$('amf').onchange=e=>{const f=e.target.files[0];if(!f)return;initAudio();ambOwn=true;envLevel();ambEl.src=URL.createObjectURL(f);if($('amt').checked)ambEl.play().catch(()=>{})};
$('amt').onchange=e=>{initAudio();envLevel();if(e.target.checked){if(ambEl.src)ambEl.play()}else ambEl.pause()};
$('amv').oninput=e=>{ambG&&(ambG.gain.value=+e.target.value);envLevel()};$('thv').oninput=e=>{thVol=+e.target.value;if(thG)thG.gain.value=thVol};
setTimeout(()=>$('hint').style.opacity=0,9000);
let wpImg=null;
