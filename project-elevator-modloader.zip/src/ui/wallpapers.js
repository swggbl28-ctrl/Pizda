//# FILE: ui/wallpapers.js
//# ЧТО: Обои на ПК: галерея до 10 штук, хранится между запусками.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: icoWall, WPL, wpApply, wpSave, wpMk, drawWps, wpsTap
// ---------- обои на ПК: галерея до 10 штук, сохраняется между запусками ----------
function icoWall(g,x,y,s){const k=s/140;g.save();g.translate(x,y);g.scale(k,k);g.shadowColor='rgba(0,0,0,.55)';g.shadowBlur=18;g.shadowOffsetY=8;
 g.fillStyle='#f3efe0';g.beginPath();g.roundRect(8,16,124,108,10);g.fill();g.shadowColor='transparent';
 let q=g.createLinearGradient(0,26,0,114);q.addColorStop(0,'#2a78d6');q.addColorStop(1,'#bfe3ff');g.fillStyle=q;g.fillRect(18,26,104,88);
 g.fillStyle='#ffd34d';g.beginPath();g.arc(98,50,10,0,6.3);g.fill();
 g.fillStyle='#3f8f4a';g.beginPath();g.moveTo(18,114);g.lineTo(52,62);g.lineTo(78,98);g.lineTo(92,80);g.lineTo(122,114);g.closePath();g.fill();
 g.fillStyle='#2c6a36';g.beginPath();g.moveTo(18,114);g.lineTo(40,92);g.lineTo(62,114);g.closePath();g.fill();
 q=g.createLinearGradient(0,16,0,70);q.addColorStop(0,'rgba(255,255,255,.35)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(18,26,104,44);g.restore()}
const WPL=[];let WPS=-1,wpMsg='';
const wpApply=()=>{wpImg=WPS>=0&&WPL[WPS]?WPL[WPS].cv:null};
function wpSave(){try{localStorage.setItem('wps',JSON.stringify({sel:WPS,l:WPL.map(w=>({n:w.n,d:w.d}))}))}catch(e){wpMsg='Не удалось сохранить (мало места)'}}
const wpMk=im=>{const k=Math.min(1,960/Math.max(im.width,im.height)),[c,g]=cv2(im.width*k|0,im.height*k|0);g.drawImage(im,0,0,c.width,c.height);return c};
(async()=>{try{const o=JSON.parse(localStorage.getItem('wps')||'null');
 if(o){for(const w of(o.l||[]).slice(0,10)){const c=wpMk(await loadImg(w.d));WPL.push({n:w.n,cv:c,d:w.d})}WPS=Math.min(o.sel??-1,WPL.length-1)}
 else{const d=localStorage.getItem('wp');if(d){const c=wpMk(await loadImg(d));WPL.push({n:'Обои',cv:c,d});WPS=0;wpSave()}}
 wpApply()}catch(e){}})();
$('wpf').onchange=async e=>{const f=e.target.files[0];e.target.value='';if(!f)return;let u;
 try{if(WPL.length>=10){wpMsg='Максимум 10 — удалите лишние';return}u=URL.createObjectURL(f);const c=wpMk(await loadImg(u));
  WPL.push({n:f.name.replace(/\.[^.]+$/,'').slice(0,14)||'Обои',cv:c,d:c.toDataURL('image/jpeg',.78)});WPS=WPL.length-1;wpApply();wpMsg='Обои добавлены и установлены';wpSave()}
 catch(x){wpMsg='Не удалось загрузить файл'}finally{u&&URL.revokeObjectURL(u);drawScreen()}};
function drawWps(g){g.fillStyle='#14161c';g.fillRect(0,0,SW,SH-40);g.textAlign='left';g.fillStyle='#fff';g.font='bold 26px sans-serif';icoWall(g,14,6,44);g.fillText('Обои рабочего стола ('+WPL.length+'/10)',68,38);
 g.fillStyle='#9ab';g.font='16px sans-serif';g.fillText(wpMsg||'Тап — установить, ✕ — удалить. Загрузка картинки с телефона',20,60);
 for(let i=0;i<12;i++){const[x,y]=slotXY(i),sel=i<11&&(i==0?WPS<0:WPS==i-1),o=i>0&&i<11?WPL[i-1]:null;
  g.fillStyle=sel?'#1f3a2a':'#222733';rr(x,y,160,210,14);g.fill();g.strokeStyle=sel?'#4caf50':'#3b4150';g.lineWidth=sel?4:2;g.stroke();g.textAlign='center';
  if(i==11){g.fillStyle='#4caf50';g.font='64px sans-serif';g.fillText('＋',x+80,y+112);g.fillStyle='#fff';g.font='bold 18px sans-serif';g.fillText(WPL.length>=10?'Лимит 10':'Загрузить',x+80,y+190)}
  else if(i>0&&!o){g.fillStyle='#3b4150';g.font='18px sans-serif';g.fillText('пусто',x+80,y+110)}
  else{g.save();g.beginPath();g.roundRect(x+8,y+44,144,96,8);g.clip();
   if(o){const k=Math.max(144/o.cv.width,96/o.cv.height);g.drawImage(o.cv,x+8+(144-o.cv.width*k)/2,y+44+(96-o.cv.height*k)/2,o.cv.width*k,o.cv.height*k)}
   else{const q=g.createLinearGradient(0,y+44,0,y+140);q.addColorStop(0,'#2a78d6');q.addColorStop(1,'#d9efff');g.fillStyle=q;g.fillRect(x+8,y+44,144,96)}
   g.restore();g.fillStyle='#fff';g.font='bold 17px sans-serif';g.fillText(o?o.n:'Стандартные',x+80,y+190);
   if(o){g.fillStyle='#c0392b';rr(x+124,y+6,30,30,8);g.fill();g.fillStyle='#fff';g.font='bold 18px sans-serif';g.fillText('✕',x+139,y+27)}}
  g.textAlign='left'}}
function wpsTap(x,y){wpMsg='';for(let i=0;i<12;i++){const[sx,sy]=slotXY(i);if(x>sx&&x<sx+160&&y>sy&&y<sy+210){
  if(i==11){if(WPL.length>=10)wpMsg='Максимум 10 — удалите лишний';else $('wpf').click()}
  else if(i==0){WPS=-1;wpApply();wpSave()}
  else{const o=WPL[i-1];if(!o)break;if(x>sx+120&&y<sy+40){WPL.splice(i-1,1);if(WPS==i-1)WPS=-1;else if(WPS>i-1)WPS--;wpApply();wpSave()}else{WPS=i-1;wpApply();wpSave()}}
  break}}drawScreen()}
