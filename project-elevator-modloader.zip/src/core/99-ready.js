//# FILE: core/99-ready.js
//# ЧТО: Сигнал window.__gameReady. Всегда последним.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
window.__gameReady&&window.__gameReady();
