//# FILE: core/01-renderer-scene.js
//# ЧТО: $() = getElementById, renderer R, сцена S, камера cam, resize.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: $, R, S, cam
const $=i=>document.getElementById(i);const urlI=$('url');let zoomed=false,zk=0;
const R=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance',stencil:false,alpha:false});R.setPixelRatio(Math.min(devicePixelRatio,2));R.setSize(innerWidth,innerHeight);
R.outputColorSpace=THREE.SRGBColorSpace;R.toneMapping=THREE.ACESFilmicToneMapping;R.toneMappingExposure=1.15;R.shadowMap.enabled=true;R.shadowMap.autoUpdate=false;R.shadowMap.type=THREE.PCFSoftShadowMap;document.body.prepend(R.domElement);
const S=new THREE.Scene();S.background=new THREE.Color(0);S.fog=new THREE.FogExp2(0x2a2410,.07);
const cam=new THREE.PerspectiveCamera(72,innerWidth/innerHeight,.05,60);cam.position.set(0,1.25,.9);
addEventListener('resize',()=>{R.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
