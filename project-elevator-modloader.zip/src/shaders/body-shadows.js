//# FILE: shaders/body-shadows.js
//# ЧТО: ШЕЙДЕРЫ: гибридные лучевые тени тела игрока (аналитический луч против капсул, на свет и пиксель). Патчит THREE.ShaderChunk.lights_fragment_begin и Material.prototype.onBeforeCompile; uniforms BCU/BBU. Вся GLSL-логика игры только здесь.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: BCU
// ---------- hybrid ray-traced body shadows (analytic ray vs capsule, per light, per pixel) ----------
const BCU={value:new Float32Array(48)},BBU={value:new THREE.Vector4()};
{const C=THREE.ShaderChunk;let L=C.lights_fragment_begin;
 const ad=(n,l)=>{L=L.replace(new RegExp('('+n+'\\(\\s*'+l+'\\s*,\\s*geometryPosition\\s*,\\s*directLight\\s*\\);)'),'$1\n#ifndef NO_BCAP\nif(directLight.visible)directLight.color*=bodyOcc(geometryPosition,directLight.direction,length('+l+'.position-geometryPosition));\n#endif')};
 ad('getPointLightInfo','pointLight');ad('getSpotLightInfo','spotLight');
 L=L.replace(/(getDirectionalLightInfo\(\s*directionalLight\s*,\s*directLight\s*\);)/,'$1\n#ifndef NO_BCAP\nif(directLight.visible)directLight.color*=bodyOcc(geometryPosition,directLight.direction,40.);\n#endif');
 C.lights_fragment_begin=L;
 C.lights_pars_begin+=`
#ifndef NO_BCAP
uniform vec4 bCap[12];
uniform vec4 bBS;
float bodyOcc(vec3 ro,vec3 rd,float tm){
 float t0=clamp(dot(bBS.xyz-ro,rd),0.,tm);
 if(length(ro+rd*t0-bBS.xyz)>bBS.w+.6)return 1.;
 float res=1.;
 for(int i=0;i<6;i++){
  vec3 pa=bCap[i*2].xyz,ba=bCap[i*2+1].xyz-pa;float r=bCap[i*2].w;
  vec3 w=ro-pa;float b=dot(rd,ba),c=max(dot(ba,ba),1e-5),d=dot(rd,w),e=dot(ba,w),D=c-b*b;
  float u=D>1e-4?clamp((e-b*d)/D,0.,1.):.5;
  float s=clamp(b*u-d,0.,tm);
  u=clamp(dot(ro+rd*s-pa,ba)/c,0.,1.);
  s=clamp(b*u-d,0.,tm);
  float k=length(ro+rd*s-pa-ba*u)-r;
  res=min(res,smoothstep(0.,1.,k/(.02+s*.28)));
 }
 return res;
}
float bodyAO(vec3 p,vec3 n){
 vec3 q=bBS.xyz-p;if(dot(q,q)>bBS.w*bBS.w*4.)return 1.;
 float ao=1.;
 for(int i=0;i<6;i++){
  vec3 pa=bCap[i*2].xyz,ba=bCap[i*2+1].xyz-pa;float r=bCap[i*2].w;
  float u=clamp(dot(p-pa,ba)/max(dot(ba,ba),1e-5),0.,1.);
  vec3 d=pa+ba*u-p;float l=max(length(d),.02);
  ao*=1.-clamp(max(dot(n,d/l),0.)*r*r/(l*l)*1.3,0.,.8);
 }
 return ao;
}
#endif
`}
THREE.Material.prototype.onBeforeCompile=function(s){const f=s.fragmentShader;if(f.indexOf('#include <lights_fragment_end>')<0)return;s.uniforms.bCap=BCU;s.uniforms.bBS=BBU;
 s.fragmentShader=f.replace('#include <aomap_fragment>','#include <aomap_fragment>\n#ifndef NO_BCAP\nreflectedLight.indirectDiffuse*=bodyAO(-vViewPosition,normal);\n#endif')};
