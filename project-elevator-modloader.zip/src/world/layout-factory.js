//# FILE: world/layout-factory.js
//# ЧТО: LAYOUT-фабрика: зоны, коридоры, двери (детерминированно по чанкам).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: mkLay, zone, zone0, cr, cls, edge, walls, hit, build, LAY2, LAY3
// ===== LAYOUT-фабрика: зоны, коридоры, двери (детерминированно по чанкам) =====
const mkLay=C=>{const BS=C.BS,c0=C.c,md=a=>((a%BS)+BS)%BS,R=(a,b,c)=>hs(a,b,c)/4294967296,ZC=new Map,
rg=l=>l<c0?[0,c0-1]:[c0+1,BS-1],
quad=(i,j)=>{const xr=rg(md(i)),yr=rg(md(j)),bi=Math.floor(i/BS),bj=Math.floor(j/BS);return{x0:bi*BS+xr[0],y0:bj*BS+yr[0],w:xr[1]-xr[0]+1,h:yr[1]-yr[0]+1}},
sd=(n,i,j)=>n.vert?i<n.x0+n.c:j<n.y0+n.c;
function zone(i,j){const key=i+','+j;let z=ZC.get(key);if(z)return z;z=zone0(i,j);if(ZC.size>6000)ZC.clear();ZC.set(key,z);return z}
function zone0(i,j){const lx=md(i),ly=md(j);
 if(lx==c0&&ly==c0)return{t:'plaza'};if(ly==c0)return{t:'corr',ax:'x'};if(lx==c0)return{t:'corr',ax:'z'};
 const Q=quad(i,j),el=C.el(j,Q),sp=C.sp(j,Q),mg=!el&&!sp&&Q.w>1&&Q.h>1&&hs(Q.x0,Q.y0,5)%100<C.mg;
 let x0=Q.x0,y0=Q.y0,w=Q.w,h=Q.h;const path=[];
 if(!mg)for(let d=0;w*h>1;d++){const k=hs(x0,y0,200+d*7+w*3+h);if(!(el&&d==0)&&w*h<=3&&k%3==0)break;
  const vert=el&&d==0?0:w>h?1:h>w?0:k&1,len=vert?w:h,c=1+((k>>>3)%(len-1));path.push({x0,y0,w,h,vert,c,k});
  if(vert){if(i<x0+c)w=c;else{x0+=c;w-=c}}else{if(j<y0+c)h=c;else{y0+=c;h-=c}}}
 const L=mg?Q:{x0,y0,w,h};
 return{t:C.typer(L.w*L.h,hs(L.x0,L.y0,77)%100,mg,el),Q,L,path}}
const cr=z=>z.t=='corr'||z.t=='plaza';
function cls(i,j,e){const i2=e?i+1:i,j2=e?j:j+1,A=zone(i,j),B=zone(i2,j2),d=R(i,j,e?11:12)*4-2,sol={k:'solid',d},op={k:'open',d},dr={k:'door',d};
 if(cr(A)&&cr(B))return op;
 if(cr(A)||cr(B)){const ca=cr(A),Rm=ca?B:A,ri=ca?i2:i,rj=ca?j2:j,Q=Rm.Q,s=e?(ca?0:1):(ca?2:3),h=s<2,idx=h?rj-Q.y0:ri-Q.x0,len=h?Q.h:Q.w;
  return idx==hs(Q.x0,Q.y0,300+s)%len||hs(i,j,e?13:14)%100<30?op:sol}
 if(A.Q.x0!=B.Q.x0||A.Q.y0!=B.Q.y0)return hs(i,j,e?15:16)%100<20?dr:sol;
 if(A.L.x0==B.L.x0&&A.L.y0==B.L.y0)return op;
 for(const n of A.path)if(sd(n,i,j)!=sd(n,i2,j2)){const len=n.vert?n.h:n.w,idx=n.vert?j-n.y0:i-n.x0,kk=n.x0==0&&n.y0==400&&!n.vert?1+((n.k>>>5)%2):(n.k>>>5)%len;return idx==kk?dr:sol}
 return op}
function edge(i,j,e){const c=cls(i,j,e);return{k:c.k,d:c.d,t2:c.k=='open'?0:c.k=='door'?1:2,t0:c.k=='open'?-1:c.k=='door'?(hs(i,j,e?17:18)%100<35?2:1):0}}
function walls(i,j){const Z=zone(i,j);if(Z.t!='corr')return[];const X=Z.ax=='x',o=[],W=C.cw;
 [-1,1].forEach((s,n)=>{const c=X?cls(i,s<0?j-1:j,0):cls(s<0?i-1:i,j,1),hc=c.k=='open'?(R(i,j,400+n)-.5)*5:null,
  seg=(a0,a1,y0,h)=>{const m=(a0+a1)/2,l=a1-a0;o.push(X?{x:m,z:s*W,w:l,d:.2,y0,h}:{x:s*W,z:m,w:.2,d:l,y0,h})};
  if(hc==null)seg(-4,4,0,2.8);else{seg(-4,hc-.6,0,2.8);seg(hc+.6,4,0,2.8);seg(hc-.6,hc+.6,2.2,.6)}});
 return o}
const hit=(x0,x1,z0,z1,a0,a1,b0,b1)=>x1>a0&&x0<a1&&z1>b0&&z0<b1,
f=c=>c.k=='open'?{f:1}:c.k=='door'?{d:c.d}:null,
holes=(i,j)=>({n:f(cls(i,j-1,0)),s:f(cls(i,j,0)),w:f(cls(i-1,j,1)),e:f(cls(i,j,1))}),
zr=(h,s)=>{const a=h.f?-4:h.d-.9,b=h.f?4:h.d+.9,p=h.f?1.2:1.8;return s=='n'?[a,b,-4,-4+p]:s=='s'?[a,b,4-p,4]:s=='w'?[-4,-4+p,a,b]:[4-p,4,a,b]},
bad=(H,x0,x1,z0,z1)=>['n','s','w','e'].some(s=>H[s]&&hit(x0,x1,z0,z1,...zr(H[s],s)));
function build(ch,i,j,cx,cz,r,put,cyl,ov,wm,Z,it){
 const ws=walls(i,j);
 ws.forEach(w=>{put(cx+w.x,cz+w.z,w.w,w.d,w.h,wm,w.y0,w.y0?0:2);
  if(w.y0){const a=cx+w.x-w.w/2,b=cx+w.x+w.w/2,c=cz+w.z-w.d/2,d=cz+w.z+w.d/2;ch.lt.push([a,b,c,d,2.8,2.2]);ch.st.push([a,b,2.2,2.8,c,d])}});
 const H=holes(i,j),ok=(x,z,rx,rz)=>!bad(H,x-rx,x+rx,z-rz,z+rz)&&!ov(cx+x,cz+z,Math.max(rx,rz)+.05);
 C.fill(Z.t,{ch,i,j,cx,cz,r,put,cyl,ov,it,Z,H,ok,ws,cw:C.cw})}
return{zone,edge,build,K:Z=>Z.t=='corr'?(Z.ax=='x'?[1,C.kk]:[C.kk,1]):[1,1]}};
const LAY2=mkLay({BS:6,c:3,cw:1.7,kk:.4,mg:30,el:(j,Q)=>j>=400&&Q.x0==0&&Q.y0==400,sp:()=>false,
 typer:(a,k,mg,el)=>el||mg?'hall':a==1?(k<55?'bed':'store'):k<45?'bed':k<70?'store':'hall',fill:(t,X)=>FILL2(t,X)});
const LAY3=mkLay({BS:5,c:2,cw:2.2,kk:.6,mg:40,el:()=>false,sp:(j,Q)=>j<400&&Q.x0==0&&Q.y0==0,
 typer:(a,k,mg)=>mg?'cube':a==1?(k<30?'srv':k<60?'break':'copy'):k<45?'meet':'cube',fill:(t,X)=>FILL3(t,X)});
