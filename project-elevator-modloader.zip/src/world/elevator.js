//# FILE: world/elevator.js
//# ЧТО: Лифт: билдер (стена z=0, кабина за стеной), двери, табло этажа, коллизии, тряска камеры; лифт этажа 3.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: flrTex, setFlr, ELS, buildElev, hintTxt, setDisp, elCall, ER, elGo, openDoors, shake, elevTick, elArrive, ambNote, _bobY, E3
// --- display textures ---
function flrTex(txt,col='#ff4020'){const[c,g]=cv2(128,64);g.fillStyle='#080303';g.fillRect(0,0,128,64);g.fillStyle=col;g.shadowColor=col;g.shadowBlur=10;g.font='bold 46px monospace';g.textAlign='center';g.fillText(txt,64,48);const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return[t,g,c]}
function setFlr(d,txt,col){const g=d[1];g.shadowBlur=0;g.fillStyle='#080303';g.fillRect(0,0,128,64);g.fillStyle=col||'#ff4020';g.shadowColor=col||'#ff4020';g.shadowBlur=10;g.font='bold 46px monospace';g.textAlign='center';g.fillText(txt,64,48);d[0].needsUpdate=true}
// --- elevator builder: wall at local z=0, room on -z side, cab/shaft on +z side. doorway local x in [-.6,.6] ---
const ELS=[];
function buildElev(P,wx,wz,floor){
 const E={floor,st:floor==3?'closed':'closed',dp:0,t:0,have:false,riding:false,P,wx,wz,btns:[]};
 const g=new THREE.Group();g.position.set(wx,0,wz);P.add(g);E.g=g;
 const dm=new THREE.MeshStandardMaterial({color:0x9a9486,roughness:.35,metalness:.85,bumpMap:RUST.map,bumpScale:.4}),fm=new THREE.MeshStandardMaterial({color:0x3a352c,roughness:.5,metalness:.7,map:RUST.map});
 const bx=(w,h,d,x,y,z,m,p=g)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);p.add(o);return o};
 // frame
 bx(.1,2.3,.2,-.65,1.15,0,fm);bx(.1,2.3,.2,.65,1.15,0,fm);bx(1.4,.12,.2,0,2.26,0,fm);bx(1.4,.04,.3,0,.02,.05,fm);
 // doors
 E.dl=bx(.6,2.15,.05,-.3,1.075,.04,dm);E.dr=bx(.6,2.15,.05,.3,1.075,.04,dm);
 [E.dl,E.dr].forEach(d=>{bx(.5,1.9,.01,0,0,-.03,RUST.clone?new THREE.MeshStandardMaterial({color:0x777166,roughness:.5,metalness:.8}):dm,d)});
 // shaft + cab (behind wall plane, +z)
 const cab=new THREE.Group();g.add(cab);E.cab=cab;
 const W=1.3,D=1.6,H=2.3;
 bx(W,.05,D,0,.0,D/2+.1,TILEF,cab);bx(W,.05,D,0,H,D/2+.1,fm,cab);bx(.05,H,D,-W/2,H/2,D/2+.1,dm,cab);bx(.05,H,D,W/2,H/2,D/2+.1,dm,cab);bx(W,H,.05,0,H/2,D+.1,dm,cab);
 // wall wear panels + handrail
 bx(.03,.04,1.2,-W/2+.04,.9,D/2+.1,RUSTBAR,cab);bx(.03,.04,1.2,W/2-.04,.9,D/2+.1,RUSTBAR,cab);bx(1.1,.04,.03,0,.9,D+.06,RUSTBAR,cab);
 // inner light
 const lm=new THREE.MeshStandardMaterial({color:0xfff2c0,emissive:0xffe9a0,emissiveIntensity:2.2});bx(.7,.03,.7,0,H-.04,D/2+.1,lm,cab);
 const L=new THREE.PointLight(0xffe0a0,0,4,2);L.position.set(0,H-.3,D/2+.1);cab.add(L);E.L=L;
 // shaft dark walls behind door (visible when cab absent) 
 E.shaft=new THREE.Group();g.add(E.shaft);bx(1.3,2.3,.05,0,1.15,.7,new THREE.MeshBasicMaterial({color:0x020202}),E.shaft);
 // outer call button panel
 const pan=bx(.14,.3,.04,1.05,1.1,-.02,fm);const cb=bx(.07,.07,.03,1.05,1.14,-.05,new THREE.MeshStandardMaterial({color:0x331100,emissive:0xff5500,emissiveIntensity:.6,roughness:.4}));E.cbtn=cb;
 const o1=bx(.04,.04,.03,1.05,1.04,-.05,new THREE.MeshStandardMaterial({color:0x222,emissive:0x00ff44,emissiveIntensity:0}));E.led=o1;
 // hit proxies
 const hm=(w,h,d,x,y,z,fn)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),HM);o.position.set(x,y,z);o.userData={fn:(ob,pt)=>{if(Math.hypot(home.x-(wx+ (P.userData.ox||0)),home.z-wz)<4)fn()}};g.add(o);hit.push(o);return o};
 E.hit=[hm(.22,.4,.12,1.05,1.1,-.06,()=>elCall(E))];
 // floor display above door
 E.d1=flrTex(String(floor));bx(.4,.2,.04,0,2.42,-.02,new THREE.MeshBasicMaterial({map:E.d1[0]}));
 // inside panel
 const ip=bx(.04,.7,.22,W/2-.03,1.2,D*.55+.1,fm,cab);E.d2=flrTex(String(floor));const dsp=bx(.04,.14,.3,W/2-.045,1.78,D*.55+.1,new THREE.MeshBasicMaterial({map:E.d2[0]}),cab);dsp.rotation.y=0;
 [3,2,1].forEach((n,i)=>{const bt=bx(.03,.07,.07,W/2-.06,1.5-i*.12,D*.55+.1,new THREE.MeshStandardMaterial({color:0x222222,emissive:n==3?0xff6600:0x663300,emissiveIntensity:n==1?.1:.8,roughness:.4}),cab);E.btns.push(bt);
  const h=new THREE.Mesh(new THREE.BoxGeometry(.1,.1,.1),HM);h.position.copy(bt.position);h.userData={fn:()=>{if(E.riding||E.st!='open'&&E.st!='opening')return;elBtn();if(n==1){hintTxt('1 этаж пока недоступен');return}if(n==E.floor){hintTxt('Вы уже здесь');return}elGo(E,n)}};cab.add(h);hit.push(h)});
 // collision
 E.col=[wx-.6,wx+.6,wz-.15,wz+.15,2.3];
 E.cols=[E.col,[wx-.7,wx-.55,wz,wz+1.8,2.3],[wx+.55,wx+.7,wz,wz+1.8,2.3],[wx-.7,wx+.7,wz+1.7,wz+1.85,2.3]];
 E.cols.push(); cols.push(...E.cols);
 E.cab.visible=false;E.shaft.visible=true;E.dl.position.x=-.3;E.dr.position.x=.3;
 ELS.push(E);return E}
const hintTxt=t=>{try{hintEl.textContent=t;hintEl.style.opacity=1;clearTimeout(hintTxt.k);hintTxt.k=setTimeout(()=>hintEl.style.opacity=0,1800)}catch(e){}};
function setDisp(E,txt,col){setFlr(E.d1,txt,col);setFlr(E.d2,txt,col)}
function elCall(E){initAudio();elBtn();if(E.st=='open'||E.st=='opening'){hintTxt('Лифт уже здесь');return}if(E.st!='closed'){return}
 E.st='waiting';E.t=0;E.led.material.emissiveIntensity=1;E.cbtn.material.emissiveIntensity=2.5;E.from=ER()<.5?1:2;E.tt=7+ER()*3;elCreak(E.tt,.3);E.fl=E.from;hintTxt('Лифт вызван…')}
const ER=mk(777);
function elGo(E,n){E.riding=true;E.st='closing';E.t=0;E.target=n;E.tt=5+ER()*2}
function openDoors(E){E.st='opening';E.t=0;elDoor(1,2.2)}
const shake={a:0};
function elevTick(dt){if(shake.a)home.y=1.6+Math.sin(performance.now()*.06)*shake.a+Math.sin(performance.now()*.017)*shake.a;
 ELS.forEach(E=>{if(E.floor!=curFloor&&!E.riding&&E.st=='closed'){return}
 E.t+=dt;const doors=()=>{E.dl.position.x=-.3-.6*E.dp;E.dr.position.x=.3+.6*E.dp};
 switch(E.st){
 case'waiting':{const k=E.t/E.tt;const fl=k<.5?E.from:k<.85?(E.from==1?2:E.from==2?3:3):E.floor;const d=Math.floor(E.t*2)%2?String(fl):(Math.random()<.2?'':String(fl));setDisp(E,k<.9?(Math.floor(E.t*1.5)%3==0?'▲':String(Math.max(1,Math.min(3,Math.round(E.from+(E.floor-E.from)*k))))):String(E.floor),'#ffb020');
  if(E.t>E.tt){elDing();E.cab.visible=true;E.shaft.visible=false;E.L.intensity=8;setDisp(E,String(E.floor));E.led.material.emissiveIntensity=0;E.cbtn.material.emissiveIntensity=.6;openDoors(E)}break}
 case'opening':E.dp=Math.min(1,E.dp+dt/2.2);doors();if(E.dp>=1){E.st='open';E.col.off=true}break;
 case'open':E.t>0;if(E.t>35&&!E.riding&&Math.hypot(home.x-E.wx,home.z-(E.wz+.8))>2.5){E.st='closing';E.t=0;E.auto=1}break;
 case'closing':if(E.dp==1&&E.t==dt)elDoor(0,2.2);E.col.off=false;E.dp=Math.max(0,E.dp-dt/2.2);doors();if(E.dp<=0){if(E.riding){E.st='riding';E.t=0;E.shk=1;elCreak(E.tt,.35);E.sf=E.floor}else{E.st='closed';E.cab.visible=false;E.shaft.visible=true;E.L.intensity=0}}break;
 case'riding':{const k=E.t/E.tt;shake.a=.012*Math.min(1,E.t*2)*(E.t<E.tt-.5?1:.3);const f=k<.5?E.floor:E.target;setDisp(E,k<.5?String(E.floor):String(E.target),'#ffb020');
  if(Math.random()<dt*.5&&AC)aTn({f:60,f2:40,d:.3,g:.2,type:'triangle',send:.8});
  if(E.t>E.tt){shake.a=0;E.riding=false;const T=ELS.find(x=>x.floor==E.target);elArrive(E,T)}break}
 }})}
function elArrive(E,T){ // teleport inside cab to target floor elevator
 E.st='closed';E.cab.visible=false;E.shaft.visible=true;E.L.intensity=0;setDisp(E,String(E.floor));
 const dx=home.x-E.wx,dz=home.z-E.wz;curFloor=T.floor;
 home.x=T.wx+dx;home.z=T.wz+dz;lk='';home.y=1.6;if(T.floor==2){S.fog.color.set(0x15130f);S.fog.density=.09}else{S.fog.color.set(0x2a2410);S.fog.density=.07}T.cab.visible=true;T.shaft.visible=false;T.L.intensity=8;T.dp=0;T.dl.position.x=-.3;T.dr.position.x=.3;setDisp(T,String(T.floor));
 elDing();T.t=0;openDoors(T);T.riding=false;
 if(T.floor==2){ambNote()}}
function ambNote(){hintTxt('Этаж 2')}
// camera shake via home.y offset
const _bobY=()=>shake.a?Math.sin(performance.now()*.05)*shake.a:0;
// --- FLOOR 3 elevator on z=+4 wall; door local x -> world x via rotation pi ---
const E3=(()=>{const P=S;const E=buildElev(P,2.2,4,3);E.g.rotation.y=Math.PI;E.g.position.set(2.2,0,4);
 // adjust: with rotation pi, local +z -> world -z. So build mirrored: put cab behind (world +z) => rotate group by 0 instead
 E.g.rotation.y=0;E.wx=2.2;E.wz=4;return E})();
E3.cols.forEach(c=>{});

// patch collision cols for E3 (wx,wz set at build time already)
