//# FILE: world/materials-kit.js
//# ЧТО: Набор PBR-материалов. Маркер //@TEXTURES:B@ (секция B), хелперы V3/Q4/hp().
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: frm, V3
// ---------- photoreal material kit (procedural, no external files) ----------
//@TEXTURES:B@
const frm=woodDk;
box(.14,.06,2.3,-3.97,.9,-1,frm);box(.14,.06,2.3,-3.97,2.3,-1,frm);box(.14,1.4,.06,-3.97,1.6,-2.1,frm);box(.14,1.4,.06,-3.97,1.6,.1,frm);box(.08,1.4,.04,-3.97,1.6,-1,frm);
const V3=THREE.Vector3,Q4=THREE.Quaternion,HP=[];function hp(o,H,k){o.name=k;o.userData.H0=H;HP.push(o);return o}
