//# FILE: world/cassette.js
//# ЧТО: Магнитофон (тап по кнопкам).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: cas, reelM, cled, hit
// cassette player (tap buttons)
const cas=new THREE.Group();cas.position.set(.8,.78,-.95);cas.rotation.y=-.3;cas.scale.setScalar(1.5);S.add(cas);
box(.5,.12,.3,0,.06,0,dark,cas);box(.46,.012,.26,0,.12,0,metal,cas);
const reelM=new THREE.MeshStandardMaterial({color:0xe8e6dc,roughness:.35,metalness:.1,normalMap:PLN}),reels=[-.08,.08].map(x=>{const c=new THREE.Mesh(new THREE.CylinderGeometry(.045,.045,.012,6),reelM);c.position.set(x,.132,-.02);cas.add(c);return c});
const cled=new THREE.Mesh(new THREE.SphereGeometry(.012,12,12),new THREE.MeshStandardMaterial({color:0x400,emissive:0x000000,emissiveIntensity:3}));cled.position.set(.2,.13,-.1);cas.add(cled);
const [dc,dg]=cv2(256,64),dT=toTex(dc),dp=new THREE.Mesh(new THREE.PlaneGeometry(.26,.065),new THREE.MeshBasicMaterial({map:dT}));dp.rotation.x=-Math.PI/2;dp.position.set(-.04,.1275,-.11);cas.add(dp);
const hit=[scr,pbtn];let musicVol=.8,trackName='';
[['play'],['pause'],['stop'],['load'],['vm'],['vp']].forEach(([a],i)=>{const[c,g]=cv2(128,128);{const q=g.createLinearGradient(0,0,0,128);q.addColorStop(0,'#5a5b5e');q.addColorStop(.5,'#3b3c3f');q.addColorStop(1,'#26272a');g.fillStyle=q;g.fillRect(0,0,128,128);g.fillStyle='rgba(255,255,255,.28)';g.fillRect(6,6,116,5);g.fillStyle='rgba(0,0,0,.5)';g.fillRect(0,0,128,5);g.fillRect(0,0,5,128);g.fillRect(0,123,128,5);g.fillRect(123,0,5,128);grain(g,128,128,500,.15)}
 g.fillStyle='#ececec';g.shadowColor='rgba(0,0,0,.6)';g.shadowBlur=4;g.shadowOffsetY=2;
 if(a==='play'){g.beginPath();g.moveTo(46,34);g.lineTo(46,94);g.lineTo(94,64);g.fill()}else if(a==='pause'){g.fillRect(40,34,16,60);g.fillRect(72,34,16,60)}else if(a==='stop')g.fillRect(38,38,52,52);else if(a==='load'){g.beginPath();g.moveTo(64,32);g.lineTo(96,68);g.lineTo(32,68);g.fill();g.fillRect(32,78,64,14)}else if(a==='vm')g.fillRect(36,58,56,12);else{g.fillRect(36,58,56,12);g.fillRect(58,36,12,56)}
 const b=box(.065,.03,.065,-.2+i*.08,.135,.1,new THREE.MeshStandardMaterial({map:toTex(c),roughness:.5,userData:{flat:1}}),cas);b.userData={act:a,btn:1};hit.push(b)});
