//# FILE: world/room-base.js
//# ЧТО: Стартовая комната: PMREM-окружение, стены/пол/потолок на текстурах (wallTex, carTex, ceilTex…). Маркер //@TEXTURES:A@ — сюда вставляется секция A из textures.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: PBR, shade, BG, rbg, g, p, box, fl, ce, wallP
// ---------- procedural unique textures (no tiling) ----------
//@TEXTURES:A@
{const pm=new THREE.PMREMGenerator(R),es=new THREE.Scene();es.background=new THREE.Color(0x15110a);
 [[0,4,0,6,.2,6,.9,.85,.6],[-4,1.5,0,.2,2,4,.35,.45,.7]].forEach(a=>{const m=new THREE.Mesh(new THREE.BoxGeometry(a[3],a[4],a[5]),new THREE.MeshBasicMaterial({color:new THREE.Color(a[6],a[7],a[8])}));m.position.set(a[0],a[1],a[2]);es.add(m)});
 S.environment=pm.fromScene(es,.03).texture;pm.dispose()}
const PBR=(t,r,b)=>new THREE.MeshStandardMaterial({map:t,roughness:r,bumpMap:t,bumpScale:b,side:THREE.DoubleSide});
const shade=(o,c=true,r=true)=>{o.castShadow=c;o.receiveShadow=r;return o};
const BG=new Map;
function rbg(w,h,d,r){const k=[w,h,d,r].join();if(BG.has(k))return BG.get(k);const a=w/2-r,b=h/2-r,sh=new THREE.Shape();sh.moveTo(-a,-b);sh.lineTo(a,-b);sh.lineTo(a,b);sh.lineTo(-a,b);sh.closePath();
const g=new THREE.ExtrudeGeometry(sh,{depth:d-2*r,bevelEnabled:true,bevelThickness:r,bevelSize:r,bevelSegments:3,curveSegments:1});g.translate(0,0,-(d-2*r)/2);
const p=g.attributes.position,n=g.attributes.normal,u=g.attributes.uv;for(let i=0;i<p.count;i++){const x=Math.abs(n.getX(i)),y=Math.abs(n.getY(i)),z=Math.abs(n.getZ(i));x>=y&&x>=z?u.setXY(i,p.getZ(i),p.getY(i)):y>=z?u.setXY(i,p.getX(i),p.getZ(i)):u.setXY(i,p.getX(i),p.getY(i))}BG.set(k,g);return g}
const box=(w,h,d,x,y,z,m,p=S,r)=>{const mn=Math.min(w,h,d);r=Math.min(r??.012,mn*.45);const o=shade(new THREE.Mesh(Array.isArray(m)||m.userData.flat||mn<.02?new THREE.BoxGeometry(w,h,d):rbg(w,h,d,r),m));o.position.set(x,y,z);p.add(o);return o};
// ---------- room (each surface = its own texture) ----------
const fl=new THREE.Mesh(new THREE.PlaneGeometry(8,8),PBR(carTex(),1,1.2));fl.rotation.x=-Math.PI/2;fl.receiveShadow=true;S.add(fl);
const ce=new THREE.Mesh(new THREE.PlaneGeometry(8,8),PBR(ceilTex(),.95,.6));ce.rotation.x=Math.PI/2;ce.position.y=2.8;S.add(ce);
function wallP(x,z,ry){const m=new THREE.Mesh(new THREE.PlaneGeometry(8,2.8),PBR(wallTex(),.92,.7));m.position.set(x,1.4,z);m.rotation.y=ry;m.receiveShadow=true;S.add(m)}
wallP(0,-4,0);
{const sh=new THREE.Shape();sh.moveTo(-4,0);sh.lineTo(4,0);sh.lineTo(4,2.8);sh.lineTo(-4,2.8);sh.closePath();const h=new THREE.Path();h.moveTo(-2.8,0);h.lineTo(-2.8,2.2);h.lineTo(-1.6,2.2);h.lineTo(-1.6,0);h.closePath();sh.holes.push(h);
 const g=new THREE.ShapeGeometry(sh),p=g.attributes.position,uv=g.attributes.uv;for(let i=0;i<p.count;i++)uv.setXY(i,(p.getX(i)+4)/8,p.getY(i)/2.8);
 const m=new THREE.Mesh(g,PBR(wallTex(),.92,.7));m.position.set(0,0,4);m.rotation.y=Math.PI;m.receiveShadow=true;S.add(m)}
{const sh=new THREE.Shape();sh.moveTo(-4,0);sh.lineTo(4,0);sh.lineTo(4,2.8);sh.lineTo(-4,2.8);sh.closePath();const h=new THREE.Path();h.moveTo(-.1,.9);h.lineTo(-.1,2.3);h.lineTo(2.1,2.3);h.lineTo(2.1,.9);h.closePath();sh.holes.push(h);
 const g=new THREE.ShapeGeometry(sh),p=g.attributes.position,uv=g.attributes.uv;for(let i=0;i<p.count;i++)uv.setXY(i,(p.getX(i)+4)/8,p.getY(i)/2.8);
 const m=new THREE.Mesh(g,PBR(wallTex(),.92,.7));m.position.set(-4,0,0);m.rotation.y=Math.PI/2;m.receiveShadow=true;S.add(m)}
