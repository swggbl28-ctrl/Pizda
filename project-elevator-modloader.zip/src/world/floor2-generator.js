//# FILE: world/floor2-generator.js
//# ЧТО: Процедурный генератор этажа 2: стены, трубы, решётки, лужи, лампы, кирпичи, предметы, спавн лифта.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: gen2
// --- FLOOR 2 procedural generator ---
function gen2(i,j){const ch={i,j,g:new THREE.Group(),cols:[],ph:new Set,lit:true,n:0,sd:[],br:[],wl:[],st:[],it:[],sh:[],lt:[],o:false},cx=i*CS,cz=j*CS,r=mk(hs(i,j,77)),G=ch.g;CH.set(i+','+j,ch);S.add(G);
 const M=(w,h,d,x,y,z,m,p=G)=>{const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);p.add(o);return o},
 col=(x0,x1,z0,z1,h=2.8)=>{const c=[x0,x1,z0,z1,h];ch.cols.push(c);ch.st.push([x0,x1,0,h,z0,z1]);return c},
 reg=(o,H)=>{const u=o.userData;u.h=H;u.id=ch.n++;ch.it.push(o);dyn.push(o);rbInit(o,H)},
 ov=(x,z,a)=>ch.sh.some(s=>x>s[0]-a&&x<s[1]+a&&z>s[2]-a&&z<s[3]+a)||ch.it.some(q=>Math.abs(q.userData.wp.x-x)<a+.1&&Math.abs(q.userData.wp.z-z)<a+.1),
 knock=(o,pt)=>kn(o,pt);
 if(i==0&&j==401)ch.sh.push([1.4,3.0,cz-4.1,cz-1.6]);if(i==0&&j==400)ch.sh.push([cx+.6,cx+3.8,cz+2,cz+4.1]);
 const Z=LAY2.zone(i,j),K=LAY2.K(Z),PUT=(x,z,w,d,h,m,y0=0,sl=1)=>{const o=M(w,h,d,x,y0+h/2,z,m);if(sl)ch.sh.push(col(x-w/2,x+w/2,z-d/2,z+d/2,y0+h));return o},CYP=(x,z,rd,h,m)=>{const o=new THREE.Mesh(CYL2,m);o.scale.set(rd,h,rd);o.position.set(x,h/2,z);G.add(o);ch.sh.push(col(x-rd,x+rd,z-rd,z+rd,h))};
 // floor & ceiling
 const fm=FLZ[Z.t]||CONC;const f=new THREE.Mesh(new THREE.PlaneGeometry(8,8),fm);f.rotation.x=-Math.PI/2;f.position.set(cx,0,cz);f.receiveShadow=true;G.add(f);ch.st.push([cx-4,cx+4,-2,0,cz-4,cz+4],[cx-4,cx+4,2.8,4,cz-4,cz+4]);
 const c=new THREE.Mesh(new THREE.PlaneGeometry(8,8),CONC2);c.rotation.x=Math.PI/2;c.position.set(cx,2.8,cz);G.add(c);
 // puddles
 if(r()<.4){const p=new THREE.Mesh(new THREE.CircleGeometry(.5+r()*1.1,20),PUDDLE);p.rotation.x=-Math.PI/2;p.position.set(cx+(r()-.5)*5*K[0],.006,cz+(r()-.5)*5*K[1]);G.add(p)}
 // walls on owned edges: east (x+4) and south (z+4)
 const edge=(e)=>{const q=mk(hs(i,j,e?11:12)),t=q(),isElev=(!e&&i==0&&j==400),EL=LAY2.edge(i,j,e),ty=isElev?9:EL.t2,d=EL.d,wm=q()<.6?BRK:PLASTER;
  const ex=cx+(e?4:0),ez=cz+(e?0:4),wg=new THREE.Group();wg.position.set(ex,0,ez);wg.rotation.y=e?-Math.PI/2:0;G.add(wg);
  if(ty==0)return;
  const holeAt=isElev?2.2:d,hw=isElev?.6:.55,hh=isElev?2.2:2.2;
  const pts=ty==2?[[-4,0],[4,0],[4,2.8],[-4,2.8]]:[[-4,0],[holeAt-hw,0],[holeAt-hw,hh],[holeAt+hw,hh],[holeAt+hw,0],[4,0],[4,2.8],[-4,2.8]],sh=new THREE.Shape();pts.forEach((p,n)=>n?sh.lineTo(p[0],p[1]):sh.moveTo(p[0],p[1]));
  const gm=new THREE.ShapeGeometry(sh),pp=gm.attributes.position,uv=gm.attributes.uv;gm.userData.own=1;for(let n=0;n<pp.count;n++)uv.setXY(n,(pp.getX(n)+4),pp.getY(n));
  const wall=new THREE.Mesh(gm,wm);wg.add(wall);
  const W=(a,b)=>e?[ex-.12,ex+.12,ez+a,ez+b]:[ex+a,ex+b,ez-.12,ez+.12];
  if(ty==2){col(...W(-4,4))}else{col(...W(-4,holeAt-hw));col(...W(holeAt+hw,4));ch.lt.push([...W(holeAt-hw,holeAt+hw),2.8,hh]);
   // rusty frame + bars
   M(.08,hh,.2,holeAt-hw-.04,hh/2,0,RUSTBAR,wg);M(.08,hh,.2,holeAt+hw+.04,hh/2,0,RUSTBAR,wg);M(hw*2+.16,.1,.2,holeAt,hh+.05,0,RUSTBAR,wg)}
  // decor: rusty pipes along wall
  const pn=isElev?0:q()*3|0;for(let k=0;k<pn;k++){const y=.4+q()*2.2,rd=.04+q()*.06,p=new THREE.Mesh(CYL2,RUST);p.scale.set(rd,8,rd);p.rotation.z=Math.PI/2;p.position.set(0,y,-.12-rd);wg.add(p);
   for(let b=-3;b<=3;b+=2){const br=M(.04,.04,.1,b+q()*.2,y,-.08,RUSTBAR,wg)}if(q()<.5){const v=new THREE.Mesh(CYL2,RUSTP);v.scale.set(.09,.05,.09);v.rotation.x=Math.PI/2;v.position.set(q()*6-3,y,-.12-rd-.07);wg.add(v)}}
  // rusty bars (rebar poking from cracked wall)
  if(!isElev&&q()<.5){for(let k=0;k<5;k++){const b=new THREE.Mesh(CYL2,BARM);b.scale.set(.012,.9+q()*.6,.012);b.position.set(-3.5+q()*7,1.2+q()*1.3,-.15-q()*.15);b.rotation.set(q()*.4-.2,0,q()*.6-.3);wg.add(b)}}
  // cracked-brick chunk spall decals
  };
 edge(1);edge(0);
 LAY2.build(ch,i,j,cx,cz,r,PUT,CYP,ov,PLASTER,Z);
 // special: elevator on floor 2 (chunk 0,400, south wall at x=cx+2.2)
 
 // ceiling pipes (large rusty runs)
 const np=1+(r()*3|0);for(let k=0;k<np;k++){const ax=r()<.5,rd=.07+r()*.12,y=2.45+r()*.25,o=r()*6-3,p=new THREE.Mesh(CYL2,r()<.6?RUST:RUSTP);if(ax){p.scale.set(rd,8,rd);p.rotation.z=Math.PI/2;p.position.set(cx,y,cz+o)}else{p.scale.set(rd,8,rd);p.rotation.x=Math.PI/2;p.position.set(cx+o,y,cz)}G.add(p);
  for(let b=-3;b<=3;b+=1.5){const br=M(ax?.05:.05,2.8-y,.05,ax?cx+b:cx+o,(2.8+y)/2,ax?cz+o:cz+b,RUSTBAR)}
  // flanges
  for(let b=-3;b<=3;b+=2){const fg=new THREE.Mesh(CYL2,RUSTP);fg.scale.set(rd*1.5,.06,rd*1.5);if(ax){fg.rotation.z=Math.PI/2;fg.position.set(cx+b,y,cz+o)}else{fg.rotation.x=Math.PI/2;fg.position.set(cx+o,y,cz+b)}G.add(fg)}}
 // vertical pillars: brick/concrete
 for(let n=Z.t=='hall'||Z.t=='store'?r()*3|0:0;n>0;n--){const x=cx+(r()-.5)*5.5*K[0],z=cz+(r()-.5)*5.5*K[1];if(ov(x,z,.6))continue;const w=.5+r()*.5,pm=r()<.5?BRK2:CONC;M(w,2.8,w,x,1.4,z,pm);const cc=col(x-w/2,x+w/2,z-w/2,z+w/2,2.8);ch.sh.push(cc);
  // chunk of rusty pipe going up pillar
  const vp=new THREE.Mesh(CYL2,RUST);vp.scale.set(.05,2.8,.05);vp.position.set(x+w/2+.06,1.4,z);G.add(vp)}
 // iron bar gates/fences
 if(r()<.35&&(Z.t=='hall'||Z.t=='store')){const x=cx+(r()-.5)*5*K[0],z=cz+(r()-.5)*5*K[1],al=r()<.5,L=2+r()*2;if(!ov(x,z,L/2)){for(let k=0;k<Math.floor(L/.15);k++){const b=new THREE.Mesh(CYL2,RUSTBAR.clone?RUST:RUST);b.scale.set(.012,2.4,.012);b.position.set(al?x-L/2+k*.15:x,1.2,al?z:z-L/2+k*.15);G.add(b)}
  M(al?L:.04,.05,al?.04:L,x,2.3,z,RUST);M(al?L:.04,.05,al?.04:L,x,.3,z,RUST);const cc=al?col(x-L/2,x+L/2,z-.06,z+.06,2.4):col(x-.06,x+.06,z-L/2,z+L/2,2.4);ch.sh.push(cc)}}
 // grate patches on floor
 if(r()<.3){M(1.2,.02,1.2,cx+(r()-.5)*5*K[0],.012,cz+(r()-.5)*5*K[1],GRATE)}
 // lamps (some dead, some flickering)
 if(r()<.6){const lm=new THREE.MeshStandardMaterial({color:0xcfe8c0,emissive:0xb8d8a0,emissiveIntensity:r()<.3?.2:1.6,userData:{}}),x=cx+(r()-.5)*3*K[0],z=cz+(r()-.5)*3*K[1];M(.9,.05,.18,x,2.76,z,lm)}
 // === small physical objects (interactive) ===
 const spawn=(x,y,z,o,H)=>{o.position.set(x,y+H[1],z);o.userData={fn:knock,ch,hh:H[1]};G.add(o);reg(o,H)};
 const kinds=['brick','pipe','bar','can','bottle','crate','bolt','barrel'];
 for(let n=(Z.t=='corr'?1:3)+(r()*7|0);n>0;n--){const x=cx+(r()-.5)*6.8*K[0],z=cz+(r()-.5)*6.8*K[1];if(ov(x,z,.3))continue;const k=kinds[r()*8|0];let o,H;
  if(k=='brick'){o=new THREE.Mesh(BRKG,BRICKM);H=[.11,.035,.0525];o.rotation.y=r()*6.28}
  else if(k=='pipe'){const rd=.03+r()*.02,hl=.12+r()*.2;o=new THREE.Mesh(CYL2,RUST);o.scale.set(rd,hl*2,rd);o.name='c';H=[rd,hl];o.rotation.z=Math.PI/2;/* lie flat */}
  else if(k=='bar'){o=new THREE.Mesh(CYL2,BARM);const hl=.15+r()*.15;o.scale.set(.012,hl*2,.012);o.name='c';H=[.012,hl];o.rotation.z=Math.PI/2}
  else if(k=='can'||k=='bottle'){const q=small(k=='can'?1+(r()*2|0):3,r);o=q[0];H=q[1];}
  else if(k=='crate'){o=new THREE.Mesh(rbg(.4,.3,.35,.015),CB);H=[.2,.15,.175]}
  else if(k=='bolt'){o=new THREE.Mesh(CYL2,RUSTP);o.scale.set(.02,.06,.02);o.name='c';H=[.02,.03]}
  else{const rd=.22,hh=.3;o=new THREE.Mesh(CYL2,RUST);o.scale.set(rd,hh*2,rd);o.name='c';H=[rd,hh]}
  if(o.name=='c'&&(k=='pipe'||k=='bar')){o.rotation.set(0,0,0);} // physics engine rotates cylinders by quaternion; keep upright start, will fall
  const y=0;o.position.set(x,y+(H[1]||.05),z);o.userData={fn:knock,ch,hh:H[1]};G.add(o);reg(o,H);ch.sh.push([x-.2,x+.2,z-.2,z+.2])}
 // loose bricks pile near broken walls
 if(r()<.5){const x=cx+(r()-.5)*5*K[0],z=cz+(r()-.5)*5*K[1];if(!ov(x,z,.5))for(let n=0;n<6;n++){const o=new THREE.Mesh(BRKG,BRICKM);o.rotation.y=r()*6.28;const lv=n/3|0;o.position.set(x+(n%3)*.24-.24+(lv?.1:0),.035+lv*.07,z+r()*.06);o.userData={fn:knock,ch,hh:.035};G.add(o);reg(o,[.11,.035,.0525])}}
 applySave(ch)}
// spawn: ensure floor-2 elevator exists at game start so it works before first visit
(function(){const P=S;const e=buildElev(P,2.2,FZ+4,2);e.wx=2.2;e.wz=FZ+4;const old=gen2;})();

