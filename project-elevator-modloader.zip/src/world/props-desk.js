//# FILE: world/props-desk.js
//# ЧТО: Плинтус, реквизит, стол.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: tFr, pled, pbtn
// props
{const bm=woodDk;box(7.9,.12,.03,0,.06,-3.98,bm);box(7.9,.12,.03,0,.06,3.98,bm);box(.03,.12,.95,3.98,.06,-3.525,bm);box(.03,.12,6.1,3.98,.06,.9,bm);box(.03,.12,7.9,-3.98,.06,0,bm)}
{const pm=t=>new THREE.MeshStandardMaterial({map:t,bumpMap:t,bumpScale:.6,roughness:.42}),iv=new THREE.MeshStandardMaterial({color:0xddd5ba,roughness:.45,normalMap:PLN}),po=pm(plateTex('outlet')),ps=pm(plateTex('switch'));
 box(.08,.12,.012,1.5,.35,-3.99,[iv,iv,iv,iv,po,iv]);box(.08,.12,.012,-2.5,1.2,-3.99,[iv,iv,iv,iv,ps,iv]);const rk=box(.026,.05,.016,-2.5,1.2,-3.978,iv);rk.rotation.x=-.14}

box(.06,1.5,2.4,2.9,.75,-1.5,fab);box(2.4,1.5,.06,1.7,.75,-2.7,fab);
{const pn=new THREE.MeshStandardMaterial({color:0x8f9a93,roughness:.45,metalness:.5,normalMap:PLN}),cf=new THREE.MeshStandardMaterial({map:cabTex(),roughness:.42,metalness:.5});box(.5,1.3,.6,-3.5,.65,-3.6,[pn,pn,pn,pn,cf,pn]);[.3,.65,1.0].forEach(y=>box(.16,.02,.024,-3.5,y,-3.288,chromeM))}

{const vm=new THREE.MeshStandardMaterial({color:0xcfcab4,roughness:.5,normalMap:PLN}),vf=new THREE.MeshStandardMaterial({map:ventTex(),roughness:.55});box(.9,.02,.6,0,2.78,3.2,[vm,vm,vm,vf,vm,vm])}
// desk
box(2.2,.06,.8,0,.75,-1.2,wood,S,.02);[[-1.04,-.86],[1.04,-.86],[-1.04,-1.54],[1.04,-1.54]].forEach(([x,z])=>box(.06,.72,.06,x,.36,z,wood));box(2,.45,.025,0,.5,-1.56,wood);box(2,.05,.04,0,.66,-.86,wood);[-1.04,1.04].forEach(x=>box(.04,.05,.68,x,.66,-1.2,wood));
box(.44,.5,.62,.78,.47,-1.2,wood);[.64,.47,.3].forEach(y=>{box(.4,.14,.02,.78,y,-.89,wood);box(.14,.018,.025,.78,y+.03,-.872,metal)});
const tFr=(()=>{const t=towerTex2();return new THREE.MeshStandardMaterial({map:t,bumpMap:t,bumpScale:1.2,roughness:.5})})(),tw=box(.24,.46,.5,-.75,.26,-1.2,[beige,beige,beige,beige,tFr,beige]);
const pled=box(.02,.02,.02,-.67,.15,-.94,new THREE.MeshStandardMaterial({color:0x0f0,emissive:0x00ff00,emissiveIntensity:3}));
const pbtn=new THREE.Mesh(new THREE.CylinderGeometry(.03,.03,.02,16),new THREE.MeshStandardMaterial({color:0xcccccc,metalness:.8,roughness:.3}));pbtn.rotation.x=Math.PI/2;pbtn.position.set(-.75,.3,-.935);pbtn.userData.act='power';S.add(pbtn);
{const kt=keysTex2(),kb=new THREE.MeshStandardMaterial({map:kt,bumpMap:kt,bumpScale:1.6,roughness:.5}),pt=padTex(),pd=fabM(0x2a3140),pf=new THREE.MeshStandardMaterial({map:pt,bumpMap:pt,bumpScale:.5,roughness:1});
 hp(box(.5,.025,.17,0,.7925,-.95,[beige,beige,kb,beige,beige,beige]),[.25,.0125,.085],'b');hp(box(.06,.03,.1,.42,.795,-.95,beige),[.03,.015,.05],'b');box(.2,.005,.28,.45,.785,-1.5,[pd,pd,pf,pd,pd,pd])}
