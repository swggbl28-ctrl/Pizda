//# FILE: world/weather.js
//# ЧТО: Погода за окном.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: bd, N, rg, DN, dg2, GW, bead, nd, drips
// ---------- weather ----------
const bd=new THREE.Mesh(new THREE.PlaneGeometry(40,20),new THREE.MeshBasicMaterial({color:0x04060c,fog:false}));bd.visible=false;bd.position.set(-11.9,4,-1);bd.rotation.y=Math.PI/2;S.add(bd);
const N=2500,rp=new Float32Array(N*3),rv=new Float32Array(N);for(let i=0;i<N;i++){rp[i*3]=-4.2-Math.random()*9;rp[i*3+1]=Math.random()*8;rp[i*3+2]=-6+Math.random()*10;rv[i]=9+Math.random()*5}
const rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.BufferAttribute(rp,3));
const DN=300,dpos=new Float32Array(DN*3);for(let i=0;i<DN;i++){dpos[i*3]=rnd(-3.8,3.8);dpos[i*3+1]=rnd(0,2.8);dpos[i*3+2]=rnd(-3.8,3.8)}
const dg2=new THREE.BufferGeometry();dg2.setAttribute('position',new THREE.BufferAttribute(dpos,3));S.add(new THREE.Points(dg2,new THREE.PointsMaterial({color:0xffeeaa,size:.012,transparent:true,opacity:.35})));
const GW=1024,GH=640,[gc,gg]=cv2(GW,GH),gT=toTex(gc),glass=new THREE.Mesh(new THREE.PlaneGeometry(2.2,1.4),new THREE.MeshBasicMaterial({map:gT,fog:false}));glass.position.set(-3.95,1.6,-1);glass.rotation.y=Math.PI/2;glass.userData.act='glass';S.add(glass);hit.push(glass);
const [bgc,bgg]=cv2(GW,GH),[bc,bcg]=cv2(GW,GH),[tc,tg]=cv2(GW,GH);
{const g=bgg,q=g.createLinearGradient(0,0,0,GH);q.addColorStop(0,'#05080f');q.addColorStop(.6,'#0b0f1a');q.addColorStop(1,'#151822');g.fillStyle=q;g.fillRect(0,0,GW,GH);
 for(let x=0;x<GW;x+=rnd(30,80)){const h=rnd(80,300),w=rnd(30,90);g.fillStyle=`rgba(${rnd(10,25)|0},${rnd(14,28)|0},${rnd(22,40)|0},.9)`;g.fillRect(x,GH-h,w,h)}
 const CL=['255,200,120','255,240,200','120,170,255','255,120,90','160,255,200'];
 for(let i=0;i<110;i++){const x=rnd(0,GW),y=rnd(GH*.4,GH*.98),r=rnd(6,38),c=CL[i%5],gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(${c},${rnd(.35,.9)})`);gr.addColorStop(.6,`rgba(${c},.12)`);gr.addColorStop(1,`rgba(${c},0)`);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r)}}
function bead(g,x,y,rx,ry){g.save();g.beginPath();g.ellipse(x,y,rx,ry,0,0,6.2832);g.clip();
 g.save();g.translate(x,y);g.scale(-1,-1);g.drawImage(bgc,x-rx*1.7,y-ry*1.7,rx*3.4,ry*3.4,-rx,-ry,rx*2,ry*2);g.restore();
 let q=g.createRadialGradient(x,y-ry*.15,Math.min(rx,ry)*.35,x,y,Math.max(rx,ry));q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,10,.6)');g.fillStyle=q;g.fillRect(x-rx,y-ry,2*rx,2*ry);
 q=g.createRadialGradient(x+rx*.1,y+ry*.62,0,x+rx*.1,y+ry*.62,ry*.7);q.addColorStop(0,'rgba(255,240,210,.55)');q.addColorStop(1,'rgba(255,240,210,0)');g.fillStyle=q;g.fillRect(x-rx,y-ry,2*rx,2*ry);g.restore();
 g.fillStyle='rgba(255,255,255,.85)';g.beginPath();g.ellipse(x-rx*.35,y-ry*.4,rx*.22,ry*.14,-.6,0,6.2832);g.fill();
 g.strokeStyle='rgba(220,235,255,.22)';g.lineWidth=Math.max(.6,rx*.12);g.beginPath();g.ellipse(x,y,rx,ry,0,0,6.2832);g.stroke()}
{for(let i=0;i<2500;i++){bcg.fillStyle=`rgba(200,215,240,${rnd(.04,.14)})`;bcg.beginPath();bcg.arc(rnd(0,GW),rnd(0,GH),rnd(.6,1.5),0,6.2832);bcg.fill()}
 for(let i=0;i<420;i++){const r=i<30?rnd(7,12):rnd(1.6,5);bead(bcg,rnd(0,GW),rnd(0,GH),r,r*rnd(1,1.25))}}
const nd=i=>({x:rnd(30,GW-30),y:i?rnd(-50,GH):rnd(-60,-10),r:rnd(5,12),v:0,t:rnd(0,3),g:rnd(60,160)}),mdr=Array.from({length:16},()=>nd(1));let gacc=0;
function drips(dt){gacc+=dt;if(gacc<1/30)return;dt=gacc;gacc=0;tg.globalCompositeOperation='destination-out';tg.fillStyle='rgba(0,0,0,.03)';tg.fillRect(0,0,GW,GH);tg.globalCompositeOperation='source-over';tg.lineCap='round';
 mdr.forEach((d,i)=>{d.t-=dt;if(d.t<=0){d.v=d.v?0:d.g*rnd(.4,1.4)*d.r/8;d.t=d.v?rnd(.3,1.4):rnd(.5,3)}const py=d.y;d.y+=d.v*dt;d.x+=Math.sin(d.y*.05+i)*.25;
  if(d.v){tg.strokeStyle='rgba(185,205,235,.10)';tg.lineWidth=d.r*1.1;tg.beginPath();tg.moveTo(d.x,py);tg.lineTo(d.x,d.y);tg.stroke();if(Math.random()<.15)bead(bcg,d.x+rnd(-3,3),d.y-d.r,rnd(1,2.2),rnd(1.3,2.8))}
  if(d.y>GH+20)Object.assign(d,nd(0))});
 gg.drawImage(bgc,0,0);gg.drawImage(bc,0,0);gg.drawImage(tc,0,0);mdr.forEach(d=>bead(gg,d.x,d.y,d.r*.8,d.r*1.15));gT.needsUpdate=true}
