//# FILE: world/rooms-content.js
//# ЧТО: Материалы и наполнение комнат. Маркер //@TEXTURES:E@ (секция E: паркет, мебель).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: FILL2, FILL3
// ===== материалы и наполнение комнат =====
//@TEXTURES:E@
function FILL2(t,X){const{i,j,cx,cz,r,put,cyl,ok,H,Z}=X,rn=(a,b)=>a+r()*(b-a);
 if(t=='corr'||t=='plaza'){const ax=Z.ax!='z',pl=t=='plaza';for(let n=rn(2,6)|0;n>0;n--){const a=rn(-3.4,3.4),b=rn(-1.2,1.2),x=pl?rn(-3.5,3.5):ax?a:b,z=pl?rn(-3.5,3.5):ax?b:a;if(!X.ov(cx+x,cz+z,.2))put(cx+x,cz+z,.2,.1,.07,BRICKM,0,0)}return}
 if(t=='hall')[-2.4,2.4].forEach(x=>[-2.4,2.4].forEach(z=>{if(r()<.55&&ok(x,z,.3,.3))put(cx+x,cz+z,.6,.6,2.8,CONC,0,1)}));
 else if(t=='bed'){const nr=hs(i,j,21)&1?-1:1;
  [-3.1,-1.55,0,1.55,3.1].forEach(x=>{const z=nr*2.95;if(r()<.75&&ok(x,z,.5,1.05)){const A=cx+x,B=cz+z;
   put(A,B,.95,2,.3,RUSTBAR,.12,1);put(A,B,.88,1.9,.16,MATT,.42,0);put(A,B+nr*.72,.6,.32,.1,PILL,.58,0)}});
  [-3,-2.2,-1.4,1.4,2.2,3].forEach(x=>{const z=-nr*3.6;if(r()<.45&&ok(x,z,.3,.3))put(cx+x,cz+z,.5,.5,1.9,LOCK,0,1)})}
 else if(t=='store'){for(let n=3+(r()*5|0);n>0;n--){const x=rn(-3.2,3.2),z=rn(-3.2,3.2),w=rn(.7,1.2),d=rn(.7,1.2),h=rn(.6,1.1);if(!ok(x,z,w/2,d/2))continue;
   put(cx+x,cz+z,w,d,h,CB,0,1);if(r()<.4)put(cx+x,cz+z,w*.8,d*.8,.6,CB,h,1)}
  for(let n=r()*3|0;n>0;n--){const x=rn(-3,3),z=rn(-3,3);if(ok(x,z,.35,.35))cyl(cx+x,cz+z,.3,.9,RUST)}}}
function FILL3(t,X){const{i,j,cx,cz,r,put,cyl,ok,it,H,Z}=X,rn=(a,b)=>a+r()*(b-a),W=X.cw;
 const paper=(n,R)=>{for(;n>0;n--){const x=rn(-R,R),z=rn(-R,R);if(!X.ov(cx+x,cz+z,.2))put(cx+x,cz+z,.21,.3,.004,O_PAP,.006,0)}},
 chair=(x,z,sg)=>{put(x,z,.45,.45,.06,O_CHR,.45,0);put(x,z,.06,.06,.4,O_CHR,.05,0);put(x,z+sg*.22,.45,.05,.45,O_CHR,.5,0)},
 pot=(x,z)=>{put(x,z,.34,.34,.35,O_POT,0,1);put(x,z,.3,.3,.55,O_GRN,.35,0)},
 desk=(x,z,w,d)=>{put(x,z,w,d,.04,O_DESK,.7,1);put(x-w/2+.03,z,.05,d-.05,.7,O_DESK,0,0);put(x+w/2-.03,z,.05,d-.05,.7,O_DESK,0,0)};
 if(t=='corr'){const ax=Z.ax=='x',L=X.ws.filter(w=>w.y0),free=a=>L.every(w=>Math.abs((ax?w.x:w.z)-a)>1.1);
  for(let n=0;n<3;n++){const s=r()<.5?-1:1,a=rn(-3.4,3.4);if(!free(a))continue;const x=cx+(ax?a:s*(W-.4)),z=cz+(ax?s*(W-.4):a);
   if(r()<.5)put(x,z,.35,.35,.55,O_BIN,0,1);else pot(x,z)}
  L.forEach(w=>{const a=ax?w.x:w.z,s=Math.sign(ax?w.z:w.x),o=s*(W-.11);put(cx+(ax?a+.8:o),cz+(ax?o:a+.8),ax?.25:.02,ax?.02:.25,.12,O_PLA,1.7,0)});
  paper(rn(1,4)|0,1.6);if(r()<.5)it(cx+(ax?rn(-3,3):rn(-1.5,1.5)),0,cz+(ax?rn(-1.5,1.5):rn(-3,3)));return}
 if(t=='plaza'){[[-3.2,-3.2],[3.2,-3.2],[-3.2,3.2],[3.2,3.2]].forEach(p=>pot(cx+p[0],cz+p[1]));put(cx,cz,1.8,.5,.45,O_CHR,0,1);paper(4,3);return}
 if(t=='cube'){put(cx,cz,6.6,.05,1.4,O_FAB,0,1);
  [-1,1].forEach(sz=>[-2.1,0,2.1].forEach((x,n)=>{if(r()<.2||!ok(x,sz*1.2,1.1,1.2))return;const A=cx+x,B=cz+sz*1.0;
   desk(A,B,1.5,.7);put(A,B-sz*.28,1.4,.03,.45,O_DESK,.25,0);put(A+.2,B-sz*.2,.12,.12,.2,O_KEY,.74,0);put(A+.2,B-sz*.2,.55,.04,.35,O_SCR,.95,0);
   put(A-.1,B+sz*.1,.42,.14,.02,O_KEY,.74,0);put(A-.55,B+sz*.1,.3,.21,.02+r()*.1,O_PAP,.74,0);chair(A,cz+sz*1.95,sz);
   put(A-1.05,cz+sz*.95,.05,1.9,1.35,O_FAB,0,1);if(n==2)put(A+1.05,cz+sz*.95,.05,1.9,1.35,O_FAB,0,1);
   if(r()<.7)it(A+.55,.74,B+sz*.05);if(r()<.4)it(A-.5,.74,B+sz*.2);if(r()<.3)put(A+.6,B-sz*.2,.2,.2,.3,O_BLU,.74,0)}));
  if(ok(-3.6,3.4,.3,.3)&&r()<.6)pot(cx-3.5,cz+3.4);paper(rn(3,8)|0,3.4);for(let n=rn(1,4)|0;n>0;n--)it(cx+rn(-3.4,3.4),0,cz+rn(-3.4,3.4));return}
 if(t=='meet'){if(ok(0,0,1.8,.8)){desk(cx,cz,3.4,1.3);put(cx,cz,3.3,1.2,.7,O_DESK,0,1);
   for(let k=-1;k<=1;k++){chair(cx+k*1.1,cz-1.0,-1);chair(cx+k*1.1,cz+1.0,1)}chair(cx-2,cz,0);chair(cx+2,cz,0);
   for(let n=rn(2,5)|0;n>0;n--)it(cx+rn(-1.4,1.4),.7,cz+rn(-.5,.5));put(cx,cz,.5,.35,.03,O_PAP,.74,0);put(cx+.9,cz,.25,.2,.12,O_SCR,.74,0)}
  const wz=!H.n?-3.93:!H.s?3.93:0;if(wz){put(cx+rn(-1,1),cz+wz,2.6,.04,1.2,O_WHT,1.0,0);put(cx,cz+wz*.97,2.2,.06,.04,O_CHR,.95,0)}
  paper(rn(2,5)|0,3.2);if(ok(3.5,-3.5,.3,.3))pot(cx+3.5,cz-3.5);return}
 if(t=='srv'){[-2.5,2.5].forEach(z=>[-3,-1.5,0,1.5,3].forEach(x=>{if(r()<.15||!ok(x,z,.4,.45))return;const A=cx+x,B=cz+z,f=z<0?1:-1;
   put(A,B,.7,.9,2.0,O_RACK,0,1);for(let n=0;n<5;n++)put(A-.25+(n%3)*.2,B+f*.46,.05,.02,.04,r()<.7?O_LG:r()<.5?O_LR:O_LB,.3+n*.3,0)}));
  put(cx,cz,.5,2,.01,O_CHR,.004,0);paper(2,3);return}
 if(t=='break'){const wz=!H.n?-3.6:3.6,s=wz<0?1:-1;
  if(ok(0,wz,1.6,.35)){put(cx,cz+wz,3.2,.65,.9,O_CNT,0,1);put(cx-1,cz+wz,.5,.35,.3,O_WHT,.9,0);put(cx+.7,cz+wz,.4,.4,.2,O_BIN,.9,0);put(cx+1.2,cz+wz,.25,.25,.1,O_POT,.9,0)}
  if(ok(-3.4,wz,.4,.4))put(cx-3.4,cz+wz,.7,.7,1.8,O_WHT,0,1);if(ok(3.4,wz,.3,.3)){put(cx+3.4,cz+wz,.35,.35,1.0,O_WHT,0,1);put(cx+3.4,cz+wz,.3,.3,.4,O_BLU,1.0,0)}
  [-1.6,1.6].forEach(x=>{if(!ok(x,-wz*.3,.8,.8))return;desk(cx+x,cz-wz*.3,.9,.9);put(cx+x,cz-wz*.3,.85,.85,.7,O_DESK,0,1);chair(cx+x-.7,cz-wz*.3,0);chair(cx+x+.7,cz-wz*.3,0);it(cx+x,.74,cz-wz*.3);if(r()<.6)it(cx+x+.2,.74,cz-wz*.3+.2)});
  if(ok(-3.5,-wz*.8,.3,.3))cyl(cx-3.5,cz-wz*.8,.25,.6,O_BIN);paper(rn(1,4)|0,3);for(let n=rn(1,3)|0;n>0;n--)it(cx+rn(-3,3),0,cz+rn(-3,3));return}
 if(t=='copy'){if(ok(0,0,.6,.5)){put(cx,cz,.9,.7,1.1,O_WHT,0,1);put(cx,cz+.2,.6,.3,.03,O_SCR,1.1,0);put(cx+.2,cz-.2,.3,.21,.2,O_PAP,1.1,0)}
  for(let n=3+(r()*4|0);n>0;n--){const x=rn(-3.2,3.2),z=rn(-3.2,3.2),w=rn(.5,.9);if(!ok(x,z,w/2,w/2))continue;put(cx+x,cz+z,w,w,rn(.3,.7),CB,0,1)}
  [-3,3].forEach(z=>{if(ok(0,z>0?3.5:-3.5,2,.3)&&r()<.7){put(cx,cz+(z>0?3.5:-3.5),3.2,.45,1.9,PM,0,1)}});paper(rn(5,12)|0,3.3);for(let n=rn(1,4)|0;n>0;n--)it(cx+rn(-3,3),0,cz+rn(-3,3))}}
