//# FILE: world/procedural-world.js
//# ЧТО: Бесконечный процедурный мир (этаж 3). Маркер //@TEXTURES:C@ (wm/fm).
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: dyn, RM
// ---------- procedural infinite world ----------
let dyn=[],A=[],dcols=[],dlt=[],lk='';const CH=new Map,CS=8,mk=q=>()=>(q=(q*1664525+1013904223)>>>0)/4294967296,hs=(a,b,c)=>{let h=Math.imul(a+1e5|0,374761393)^Math.imul(b+1e5|0,668265263)^Math.imul(c,2147483647);h=Math.imul(h^h>>>13,1274126177);return(h^h>>>16)>>>0},
vd=(a,b)=>a==-1&&b==0,hintEl=$('hint'),GB={},gb=(w,h,d)=>GB[[w,h,d]]||(GB[[w,h,d]]=new THREE.BoxGeometry(w,h,d)),HM=new THREE.MeshBasicMaterial({visible:false}),
CYL=new THREE.CylinderGeometry(1,1,1,16),TOR=new THREE.TorusGeometry(1,.15,8,20),PG=new THREE.PlaneGeometry(8,8),WM=[],FM=[],
PAL=[['#b8a24a','#8d7a2c'],['#9fb08a','#6f8466'],['#a8a8a0','#77776f'],['#c9a28a','#8e6a55'],['#8a9db0','#5c7088']],
NT=['Уровень 0. Не оглядывайся.','Лампы гудят… считай шаги.','Выход там, где пахнет мокрым ковром.','Дверь за тобой уже другая.','Трубы стонут по ночам.','Здесь никто не ждёт. Но кто-то слушает.'];
//@TEXTURES:C@
const RM=(()=>{const[c,g]=cv2(256,256);g.fillStyle='#7a3f1c';g.fillRect(0,0,256,256);blot(g,256,256,60,10,60,'200,110,40',.6);blot(g,256,256,40,10,50,'30,15,5',.6);grain(g,256,256,4000,.3);return new THREE.MeshStandardMaterial({map:toTex(c),roughness:.95,metalness:.4})})(),
PM=new THREE.MeshStandardMaterial({color:0x7d857f,roughness:.4,metalness:.8}),CB=cbMat(),plm=new THREE.MeshStandardMaterial({color:0xe8e4d0,roughness:.4}),
PAP=new THREE.MeshStandardMaterial({color:0xe8dfb8,roughness:.8}),cm=new THREE.MeshStandardMaterial({color:0xaa3a2a,roughness:.5,metalness:.3}),ply=new THREE.PointLight(0xffe9b0,0,10,1.5);S.add(ply);

