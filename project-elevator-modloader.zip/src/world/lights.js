//# FILE: world/lights.js
//# ЧТО: Освещение комнаты.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: LAMP, hemi, sun
// ---------- lights ----------
const LAMP=new THREE.MeshStandardMaterial({color:0xffffff,emissive:0xffffff,emissiveMap:lampTex(),emissiveIntensity:2.2,userData:{flat:1}}),lamps=[];[[0,-.5],[0,2.5],[0,-3]].forEach(([x,z],i)=>{box(1.2,.05,.4,x,2.77,z,LAMP);
 const l=i==0?new THREE.SpotLight(0xfff0b0,60,10,1.2,.6,1.5):new THREE.PointLight(0xfff0b0,18,10);l.position.set(x,2.6,z);if(i==0){l.target.position.set(0,0,-1.2);S.add(l.target);l.castShadow=true;l.shadow.mapSize.set(2048,2048);l.shadow.bias=-.0005}S.add(l);lamps.push([l,i==0?60:18])});
const hemi=new THREE.HemisphereLight(0xcfc48a,0x3a3318,.5);S.add(hemi);
const sun=new THREE.DirectionalLight(0xcfd8ff,0);sun.position.set(-9,3,-1);S.add(sun);
