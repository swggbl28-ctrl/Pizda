//# FILE: world/extra-detail.js
//# ЧТО: Дополнительные мелкие детали комнаты.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
// ---------- extra detail ----------
{const cyl=(r,h,x,y,z,m)=>{const o=shade(new THREE.Mesh(new THREE.CylinderGeometry(r,r,h,24),m));o.position.set(x,y,z);S.add(o);return o};
 const seat=fabM(0x4a4a3e);
 box(.5,.08,.5,0,.5,-.4,seat,S,.03);box(.46,.5,.07,0,.82,-.14,seat,S,.03);[-1,1].forEach(q=>{box(.04,.04,.34,q*.27,.67,-.36,dark);box(.04,.17,.04,q*.27,.585,-.3,dark)});box(.05,.18,.05,0,.38,-.4,metal);cyl(.03,.3,0,.2,-.4,metal);
 for(let i=0;i<5;i++){const a=i*1.2566,b=box(.3,.025,.045,Math.cos(a)*.15,.07,-.4+Math.sin(a)*.15,dark);b.rotation.y=-a;cyl(.025,.04,Math.cos(a)*.3,.04,-.4+Math.sin(a)*.3,dark)}
 const mug=cyl(.04,.09,-.9,.835,-1.4,new THREE.MeshPhysicalMaterial({map:mugTex(),roughness:.12,clearcoat:1,clearcoatRoughness:.05}));{const d=cyl(.034,.005,-.9,.878,-1.4,new THREE.MeshPhysicalMaterial({color:0x2a1608,roughness:.05,clearcoat:1}));d.position.set(0,.043,0);mug.add(d)}{const h=shade(new THREE.Mesh(new THREE.TorusGeometry(.022,.006,8,16),new THREE.MeshPhysicalMaterial({color:0xf2efe6,roughness:.12,clearcoat:1})));h.position.set(.04,0,0);mug.add(h);hp(mug,[.04,.045,.04],'c')}
 const [pc,pg]=cv2(768,1080);pg.scale(3,3);pg.fillStyle='#d9d2b0';pg.fillRect(0,0,256,360);blot(pg,256,360,6,20,80,'120,90,30',.3);pg.fillStyle='#222';pg.fillRect(16,16,224,200);pg.fillStyle='#b9a24a';pg.font='bold 34px sans-serif';pg.textAlign='center';pg.fillText('DON\'T',128,100);pg.fillText('LOOK BACK',128,150);pg.fillStyle='#222';pg.font='20px sans-serif';pg.fillText('Level 0  ·  Office',128,260);pg.fillText('Safety first',128,300);grain(pg,256,360,2500,.2);posterFx(pg);
 const po=new THREE.Mesh(new THREE.PlaneGeometry(.6,.84),(()=>{const t=toTex(pc);return new THREE.MeshStandardMaterial({map:t,bumpMap:t,bumpScale:.8,roughness:.55})})());po.position.set(-1.5,1.6,-3.985);S.add(po);
 const clk=new THREE.Group();clk.position.set(2.2,2.2,-3.99);S.add(clk);let hH,hM,hS;
 {const ft=clockFace(),face=new THREE.Mesh(new THREE.CircleGeometry(.2,64),new THREE.MeshStandardMaterial({map:ft,bumpMap:ft,bumpScale:.5,roughness:.55}));face.position.z=.012;clk.add(face);
  const rim=shade(new THREE.Mesh(new THREE.TorusGeometry(.207,.016,16,64),new THREE.MeshStandardMaterial({color:0x151518,roughness:.35,normalMap:PLN})));rim.position.z=.016;clk.add(rim);
  const back=new THREE.Mesh(new THREE.CylinderGeometry(.215,.215,.024,48),dark);back.rotation.x=Math.PI/2;back.position.z=.01;clk.add(back);
  const gl=new THREE.Mesh(new THREE.CircleGeometry(.2,64),new THREE.MeshPhysicalMaterial({color:0xffffff,transparent:true,opacity:.1,roughness:.02,clearcoat:1,depthWrite:false}));gl.position.z=.03;clk.add(gl);
  const hand=(l,w,col,z)=>{const p=new THREE.Group(),sh=new THREE.Shape();sh.moveTo(-w/2,-l*.18);sh.lineTo(-w*.35,l*.82);sh.lineTo(0,l);sh.lineTo(w*.35,l*.82);sh.lineTo(w/2,-l*.18);sh.closePath();const m=shade(new THREE.Mesh(new THREE.ShapeGeometry(sh),new THREE.MeshStandardMaterial({color:col,roughness:.4,side:THREE.DoubleSide})));m.position.z=z;p.add(m);clk.add(p);return p};
  hH=hand(.11,.014,0x15151a,.018);hM=hand(.165,.01,0x15151a,.021);hS=hand(.18,.0035,0xc0201a,.024);
  const cap=new THREE.Mesh(new THREE.CylinderGeometry(.008,.008,.012,16),new THREE.MeshStandardMaterial({color:0xc0201a,roughness:.3}));cap.rotation.x=Math.PI/2;cap.position.z=.027;clk.add(cap)}
 const tick=()=>{const d=new Date(),s=d.getSeconds()+d.getMilliseconds()/1000,m=d.getMinutes()+s/60,h=d.getHours()%12+m/60;hH.rotation.z=-h*Math.PI/6;hM.rotation.z=-m*Math.PI/30;hS.rotation.z=-s*Math.PI/30};tick();setInterval(tick,100);
 const [xc,xg]=cv2(4,4);xg.fillStyle='rgba(0,0,0,.4)';xg.fillRect(3,0,1,4);xg.fillRect(0,3,4,1);const xT=new THREE.CanvasTexture(xc);xT.wrapS=xT.wrapT=THREE.RepeatWrapping;xT.repeat.set(1024,576);xT.anisotropy=AN;
 const px=new THREE.Mesh(new THREE.PlaneGeometry(.92,.52),new THREE.MeshBasicMaterial({map:xT,transparent:true,depthWrite:false}));px.position.set(0,1.22,-1.3675);S.add(px)}
