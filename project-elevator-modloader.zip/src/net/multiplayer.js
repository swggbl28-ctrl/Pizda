//# FILE: net/multiplayer.js
//# ЧТО: Мультиплеер: удалённый игрок, синхронизация, скины по сети, индикатор связи.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
//# ТОП-УРОВЕНЬ: mpTick, rp, mkTex, rmb, rSkN, rSkin, rSkIn, sendSkin, raTick, lc, ls, label, hud, v, sk, ap, rel, eid
// ---------- MP: удалённый игрок, синхронизация, индикатор связи ----------
let mpTick=()=>{};
{const Nt=window.Net,GS=window.GameSettings,mt=c=>new THREE.MeshStandardMaterial({color:c,roughness:.6});
const rp=new THREE.Group();
// удалённый игрок = та же Minecraft-модель, что и у тебя в одиночной игре, но со своим материалом (скин приходит по сети)
const mkTex=c=>{const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.magFilter=THREE.NearestFilter;t.anisotropy=AN;return t},
RM=new THREE.MeshStandardMaterial({map:mkTex(STC),roughness:.85});RM.onBeforeCompile=SM.onBeforeCompile;RM.customProgramCacheKey=SM.customProgramCacheKey;
const rmb=(w,h,d,ox,oy,piv,P)=>{const m=new THREE.Mesh(mcg(w,h,d,ox,oy,piv,P),RM);m.receiveShadow=true;return m},
rsp=(w,x,y)=>{const u=rmb(w,6,4,x,y,1,0),l=rmb(w,6,4,x,y,1,1);l.position.y=-6*U;u.add(l);u.userData.f=l;return u},
rTo=rmb(8,12,4,16,16),rHd=rmb(8,8,8,0,0),rAR=rsp(4,40,16),rAL=rsp(4,32,48),rLR=rsp(4,0,16),rLL=rsp(4,16,48),rSp=new THREE.Group(),rBody=new THREE.Group(),ra={ph:0,amp:0,lean:0};
rSp.position.y=12*U;rTo.position.y=6*U;rHd.position.y=16*U;rAR.position.set(6*U,12*U,0);rAL.position.set(-6*U,12*U,0);rLR.position.set(2*U,12*U,0);rLL.position.set(-2*U,12*U,0);
rHd.rotation.order='YXZ';rSp.add(rTo,rHd,rAR,rAL);rBody.add(rSp,rLR,rLL);
let rSkN=0;
function rSkin(c,slim){RM.map.dispose();RM.map=mkTex(c);RM.needsUpdate=true;
 const w=slim?3:4;[[rAR,40,16],[rAL,32,48]].forEach(([a,x,y])=>{a.geometry.dispose();a.userData.f.geometry.dispose();a.geometry=mcg(w,6,4,x,y,1,0);a.userData.f.geometry=mcg(w,6,4,x,y,1,1)});rAR.position.x=(4+w/2)*U;rAL.position.x=-(4+w/2)*U}
// получили скин соперника (PNG 64×64 в base64): проверяем и надеваем на удалённого игрока
function rSkIn(d){const u=d.d;if(u==null){rSkN++;rSkin(STC,false);return}
 if(typeof u!=='string'||u.length>150000||!/^data:image\/png;base64,[A-Za-z0-9+\/=]+$/.test(u))return;
 const n=++rSkN;loadImg(u).then(im=>{if(n!==rSkN)return;const[c,g]=cv2(64,64);g.drawImage(im,0,0,64,64);rSkin(c,!!d.sl)}).catch(()=>{})}
// отправка своего текущего скина (по надёжному каналу rel — с повтором, пока не подтвердят)
function sendSkin(){if(!on)return;let d=null,sl=0;const k=SKS>=0&&SKL[SKS];if(k){try{d=k.cv.toDataURL('image/png');sl=k.slim?1:0}catch(e){d=null}}rel({t:'s',d,sl})}
// ходьба/голова удалённого игрока (те же формулы, что у твоего тела в bodyTick)
function raTick(dt,mx,mz){const sp=Math.hypot(mx,mz)/Math.max(dt,1e-3);
 ra.amp+=(Math.min(1.5,sp/1.7)-ra.amp)*Math.min(1,dt*10);ra.ph+=sp*dt*4.2;
 const a=ra.amp,ph=ra.ph,w=a*.8,fL=ph+Math.PI,gt=f=>Math.sin(f)+.22*Math.sin(2*f+.6),kn=f=>{const c=Math.max(0,Math.cos(f-.35));return .1+c*c*1.05},br=Math.sin(performance.now()*.0017)*.012;
 ra.lean+=(Math.min(1,a)*.12-ra.lean)*Math.min(1,dt*6);
 rLR.rotation.x=gt(ph)*w;rLL.rotation.x=gt(fL)*w;rLR.userData.f.rotation.x=-kn(ph)*a;rLL.userData.f.rotation.x=-kn(fL)*a;
 rAL.rotation.x=.1+gt(ph-.45)*w;rAR.rotation.x=.1+gt(fL-.45)*w;
 rAL.userData.f.rotation.x=.2+a*(.25+.3*Math.sin(ph+1.2));rAR.userData.f.rotation.x=.2+a*(.25+.3*Math.sin(fL+1.2));
 rAR.rotation.z=.05+a*.05*Math.sin(ph);rAL.rotation.z=-.05+a*.05*Math.sin(ph);
 rSp.rotation.set(ra.lean+br,-Math.sin(ph)*.14*a,Math.cos(ph)*.05*a);
 const hy=tw-rp.rotation.y;rHd.rotation.set(tpt,Math.atan2(Math.sin(hy),Math.cos(hy)),0)}
const lc=document.createElement('canvas');lc.width=256;lc.height=64;const lt=new THREE.CanvasTexture(lc);lt.colorSpace=THREE.SRGBColorSpace;
const ls=new THREE.Sprite(new THREE.SpriteMaterial({map:lt,transparent:true,fog:false}));ls.scale.set(1,.25,1);ls.position.y=2.05;
rp.add(rBody,ls);rp.visible=false;S.add(rp);
const label=n=>{const g=lc.getContext('2d');g.clearRect(0,0,256,64);g.font='bold 34px sans-serif';g.textAlign='center';g.lineWidth=6;g.strokeStyle='#000';g.fillStyle='#fff';g.strokeText(n,128,44);g.fillText(n,128,44);lt.needsUpdate=true};
const hud=document.createElement('div');hud.style.cssText='position:fixed;top:6px;right:8px;z-index:9998;font:12px system-ui;color:#fff;background:#0008;padding:4px 8px;border-radius:8px;pointer-events:none;display:none';document.body.appendChild(hud);
const v=new THREE.Vector3(),v2=new THREE.Vector3();
const sk=o=>{const u=o.userData;if(u.sid!=null)return'h'+u.ch.i+','+u.ch.j+':'+u.sid;if(u.id!=null&&u.ch)return'i'+u.ch.i+','+u.ch.j+':'+u.id;o.getWorldPosition(v2);return'p'+Math.round(v2.x*100)+','+Math.round(v2.y*100)+','+Math.round(v2.z*100)};
const ap=m=>{const o=hit.concat(dyn).find(o=>sk(o)===m.k);if(!o)return 0;const u=o.userData;u.fn?u.fn(o,new THREE.Vector3(m.x,m.y,m.z)):act(u.act,o);return 1};
const rel=m=>{m.e=++eid;eq.push(m);Nt.send(m)};
Object.assign(window.mp,{sync(o,p){on&&rel({t:'i',k:sk(o),x:p?p.x:0,y:p?p.y:0,z:p?p.z:0})},ev(m){on&&rel(m)},skin:sendSkin});
let eid=0,rx=0,eq=[],pend=[],lRt=0,lRe=0,on=0,seq=0,rs=-1,rcv=0,lost=0,rtt=0,jit=0,lTx=0,lPing=0,lRx=0,tx=0,ty=1.6,tz=0,tw=0,tpt=0;
Nt.onData=d=>{
 if(d.t==='p'){if(d.s>rs){if(rs>=0)lost+=d.s-rs-1;rs=d.s;rcv++;if(rcv+lost>200){rcv>>=1;lost>>=1}tx=d.x;ty=d.y;tz=d.z;tw=d.w;tpt=d.p;if(!rp.visible){rp.visible=true;rp.position.set(tx,0,tz);rp.rotation.y=tw}}lRx=performance.now()}
 else if(d.t==='h')label(d.n||'Игрок');
 else if(d.t==='a')Nt.send({t:'b',ts:d.ts});
 else if(d.t==='z')eq=eq.filter(m=>m.e>d.e);
 else if(d.e){if(d.e===rx+1){rx++;if(d.t==='i'){ap(d)||pend.push(d)}else if(d.t==='k')strike(d.d);else if(d.t==='s')rSkIn(d)}Nt.send({t:'z',e:rx})}
 else if(d.t==='b'){const r=performance.now()-d.ts;if(rtt)jit+=(Math.abs(r-rtt)-jit)/8;rtt=rtt?rtt+(r-rtt)/4:r}};
document.addEventListener('game:start',e=>{on=e.detail.mode==='mp';mp.on=on;mp.host=Nt.isHost;eid=rx=0;eq=[];pend=[];hud.style.display=on?'block':'none';if(!on)return;seq=0;rs=-1;rcv=lost=0;rtt=jit=0;lRx=lPing=performance.now();label('…');rSkN++;rSkin(STC,false);Nt.send({t:'h',n:GS.name||'Игрок'});sendSkin()});
document.addEventListener('game:stop',()=>{on=0;mp.on=0;rp.visible=false;hud.style.display='none'});
mpTick=(dt,now)=>{if(!on)return;
 if(now-lTx>=16){lTx=now;v.set(0,0,-1).applyQuaternion(fq);Nt.send({t:'p',s:seq++,x:home.x,y:home.y,z:home.z,w:Math.atan2(-v.x,-v.z),p:Math.asin(Math.max(-1,Math.min(1,v.y)))})}
 if(pend.length&&now-lRt>500){lRt=now;pend=pend.filter(m=>!ap(m)).slice(-200)}
 if(eq.length&&now-lRe>250){lRe=now;eq.forEach(m=>Nt.send(m))}
 if(now-lPing>=1000){lPing=now;Nt.send({t:'a',ts:now});Nt.send({t:'h',n:GS.name||'Игрок'});
  const lp=lost/Math.max(1,lost+rcv)*100,dead=now-lRx>2000,c=dead||rtt>180||lp>5?'#f55':rtt>90||jit>25||lp>1?'#fb3':'#5f5';
  hud.innerHTML=`<span style="color:${c}">●</span> ${dead?'нет связи':Math.round(rtt)+' мс'} ±${Math.round(jit)} · потери ${lp.toFixed(0)}%`}
 if(!rp.visible)return;const k=Math.min(1,dt*15),p=rp.position,ox=p.x,oz=p.z;p.x+=(tx-p.x)*k;p.z+=(tz-p.z)*k;
 rp.rotation.y+=Math.atan2(Math.sin(tw-rp.rotation.y),Math.cos(tw-rp.rotation.y))*k;raTick(dt,p.x-ox,p.z-oz)}}
R.setAnimationLoop(()=>{const dt=Math.min(clk.getDelta(),.05),now=performance.now();
 adapt(dt);walk(dt);procTick(dt);elevTick(dt);if(fr<2)R.shadowMap.needsUpdate=true;if(now>next&&(!mp.on||mp.host)){const d=Math.pow(Math.random(),.7);strike(d);mp.ev({t:'k',d});next=now+7000+Math.random()*12000}
 const f=flashEnv();glass.material.color.setScalar(1+f*4);hemi.intensity=.5+f*2.5;sun.intensity=f*6;bd.material.color.copy(bgDark).lerp(bgFl,f);
 fk=Math.random()<.012?.15:Math.min(1,fk+.15);lamps.forEach(([l,b])=>l.intensity=b*fk*(.92+Math.random()*.08));
 
 const dq=dg2.attributes.position;for(let i=0;i<DN;i++){dq.setY(i,(dq.getY(i)+dt*.03)%2.8);dq.setX(i,dq.getX(i)+Math.sin(now*.0003+i)*.0007)}dq.needsUpdate=true;
 drips(dt);if(playing())reels.forEach(r=>r.rotation.y+=dt*4);pled.material.emissiveIntensity=power?2+Math.sin(now*.01):0;
 if(!(fr++%((mode==='video'||mode==='emu')?(zoomed?2:3):20)))drawScreen();
 qo.setFromEuler(eu.set(pitch,yaw,0,'YXZ'));
 if(hasGyro&&gyroOn&&!tp){tq.copy(qo).multiply(devQ);fq.slerp(tq,.18)}else fq.copy(qo);bodyTick(dt);
 zk=Math.min(1,Math.max(0,zk+(zoomed?dt:-dt)*2.2));const e=zk*zk*(3-2*zk),th=Math.tan(36*Math.PI/180),dist=Math.max(.26/th,.46/(th*cam.aspect))*1.03;
 tpCam(dt);cam.position.lerpVectors(camBase,tgt.set(0,1.22,-1.368+dist),e);cam.quaternion.copy(fq).slerp(ID,e);cam.fov=72+rk*8;cam.updateProjectionMatrix();cam.updateMatrixWorld();placeWeb();placeVp();bodyCaps();mpTick(dt,now);
 R.render(S,cam)});
