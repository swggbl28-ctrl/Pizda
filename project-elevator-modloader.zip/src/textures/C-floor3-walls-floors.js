//@@C  ===== Материалы стен (wm) и полов (fm) этажа 3: палитры, обои, ковёр =====
//# FILE: textures/C-floor3-walls-floors.js — wm(k) — обои этажа 3, fm(k) — полы этажа 3 (используют PAL, WM, FM, mk из игры).
//# НЕ ЛОМАТЬ: имена функций/констант (их зовёт игра), размеры холстов и раскладку UV (клавиши, шкаф, башня, монитор).
//# ТОП-УРОВЕНЬ: TX_rc, wm, fm
const TX_rc={};function TX_rgb(s){if(TX_rc[s])return TX_rc[s];const[c,g]=cv2(1,1);g.fillStyle=s;g.fillRect(0,0,1,1);const d=g.getImageData(0,0,1,1).data;return TX_rc[s]=[d[0],d[1],d[2]]}
function wm(k){if(WM[k])return WM[k];const W=1024,H=384,[m,g]=cv2(W,H),[a,b]=PAL[k/10|0],p=k%10,r=mk(k*7919+1),A=TX_rgb(a),B=TX_rgb(b);
 g.fillStyle='#000';g.fillRect(0,0,W,H);g.fillStyle=g.strokeStyle='#f00';g.lineWidth=6;
 if(p==0)for(let x=0;x<W;x+=40)g.fillRect(x,0,20,H);
 else if(p==1)for(let y=0;y<H;y+=32)for(let x=y/32%2*32;x<W;x+=64)g.fillRect(x+2,y+2,60,28);
 else if(p==2)for(let y=0;y<H;y+=40)for(let x=0;x<W;x+=40){g.beginPath();g.moveTo(x,y+20);g.lineTo(x+20,y);g.lineTo(x+40,y+20);g.lineTo(x+20,y+40);g.fill()}
 else if(p==3){for(let i=0;i<W;i+=64)g.fillRect(i,0,3,H);for(let i=0;i<H;i+=64)g.fillRect(0,i,W,3)}
 else if(p==4){g.fillRect(0,H*.55,W,H);g.fillStyle='#ff0';g.fillRect(0,H*.55-6,W,6)}
 else if(p==5)for(let i=0;i<500;i++){g.beginPath();g.arc(r()*W,r()*H,3+r()*4,0,6.3);g.fill()}
 else if(p==6)blot(g,W,H,80,40,200,'255,0,0',1);
 else if(p==7)for(let x=0;x<W;x+=r()*50+20)g.fillRect(x,0,3,H);
 else if(p==8)for(let y=0;y<H;y+=48)for(let x=y/48%2*48;x<W;x+=96)g.fillRect(x,y,48,48);
 else for(let y=0;y<H;y+=40){g.beginPath();for(let x=0;x<=W;x+=32)g.lineTo(x,y+x/32%2*20);g.stroke()}
 const M=g.getImageData(0,0,W,H).data,hue=r()*360,tn=TX_rgb(`hsl(${hue|0},35%,50%)`),sd=r()*50,w2=W>>1,h2=H>>1,[o0,og0]=cv2(w2,h2),im=og0.createImageData(w2,h2),d=im.data;let i=0;
 for(let y=0;y<h2;y++)for(let x=0;x<w2;x++,i+=4){const u=x/w2,v=y/h2,mi=(y*2*W+x*2)*4,al=.35*M[mi]/255+.3*M[mi+1]/255,e=(y>5&&y<h2-5&&x>5&&x<w2-5)?((M[mi+W*8+8]-M[mi-W*8-8])/255):0,
  n=TX_fp(u*16,v*6,16,6,3),f=TX_pn(u*256,v*96,256,96),bl=TX_fp(u*7+sd,v*3,7,3,3),st=TX_sm(.55,.8,TX_fp(u*60+sd,v*2.5,60,3,2))*Math.pow(1-v,1.3),dm=TX_sm(.58,.8,bl);
  let c=[A[0]+(B[0]-A[0])*al,A[1]+(B[1]-A[1])*al,A[2]+(B[2]-A[2])*al];c=TX_mc(c,tn,.07);
  let l=(.84+.3*n)*(.92+.14*f)*(1+e*.22)*(1-.35*dm)*(1-.25*TX_sm(.6,1,v))*(.82+.18*TX_sm(0,.12,v));c=TX_mc([c[0]*l,c[1]*l,c[2]*l],[40,28,6],st*.4);
  if(y>h2-13){const q=(y-(h2-13))/13,w=TX_mc([62,46,28],[38,28,16],q),lw=.85+.3*TX_pn(u*64,v*8,64,8),hl=y<h2-11?1.4:1;c=[w[0]*lw*hl,w[1]*lw*hl,w[2]*lw*hl]}
  d[i]=c[0];d[i+1]=c[1];d[i+2]=c[2];d[i+3]=255}
 og0.putImageData(im,0,0);const[o,og]=TX_up(o0,W,H);grain(og,W,H,9000,.14);
 return WM[k]=new THREE.MeshStandardMaterial({map:toTex(o),roughness:.92,side:THREE.DoubleSide})}
function fm(k){if(FM[k])return FM[k];const r=mk(k*131+7),P=['#6b6636','#55524a','#7a6a4a','#4a4d52','#5f6b52','#6a5a56','#74705c','#4f5a63','#6e5f3a','#58504a','#66705e','#7b7468'],B=TX_rgb(P[k]),tile=k%4==1,
 xs=[],ys=[];if(tile){for(let x=0;x<1024;x+=90+r()*110)xs.push(x);for(let y=0;y<1024;y+=90+r()*110)ys.push(y)}
 const S=384,dx=new Float32Array(S),dy=new Float32Array(S);if(tile){for(let i=0;i<S;i++){dx[i]=Math.min(...xs.map(x=>Math.abs(x*S/1024-i)),Math.abs(S-i));dy[i]=Math.min(...ys.map(y=>Math.abs(y*S/1024-i)),Math.abs(S-i))}}
 const c=TX_px(S,S,(u,v)=>{const a=TX_fp(u*8,v*8,8,8,5),b=TX_fp(u*32,v*32,32,32,4),t=TX_pn(u*256,v*256,256,256),st=TX_sm(.6,.78,TX_fp(u*5,v*5,5,5,4)),lt=TX_sm(.6,.8,TX_fp(u*6+3,v*6,6,6,4)),sp=TX_sm(.8,.9,TX_fp(u*14,v*14,14,14,3));
  let c=B,l=(.8+.4*a)*(.92+.16*b),h=t*.5+b*.3;
  if(tile){const x=u*S|0,y=v*S|0,e=Math.min(dx[x],dy[y]),gr=1-TX_sm(.5,1.6,e),tt=TX_h(Math.floor(u*8),Math.floor(v*8));l*=.9+.2*tt;l*=(.94+.12*TX_pn(u*128,v*128,128,128));c=TX_mc(c,[24,20,14],gr*.8);h=h*(1-gr)-gr*.6}
  else l*=(.8+.4*t);
  c=TX_mc([c[0]*l,c[1]*l,c[2]*l],[26,18,6],st*.5);c=TX_mc(c,[230,220,170],lt*.1);c=TX_mc(c,[20,14,4],sp*.5);return[c[0],c[1],c[2],h]},tile?2:2.5),[o,g]=TX_up(c,1024,1024);
 g.strokeStyle='rgba(0,0,0,.22)';g.beginPath();for(let i=0;i<(tile?3000:7000);i++){const x=r()*1024,y=r()*1024,a=r()*6.3,l=3+r()*6;g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke();grain(g,1024,1024,30000,.18);
 const t=toTex(o);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(1.5,1.5);return FM[k]=new THREE.MeshStandardMaterial({map:t,roughness:tile?.75:1})}

