//@@E  ===== Материалы новых комнат: паркет, мебель, офисные материалы =====
//# FILE: textures/E-rooms-materials.js — Паркет (PARQ), FLZ/FL3, офисные материалы O_*, MATT, PILL, LOCK.
//# НЕ ЛОМАТЬ: имена функций/констант (их зовёт игра), размеры холстов и раскладку UV (клавиши, шкаф, башня, монитор).
//# ТОП-УРОВЕНЬ: woodFn, PARQ
const woodFn=(u,v)=>{const P=5,pi=Math.floor(u*P),fx=u*P-pi,vv=v*3+pi*.4,row=Math.floor(vv),fy=vv-row,ed=Math.min(Math.min(fx,1-fx)*1024/P,Math.min(fy,1-fy)*1024/3),gr=sm(1,5,ed),h1=H1(pi,row),g=TX_fp(u*60,v*6,60,6,4),s=N1(u,v,64,3),fib=TX_pn(u*300,v*20,300,20);
 let c=mc([70,44,26],[128,86,52],h1*.7+g*.5);const k=(.7+.5*s)*(.92+.16*fib);c=mc([18,12,8],[c[0]*k,c[1]*k,c[2]*k],gr);return[c[0],c[1],c[2],gr*(.6+.3*g)+fib*.06,.7+.1*(1-gr),0]};
const PARQ=PH(1024,4,4,woodFn,{k:5}),FLZ={corr:TILEF,plaza:TILEF,bed:PARQ,hall:CONC,store:CONC},FL3={meet:PARQ,break:TILEF,srv:CONC,copy:TILEF},
OM=(c,r=.8,m=0,n=0)=>new THREE.MeshStandardMaterial(n?{color:c,roughness:r,metalness:m,normalMap:PLN,normalScale:new THREE.Vector2(n,n)}:{color:c,roughness:r,metalness:m}),
MATT=fabM(0x6c7480),PILL=fabM(0xd8d4c6),LOCK=OM(0x4d5a52,.45,.6,.3),
O_DESK=new THREE.MeshStandardMaterial({color:0xb8987a,map:WT,normalMap:WN,roughness:.55}),O_SCR=OM(0x07090c,.15,.3),O_KEY=OM(0x1c1c20,.5,0,.4),O_CHR=fabM(0x2c3036),O_FAB=fabM(0x6f7f8c),O_WHT=OM(0xe6e6e0,.5,0,.4),
O_PAP=OM(0xf2f0e6,.9),O_PLA=OM(0xd8d0a8,.6,0,.3),O_BIN=OM(0x2f3338,.6,.4,.3),O_GRN=OM(0x2f6a35,.9),O_POT=OM(0x8a4f33,.8,0,.5),O_BLU=OM(0x6fb6e8,.2),
O_RACK=OM(0x16181c,.4,.7,.3),O_CNT=OM(0xb9b3a4,.5,0,.4),O_LG=new THREE.MeshBasicMaterial({color:0x33ff66}),O_LR=new THREE.MeshBasicMaterial({color:0xff3322}),O_LB=new THREE.MeshBasicMaterial({color:0xffaa22});
