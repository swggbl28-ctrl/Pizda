//@@D  ===== Текстуры этажа 2 и лифта: кирпич, бетон, ржавчина, штукатурка, плитка, решётка, лужи =====
//# FILE: textures/D-floor2-lift.js — Этаж 2 и лифт: PH() (PBR-генератор), brickFn/concFn/rustFn/plasterFn/tileFn, BRK*/CONC*/RUST*/PLASTER/TILEF, GRATE, PUDDLE, BRICKM, BARM.
//# НЕ ЛОМАТЬ: имена функций/констант (их зовёт игра), размеры холстов и раскладку UV (клавиши, шкаф, башня, монитор).
//# ТОП-УРОВЕНЬ: eC, T2, MT, N1, rustFill, brickFn, brickTex, PH, concFn, rustFn, plasterFn, tileFn, BRK, CONC, RUST, PLASTER, TILEF, GRATE, TX_pc, PUDDLE, HMAT, BRICKM, BRKG, CYL2, BARM
const eC=(w,h,f)=>{const[c,g]=cv2(w,h);f(g,w,h);return c};
const T2=(w,h,f,rx=1,ry=1)=>{const t=toTex(eC(w,h,f));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);return t};
const MT=(t,r,b,m=0)=>new THREE.MeshStandardMaterial({map:t,bumpMap:t,bumpScale:b,roughness:r,metalness:m,side:THREE.DoubleSide});
const N1=(u,v,m,o=4)=>fbmp(u*m,v*m,m,o),H1=TX_h,sm=TX_sm,mx=TX_mx,mc=TX_mc;
// ржавчина на произвольном 2D-контексте: низкое разрешение + апскейл
function rustFill(g,w,h,n=70){const s=Math.min(1,512/Math.max(w,h)),cw=Math.max(8,w*s|0),ch=Math.max(8,h*s|0),sh=(n-70)*.002;
 const c=TX_px(cw,ch,(u,v)=>{const a=TX_fp(u*6,v*6,6,6,5),b=TX_fp(u*32,v*32,32,32,4),d=TX_fp(u*12+.5,v*12,12,12,4),r=TX_sm(.4-sh,.62-sh,a*.7+d*.5),q=TX_mc([70,62,58],TX_mc([112,52,22],[184,100,44],b),r),k=(.78+.44*b)*(1-.3*TX_sm(.65,.9,d)*(1-r));return[q[0]*k,q[1]*k,q[2]*k,r*.6+b*.4]},2);
 g.drawImage(c,0,0,w,h);grain(g,w,h,Math.min(w*h/90,60000),.25)}
const brickFn=(cr,R=12,C=4)=>(u,v)=>{const bh=1/R,bw=1/C,row=Math.floor(v/bh),fy=(v-row*bh)/bh,uo=u+(row&1)*bw/2,cc=Math.floor(uo/bw),fx=uo/bw-cc,id=((cc%C)+C)%C,h1=H1(id,row),h2=H1(id+9,row+3),
 ed=Math.min(Math.min(fx,1-fx)*bw*1024,Math.min(fy,1-fy)*bh*1024),nz=N1(u,v,64,3),m=sm(1.5,5,ed+(nz-.5)*7),gr=N1(u,v,8,5),sp=N1(u,v,128,2),soot=sm(.5,.85,TX_fp(u*24,v*3,24,3,3))*(1-.5*v);
 let c=mc([112,52,36],[158,92,62],h1);const dk=.72+.35*h2,sm2=.55+.6*gr,kk=dk*sm2*(.85+.3*sp)*(1-.4*soot);c=[c[0]*kk,c[1]*kk,c[2]*kk];
 const mo=mc([88,84,76],[124,118,106],sp);mo[0]*=.5+gr*.7;mo[1]*=.5+gr*.7;mo[2]*=.5+gr*.7;let q=mc(mo,c,m),h=m*(.7+.3*sp)+.1*nz;
 if(cr){const cf=Math.abs(N1(u,v,8,5)-.5);if(cf<.012){q=mc(q,[12,9,7],.8);h-=.5}}
 return[q[0],q[1],q[2],h,.9-.1*m*sp,0]};
function brickTex(cr){const f=brickFn(cr,16,8),t=toTex(TX_px(512,512,(u,v)=>f(u,v),4));t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(2,1);return t}
// --- фотореалистичные PBR (бесшовные fbm, albedo + normal + roughness/metal) ---
function PH(w,rx,ry,fn,o={}){const n=w*w,cl=new Uint8ClampedArray(n*4),H=new Float32Array(n),rg=new Uint8ClampedArray(n*4),nm=new Uint8ClampedArray(n*4);
 for(let y=0;y<w;y++)for(let x=0;x<w;x++){const i=y*w+x,q=fn(x/w,y/w);cl[i*4]=q[0];cl[i*4+1]=q[1];cl[i*4+2]=q[2];cl[i*4+3]=255;H[i]=q[3];rg[i*4]=255;rg[i*4+1]=Math.min(1,q[4])*255;rg[i*4+2]=(q[5]==null?o.m||0:q[5])*255;rg[i*4+3]=255}
 const k=o.k||4,g=(a,b)=>H[((b+w)%w)*w+((a+w)%w)];
 for(let y=0;y<w;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4,dx=(g(x+1,y)-g(x-1,y))*k,dy=(g(x,y+1)-g(x,y-1))*k,l=Math.hypot(dx,dy,1);nm[i]=(-dx/l*.5+.5)*255;nm[i+1]=(dy/l*.5+.5)*255;nm[i+2]=(1/l*.5+.5)*255;nm[i+3]=255}
 const T=(d,srgb)=>{const[c,g2]=cv2(w,w);g2.putImageData(new ImageData(d,w,w),0,0);const t=new THREE.CanvasTexture(c);t.colorSpace=srgb?THREE.SRGBColorSpace:THREE.NoColorSpace;t.anisotropy=AN;t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(rx,ry);t.generateMipmaps=true;t.minFilter=THREE.LinearMipmapLinearFilter;return t},rm=T(rg,0);
 return new THREE.MeshStandardMaterial({map:T(cl,1),normalMap:T(nm,0),normalScale:new THREE.Vector2(o.ns||1,o.ns||1),roughnessMap:rm,roughness:1,metalnessMap:o.m?rm:null,metalness:o.m?1:0,side:THREE.DoubleSide})}
const concFn=(base,st)=>(u,v)=>{const a=N1(u,v,4,5),b=N1(u,v,32,4),p=N1(u,v,128,2),pore=sm(.62,.7,p)*.7,sn=N1(u+.3,v,2,4),f=Math.min(1,Math.min(Math.min(u,1-u),Math.min(v,1-v))*130),agg=sm(.78,.82,N1(u+.1,v,256,1)),rs=sm(.55,.85,TX_fp(u*20,v*2,20,2,3))*(st?.6:.25);
 let c=base*(.6+.7*a)*(.88+.24*b)*(1-pore*.5)*(.55+.45*f)*(1+.12*agg);const cf=Math.abs(N1(u,v,16,5)-.5)<.006?.35:1;c*=cf;
 return[c*1.02+rs*18,c-rs*4,c*.95+(st?sn*8:0)-rs*12,.5*b+.3*a-pore*.4-(1-f)*.4+agg*.05,.92-.1*pore,0]};
const rustFn=(band)=>(u,v)=>{const a=N1(u,v,8,5),b=N1(u,v,64,4),c2=N1(u+.5,v,16,4),r=sm(.38,.62,a*.7+c2*.5),pt=sm(.46,.56,N1(u+.2,v,4,5)+.25*(c2-.5)),pe=sm(.5,.56,N1(u+.2,v,4,5)+.25*(c2-.5))-pt;
 let c=mc([66,60,56],mc([112,52,22],[178,98,42],b),r);c=mc(c,[78,88,66],(1-pt)*(1-r)*.7);
 if(band){const y=(v*8)%1;const l=y<.04||y>.96?.55:1;c=[c[0]*l,c[1]*l,c[2]*l]}c=[c[0]*(.8+.4*b),c[1]*(.8+.4*b),c[2]*(.8+.4*b)];
 return[c[0],c[1],c[2],r*.6+b*.4-(band&&((v*8)%1<.04)?.5:0)+(1-pt)*.15-pe*.1,mx(.38,.92,Math.max(r,(1-pt)*.8)),(1-r*.85)*pt]};
const plasterFn=(u,v)=>{const a=N1(u,v,4,5),b=N1(u,v,64,4),st=N1(u,v*.25,16,4),d=sm(.5,.7,N1(u,v,6,4)),pl=sm(.7,.76,N1(u+.2,v,10,4)),ck=Math.abs(N1(u,v,12,5)-.5)<.004?1:0;let c=mc([164,156,132],[190,182,158],b);c=mc(c,[88,98,66],d*.5);const k=(.6+.6*a)*(.85+.3*st);c=[c[0]*k,c[1]*k,c[2]*k];c=mc(c,[210,205,190],pl*.6);c=mc(c,[40,36,28],ck*.8);
 return[c[0],c[1],c[2],b*.5+a*.3-pl*.6-ck*.5,.93,0]};
const tileFn=(u,v)=>{const T=4,tx=Math.floor(u*T),ty=Math.floor(v*T),fx=u*T-tx,fy=v*T-ty,ed=Math.min(Math.min(fx,1-fx),Math.min(fy,1-fy))*1024/T,gr=sm(2,6,ed+(N1(u,v,64,2)-.5)*3),h1=H1(tx,ty),dirt=N1(u,v,8,5),sc=sm(.9,.95,N1(u,v*.2,128,2)),p=N1(u,v,64,4),ml=sm(.6,.8,N1(u+.4,v,16,4))*(1-gr);
 let c=mc([84,92,80],[116,120,104],h1);const k=(.55+.7*dirt)*(.9+.2*p)*(1-sc*.25);c=[c[0]*k,c[1]*k,c[2]*k];c=mc([30,28,24],c,gr);c=mc(c,[44,52,34],ml*.6);
 return[c[0],c[1],c[2],gr*(.8+.2*p)-sc*.1,mx(.9,.3+.3*dirt,gr*h1),0]};
const BRK=PH(1024,1,1,brickFn(1),{k:6,ns:1.3}),BRK2=PH(1024,1,1,brickFn(0),{k:6,ns:1.3});
const CONC=PH(1024,4,4,concFn(118),{k:5}),CONC2=PH(512,4,4,concFn(70,1),{k:5});
const RUST=PH(512,1,1,rustFn(0),{k:5,m:1}),RUSTP=PH(512,.5,2,rustFn(1),{k:5,m:1}),RUSTBAR=PH(256,1,2,rustFn(1),{k:4,m:1});
const PLASTER=PH(1024,1,1,plasterFn,{k:3});
const TILEF=PH(1024,8,8,tileFn,{k:6});
const GRATE=MT(T2(128,128,(g,w,h)=>{g.fillStyle='#050505';g.fillRect(0,0,w,h);
 for(let i=0;i<8;i++){let q=g.createLinearGradient(i*16,0,i*16+5,0);q.addColorStop(0,'#3a2414');q.addColorStop(.45,'#9a6a3c');q.addColorStop(1,'#32200f');g.fillStyle=q;g.fillRect(i*16,0,5,h);q=g.createLinearGradient(0,i*16,0,i*16+5);q.addColorStop(0,'#3a2414');q.addColorStop(.45,'#8c5e34');q.addColorStop(1,'#32200f');g.fillStyle=q;g.fillRect(0,i*16,w,5)}
 blot(g,w,h,10,10,40,'180,90,30',.4);blot(g,w,h,8,8,30,'20,10,4',.4);grain(g,w,h,900,.3)},4,4),.7,1,.6);
const TX_pc=pix(128,128,(x,y)=>{PQ[0]=PQ[1]=PQ[2]=fbmp(x/16,y/16,8,4)*255;return PQ})[0];
const PUDDLE=new THREE.MeshStandardMaterial({color:0x1b2a2c,roughness:.05,metalness:.6,transparent:true,opacity:.75,normalMap:rpt(nmap(TX_pc,2),3,3),normalScale:new THREE.Vector2(.15,.15)});
const HMAT=new THREE.MeshStandardMaterial({color:0x6f6a2a,roughness:.5,metalness:.2});
const BRICKM=new THREE.MeshStandardMaterial({map:brickTex(0),roughness:.95,color:0xcc9988});
const BRKG=new THREE.BoxGeometry(.22,.07,.105);
const CYL2=new THREE.CylinderGeometry(1,1,1,14);
const BARM=new THREE.MeshStandardMaterial({map:RUST.map,color:0xcc8866,roughness:.7,metalness:.6});

