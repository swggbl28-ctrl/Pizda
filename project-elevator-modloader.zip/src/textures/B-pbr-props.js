//@@B  ===== PBR-набор: шум/fbm, нормали, ткань, дерево, металл, пластик, розетки, монитор, клавиатура, шкаф, вентиляция, кружка, часы, постер =====
//# FILE: textures/B-pbr-props.js — Шум/fbm, нормали (nmap), ткань, дерево, металл, пластик, розетки (plateTex), башня ПК (towerTex2), монитор (monTex), клавиатура (keysTex2), шкаф (cabTex), вентиляция, коврик, кружка, часы, постер (posterFx).
//# НЕ ЛОМАТЬ: имена функций/констант (их зовёт игра), размеры холстов и раскладку UV (клавиши, шкаф, башня, монитор).
//# ТОП-УРОВЕНЬ: NZT, vn, fbm, vnp, fbmp, PQ, pix, nmap, rpt, PLN, FC, fabM, BMC, WC, wood, plateTex, towerTex2, monTex, keysTex2, cabTex, ventTex, padTex, mugTex, clockFace, posterFx
const NZT=TX_NT;
const vn=(x,y)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=xi&255,b=yi&255,a1=(a+1)&255,b1=(b+1)&255;return NZT[b*256+a]*(1-u)*(1-v)+NZT[b*256+a1]*u*(1-v)+NZT[b1*256+a]*(1-u)*v+NZT[b1*256+a1]*u*v};
const fbm=(x,y,o=4)=>{let a=.5,s=0;for(let i=0;i<o;i++){s+=a*vn(x,y);x=x*2.03+17;y=y*2.03+9;a*=.5}return s};
const vnp=(x,y,m)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=xi&(m-1),b=yi&(m-1),a1=(xi+1)&(m-1),b1=(yi+1)&(m-1);return NZT[b*256+a]*(1-u)*(1-v)+NZT[b*256+a1]*u*(1-v)+NZT[b1*256+a]*(1-u)*v+NZT[b1*256+a1]*u*v};
const fbmp=(x,y,m,o=4)=>{let a=.5,s=0;for(let i=0;i<o;i++){s+=a*vnp(x,y,m);x*=2;y*=2;m*=2;a*=.5}return s};
const PQ=[0,0,0];
function pix(w,h,f){const[c,g]=cv2(w,h),im=g.createImageData(w,h),d=im.data;let i=0;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const q=f(x,y);d[i++]=q[0];d[i++]=q[1];d[i++]=q[2];d[i++]=255}g.putImageData(im,0,0);return[c,g]}
function nmap(c,k=4){const w=c.width,h=c.height,s=c.getContext('2d').getImageData(0,0,w,h).data,H=new Float32Array(w*h);for(let i=0;i<w*h;i++)H[i]=(s[i*4]*.3+s[i*4+1]*.59+s[i*4+2]*.11)/255;
 const[o,og]=cv2(w,h),im=og.createImageData(w,h),d=im.data;
 for(let y=0;y<h;y++){const y0=((y+h-1)%h)*w,y1=y*w,y2=((y+1)%h)*w;for(let x=0;x<w;x++){const xl=(x+w-1)%w,xr=(x+1)%w,dx=(H[y1+xl]-H[y1+xr])*k,dy=(H[y2+x]-H[y0+x])*k,n=1/Math.hypot(dx,dy,1),i=(y1+x)*4;d[i]=(dx*n*.5+.5)*255;d[i+1]=(dy*n*.5+.5)*255;d[i+2]=(n*.5+.5)*255;d[i+3]=255}}
 og.putImageData(im,0,0);const t=new THREE.CanvasTexture(o);t.anisotropy=AN;return t}
const rpt=(t,x,y)=>{t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(x,y);return t};
// пластик: микрорельеф «апельсиновая корка»
const PLN=rpt(nmap(pix(256,256,(x,y)=>{PQ[0]=PQ[1]=PQ[2]=(fbmp(x/32,y/32,8,5)*.7+Math.random()*.3)*255;return PQ})[0],7),10,10);
// тканое полотно: нити с кручёными волокнами
const FC=pix(256,256,(x,y)=>{const cx=x&7,cy=y&7,o=((x>>3)+(y>>3))&1,h=o?Math.sin(cy/8*Math.PI):Math.sin(cx/8*Math.PI),fz=o?TX_pn(x/4,y*1.5,64,384):TX_pn(x*1.5,y/4,384,64),n=Math.random()*.15+fbmp(x/16,y/16,16,3)*.3,v=Math.min(255,(.6+.3*h+fz*.18+n*.35)*255*(o?1:.92));PQ[0]=PQ[1]=PQ[2]=v;return PQ})[0],FT=rpt(toTex(FC),12,12),FN=rpt(nmap(FC,9),12,12);
const fabM=col=>new THREE.MeshStandardMaterial({color:col,map:FT,normalMap:FN,roughness:1});
// шлифованный металл: тонкие продольные риски
const BMC=TX_px(256,256,(u,v)=>{const a=TX_pn(u*2,v*256,2,256),b=TX_pn(u*6,v*128,6,128),s=.5+.6*a+.3*b,t=TX_fp(u*3,v*3,3,3,3);const k=(.86+.2*(s-.7))*(.95+.1*t);return[163*k,165*k,166*k,0]});
// дуб: годовые кольца, волокна, поры, сердцевинные лучи
const WC=pix(1024,512,(x,y)=>{const w1=fbm(x*.004,y*.03,3)*5,r=y*.055+w1+fbm(x*.0015,y*.006,2)*14,b=Math.pow(Math.abs(Math.sin(r*3.14159)),.8),fib=fbm(x*.02,y*.6,3),pore=vn(x*.5,y*1.2)>.86?.4:0,ray=vn(x*.05,y*.9)>.9?.12:0,t=Math.min(1,Math.max(0,.25+.55*b+.5*(fib-.5)-pore+ray));PQ[0]=88+90*t;PQ[1]=54+70*t;PQ[2]=26+44*t;return PQ})[0],WT=rpt(toTex(WC),.5,1),WN=rpt(nmap(WC,5),.5,1);
const wood=new THREE.MeshPhysicalMaterial({map:WT,normalMap:WN,roughness:.5,clearcoat:.3,clearcoatRoughness:.35}),woodDk=new THREE.MeshStandardMaterial({color:0x8a6a4c,map:WT,normalMap:WN,roughness:.6}),
 dark=new THREE.MeshStandardMaterial({color:0x1b1c20,roughness:.42,normalMap:PLN,normalScale:new THREE.Vector2(.6,.6)}),beige=new THREE.MeshStandardMaterial({color:0xd2caa8,roughness:.48,normalMap:PLN,normalScale:new THREE.Vector2(.5,.5)}),
 metal=new THREE.MeshStandardMaterial({color:0xc4c6c7,map:rpt(toTex(BMC),4,4),normalMap:rpt(nmap(BMC,3),4,4),roughness:.32,metalness:.95}),fab=fabM(0x7a7960),
 chromeM=new THREE.MeshStandardMaterial({color:0xdadcdc,metalness:1,roughness:.18});
function plateTex(t){const[c,g]=cv2(256,384);g.scale(2,2);let q=g.createLinearGradient(0,0,128,192);q.addColorStop(0,'#ece5cd');q.addColorStop(1,'#d1c7a7');g.fillStyle=q;g.fillRect(0,0,128,192);grain(g,128,192,900,.1);blot(g,128,192,5,10,40,'120,95,40',.22);
 g.fillStyle='rgba(255,255,255,.65)';g.fillRect(0,0,128,2);g.fillRect(0,0,2,192);g.fillStyle='rgba(0,0,0,.3)';g.fillRect(0,190,128,2);g.fillRect(126,0,2,192);
 q=g.createLinearGradient(0,0,0,192);q.addColorStop(0,'rgba(255,255,255,.35)');q.addColorStop(.5,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(0,0,0,.14)');g.fillStyle=q;g.fillRect(3,3,122,186);
 const scr=(x,y,a)=>{g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.arc(x+1,y+1.8,7,0,6.3);g.fill();const r=g.createRadialGradient(x-2.5,y-2.5,1,x,y,7);r.addColorStop(0,'#f6f6f2');r.addColorStop(.7,'#b4b4aa');r.addColorStop(1,'#8a8a80');g.fillStyle=r;g.beginPath();g.arc(x,y,6,0,6.3);g.fill();const ca=Math.cos(a),sa=Math.sin(a);g.strokeStyle='#33332f';g.lineWidth=1.7;g.beginPath();g.moveTo(x+ca*5,y+sa*5);g.lineTo(x-ca*5,y-sa*5);g.stroke();g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=.8;g.beginPath();g.moveTo(x+ca*5-sa*1.6,y+sa*5+ca*1.6);g.lineTo(x-ca*5-sa*1.6,y-sa*5+ca*1.6);g.stroke()};
 const rec=(x,y,w,h)=>{g.fillStyle='rgba(0,0,0,.4)';g.beginPath();g.roundRect(x-1,y-1,w+2,h+2,8);g.fill();q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#bfb696');q.addColorStop(1,'#dbd2b4');g.fillStyle=q;g.beginPath();g.roundRect(x,y,w,h,7);g.fill();TX_in(g,x,y,w,h,7,.45,5)};
 if(t==='outlet'){[20,108].forEach(y=>{rec(24,y,80,64);[50,78].forEach(x=>{g.fillStyle='#0d0c0a';g.fillRect(x-3,y+12,7,24);g.fillStyle='rgba(176,138,70,.8)';g.fillRect(x-2,y+33,5,2)});const r=g.createRadialGradient(64,y+50,0,64,y+50,5);r.addColorStop(0,'#000');r.addColorStop(1,'#1b1a16');g.fillStyle=r;g.beginPath();g.arc(64,y+50,4.5,0,6.3);g.fill()});scr(64,96,.5)}
 else{rec(30,38,68,116);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(34,96,60,2);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(34,98,60,1);scr(64,16,.9);scr(64,176,2.1)}
 return toTex(c)}
function towerTex2(){const W=480,H=920,[c,g]=TX_abs(W,H,[214,207,174],[191,183,147]);
 const tx=(t,x,y,f='bold 14px Arial')=>TX_txt(g,t,x,y,f,'#4a4632');
 TX_bay(g,40,36,400,92);g.fillStyle='#24231e';g.beginPath();g.roundRect(70,66,340,12,3);g.fill();TX_in(g,70,66,340,12,3,.7,5);g.fillStyle='rgba(255,255,255,.25)';g.fillRect(70,79,340,1.5);TX_out(g,330,92,60,18,4,'#a79f80');g.fillStyle='#4a4632';g.fillRect(340,100,40,2);tx('CD-ROM',64,108);TX_led(g,300,101,4,'#22bb66');
 TX_bay(g,40,150,400,70);g.strokeStyle='rgba(0,0,0,.3)';g.lineWidth=2;g.beginPath();g.moveTo(60,185);g.lineTo(420,185);g.stroke();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1;g.beginPath();g.moveTo(60,187);g.lineTo(420,187);g.stroke();
 TX_bay(g,40,238,400,100);g.fillStyle='#121210';g.beginPath();g.roundRect(150,276,180,12,3);g.fill();TX_in(g,150,276,180,12,3,.7,5);g.fillStyle='#8c8a80';g.fillRect(152,279,176,2);TX_out(g,350,300,50,20,4,'#a79f80');TX_led(g,120,312,4,'#dd3333');tx('3.5"  1.44MB',64,326,'12px Arial');
 let q=g.createLinearGradient(170,360,310,480);q.addColorStop(0,'#8a8466');q.addColorStop(.5,'#c9c3a6');q.addColorStop(1,'#6e684e');g.strokeStyle=q;g.lineWidth=5;g.beginPath();g.arc(240,420,66,0,6.3);g.stroke();g.strokeStyle='rgba(255,255,255,.45)';g.lineWidth=2;g.beginPath();g.arc(240,420,70,.2,2.6);g.stroke();
 g.fillStyle='#8f8869';g.fillRect(60,350,170,34);g.fillStyle='#14130e';g.fillRect(64,354,162,26);TX_in(g,64,354,162,26,2,.7,6);g.fillStyle='#d1342a';g.shadowColor='#ff3322';g.shadowBlur=6;g.font='bold 22px monospace';g.textAlign='left';g.fillText('P5  200',74,374);g.shadowBlur=0;tx('turbo',250,372);
 q=g.createRadialGradient(397,677,1,400,680,13);q.addColorStop(0,'#3a392f');q.addColorStop(1,'#0e0d09');g.fillStyle=q;g.beginPath();g.arc(400,680,12,0,6.3);g.fill();g.strokeStyle='#7d775c';g.lineWidth=3;g.stroke();tx('HDD  PWR',340,716,'12px Arial');
 for(let y=520;y<880;y+=16){g.fillStyle='#17160f';g.fillRect(60,y,360,7);q=g.createLinearGradient(0,y,0,y+7);q.addColorStop(0,'rgba(0,0,0,.6)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(60,y,360,7);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(60,y+7,360,2)}
 tx('PENTIUM',60,500,'bold 26px Arial');return toTex(c)}
function monTex(){const W=1024,H=614,[c,g]=TX_abs(W,H,[225,218,186],[194,186,151]);TX_in(g,30,30,964,554,10,.75,16);
 let q=g.createLinearGradient(34,34,990,580);q.addColorStop(0,'#0a0a0b');q.addColorStop(1,'#030303');g.fillStyle=q;g.fillRect(34,34,956,546);
 q=g.createRadialGradient(300,180,10,512,307,620);q.addColorStop(0,'rgba(255,255,255,.04)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(34,34,956,546);
 TX_txt(g,'V I E W S Y N C',60,604,'bold 20px Arial','#7d765c');TX_txt(g,'LCD  15"  XGA',470,603,'14px Arial','#7d765c');
 for(let i=0;i<3;i++)TX_out(g,820+i*34,592,26,14,3,'#cdc5a6');TX_led(g,960,599,3.5,'#22cc66');return toTex(c)}
function keysTex2(){const W=1024,H=348,[c,g]=cv2(W,H);let q=g.createLinearGradient(0,0,0,H);q.addColorStop(0,'#948c73');q.addColorStop(1,'#827b64');g.fillStyle=q;g.fillRect(0,0,W,H);grain(g,W,H,4000,.1);
 const u=63,key=(x,y,w,h,t)=>TX_kc(g,x,y,w,h,[232,225,198],[196,188,158],'#34322a',t,t.length>2?15:22),
 row=(a,y)=>{let x=(W-15*u)/2;a.forEach(([t,w=1])=>{key(x,y,w*u-6,60,t);x+=w*u})},ch=s=>[...s].map(t=>[t]);
 row([...ch('`1234567890-='),['BKSP',2]],8);row([['TAB',1.5],...ch('QWERTYUIOP[]'),['\\',1.5]],76);row([['CAPS',1.75],...ch("ASDFGHJKL;'"),['ENTER',2.25]],144);row([['SHIFT',2.25],...ch('ZXCVBNM,./'),['SHIFT',2.75]],212);row([['CTRL',1.5],['WIN',1.25],['ALT',1.25],['',6.25],['ALT',1.25],['WIN',1.25],['MENU',1.25],['CTRL',1.5]],280);return toTex(c)}
function cabTex(){const W=256,H=666,c=TX_px(W,H,(u,v)=>{const p=TX_pn(u*128,v*333,128,333),s=TX_pn(u*4,v*300,4,300),n=TX_fp(u*5,v*5,5,5,4);let q=TX_mc([152,163,155],[127,138,131],u);const k=(.92+.1*p)*(.94+.1*s)*(.9+.2*n);return[q[0]*k,q[1]*k,q[2]*k,p*.4]},1),g=c.getContext('2d');
 [[.1,.3615],[.3692,.6308],[.6385,.9]].forEach(([a,b])=>{const y0=a*H,y1=b*H;g.fillStyle='rgba(0,0,0,.6)';g.fillRect(8,y0-3,W-16,y1-y0+6);TX_in(g,8,y0-3,W-16,y1-y0+6,2,.7,8);
  let q=g.createLinearGradient(0,y0,0,y1);q.addColorStop(0,'#a4afa7');q.addColorStop(1,'#86918a');g.fillStyle=q;g.fillRect(12,y0,W-24,y1-y0-2);
  g.fillStyle='rgba(255,255,255,.45)';g.fillRect(12,y0,W-24,2);g.fillRect(12,y0,2,y1-y0-2);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(12,y1-4,W-24,2);g.fillRect(W-14,y0,2,y1-y0-2);
  for(let i=0;i<14;i++){g.strokeStyle=`rgba(255,255,255,${rnd(.04,.12)})`;g.lineWidth=1;const x=rnd(14,W-14),y=rnd(y0,y1);g.beginPath();g.moveTo(x,y);g.lineTo(x+rnd(-30,30),y+rnd(-8,8));g.stroke()}
  TX_out(g,94,y0+12,68,26,2,'#c9ced0');g.fillStyle='#f3efe0';g.fillRect(99,y0+17,58,16);TX_in(g,99,y0+17,58,16,1,.5,3);g.fillStyle='#4a4a4a';g.font='11px Arial';g.textAlign='center';g.fillText('ARCHIVE',128,y0+29);
  TX_in(g,84,y1-36,88,16,6,.7,6);q=g.createLinearGradient(0,y1-32,0,y1-24);q.addColorStop(0,'#eef0f0');q.addColorStop(.5,'#9aa0a2');q.addColorStop(1,'#d4d8d9');g.fillStyle=q;g.beginPath();g.roundRect(90,y1-32,76,8,4);g.fill()});
 blot(g,W,H,10,10,50,'30,25,10',.15);grain(g,W,H,3000,.08);return toTex(c)}
function ventTex(){const[c,g]=TX_abs(256,170,[220,216,196],[206,201,180]);for(let i=0;i<15;i++){const y=8+i*10.5;let q=g.createLinearGradient(0,y,0,y+6);q.addColorStop(0,'#050504');q.addColorStop(1,'#2a281f');g.fillStyle=q;g.beginPath();g.roundRect(10,y,236,6,1.5);g.fill();g.fillStyle='rgba(0,0,0,.25)';g.fillRect(10,y-1.5,236,1.5);g.fillStyle='rgba(255,255,255,.6)';g.fillRect(10,y+6,236,1.5)}
 g.strokeStyle='#8e8a74';g.lineWidth=4;g.strokeRect(2,2,252,166);g.strokeStyle='rgba(255,255,255,.4)';g.lineWidth=1;g.strokeRect(4.5,4.5,247,161);blot(g,256,170,6,10,40,'110,100,70',.18);grain(g,256,170,700,.08);return toTex(c)}
function padTex(){const c=TX_px(256,358,(u,v)=>{const w=TX_pn(u*256,v*358,256,358),r=TX_pn(u*128,v*179,128,179),n=TX_fp(u*4,v*4,4,4,3),q=TX_mc([47,58,78],[34,42,56],(u+v)/2),k=(.82+.3*w)*(.9+.2*r)*(.9+.2*n);return[q[0]*k,q[1]*k,q[2]*k,w*.5+r*.3]},1.5),g=c.getContext('2d');
 g.strokeStyle='rgba(0,0,0,.45)';g.lineWidth=3;g.setLineDash([7,5]);g.strokeRect(10.5,12,236,338);g.strokeStyle='#8a93a6';g.lineWidth=2.2;g.strokeRect(10,10,236,338);g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=.8;g.strokeRect(10,9.2,236,338);g.setLineDash([]);
 g.strokeStyle='rgba(138,147,166,.25)';g.lineWidth=6;g.beginPath();g.arc(128,179,46,0,6.3);g.stroke();grain(g,256,358,3500,.1);return toTex(c)}
function mugTex(){const[c,g]=cv2(512,256);let q=g.createLinearGradient(0,0,0,256);q.addColorStop(0,'#f8f4e9');q.addColorStop(1,'#e1dac6');g.fillStyle=q;g.fillRect(0,0,512,256);blot(g,512,256,8,20,70,'160,140,90',.08);
 g.font='bold 34px Arial';g.textAlign='center';[0,256,512].forEach(x=>{[["WORLD'S",98],['OKAYEST',138],['EMPLOYEE',178]].forEach(([t,y])=>{g.fillStyle='rgba(255,255,255,.7)';g.fillText(t,x,y+1.5);g.fillStyle='rgba(29,53,87,.94)';g.fillText(t,x,y)})});
 g.strokeStyle='rgba(90,55,20,.35)';g.lineWidth=5;g.beginPath();g.arc(400,200,26,.2,5);g.stroke();g.fillStyle='rgba(110,70,30,.25)';g.beginPath();g.ellipse(256,252,200,6,0,0,6.3);g.fill();
 g.fillStyle='rgba(90,80,60,.35)';for(let i=0;i<120;i++)g.fillRect(rnd(0,512),rnd(0,256),1,1);return toTex(c)}
function clockFace(){const[c,g]=cv2(512,512);let q=g.createRadialGradient(256,256,20,256,256,256);q.addColorStop(0,'#f4efdd');q.addColorStop(.85,'#e0d9bd');q.addColorStop(1,'#cfc7a8');g.fillStyle=q;g.beginPath();g.arc(256,256,256,0,6.3);g.fill();grain(g,512,512,3000,.07);blot(g,512,512,6,30,110,'130,100,40',.12);
 g.strokeStyle='rgba(0,0,0,.28)';g.lineWidth=5;g.beginPath();g.arc(256,256,248,0,6.3);g.stroke();g.strokeStyle='rgba(27,27,30,.5)';g.lineWidth=1.5;g.beginPath();g.arc(256,256,240,0,6.3);g.stroke();
 g.strokeStyle='#1b1b1e';g.lineCap='round';for(let i=0;i<60;i++){const a=i*Math.PI/30,l=i%5?10:22,r1=236,r2=r1-l;g.lineWidth=i%5?2:5;g.beginPath();g.moveTo(256+Math.sin(a)*r1,256-Math.cos(a)*r1);g.lineTo(256+Math.sin(a)*r2,256-Math.cos(a)*r2);g.stroke()}
 g.font='bold 54px Arial, Helvetica, sans-serif';g.textAlign='center';g.textBaseline='middle';for(let i=1;i<=12;i++){const a=i*Math.PI/6,x=256+Math.sin(a)*172,y=256-Math.cos(a)*172+3;g.fillStyle='rgba(255,255,255,.5)';g.fillText(i,x+1,y+1.5);g.fillStyle='#1b1b1e';g.fillText(i,x,y)}
 g.font='bold 22px Arial';g.fillText('QUARTZ',256,170);g.font='14px Arial';g.fillText('MADE IN CHINA',256,372);return toTex(c)}
function posterFx(g){let q=g.createLinearGradient(0,0,0,360);q.addColorStop(0,'rgba(160,120,40,.16)');q.addColorStop(1,'rgba(160,120,40,.06)');g.fillStyle=q;g.fillRect(0,0,256,360);
 for(const[x0,y0,x1,y1]of[[0,180,256,182],[128,0,129,360]]){g.strokeStyle='rgba(0,0,0,.16)';g.lineWidth=.8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='rgba(255,255,255,.22)';g.beginPath();g.moveTo(x0+(y0?0:1.5),y0+(y0?1.5:0));g.lineTo(x1+(y0?0:1.5),y1+(y0?1.5:0));g.stroke()}
 q=g.createLinearGradient(0,176,0,188);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.5,'rgba(0,0,0,.07)');q.addColorStop(1,'rgba(255,255,255,.06)');g.fillStyle=q;g.fillRect(0,176,256,12);
 blot(g,256,360,5,15,50,'120,80,20',.25);
 [[4,12,-.7],[252,12,.7]].forEach(([x,y,a])=>{g.save();g.translate(x,y);g.rotate(a);g.shadowColor='rgba(0,0,0,.25)';g.shadowBlur=3;g.shadowOffsetY=1;const t=g.createLinearGradient(-14,0,14,0);t.addColorStop(0,'rgba(232,220,168,.7)');t.addColorStop(.5,'rgba(244,236,196,.55)');t.addColorStop(1,'rgba(226,214,160,.7)');g.fillStyle=t;g.fillRect(-14,-6,28,12);g.restore()});
 const e=g.createLinearGradient(0,0,12,0);e.addColorStop(0,'rgba(0,0,0,.28)');e.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=e;g.fillRect(0,0,12,360);g.save();g.translate(256,0);g.scale(-1,1);g.fillStyle=e;g.fillRect(0,0,12,360);g.restore();
 const b=g.createLinearGradient(0,348,0,360);b.addColorStop(0,'rgba(0,0,0,0)');b.addColorStop(1,'rgba(0,0,0,.18)');g.fillStyle=b;g.fillRect(0,348,256,12)}

