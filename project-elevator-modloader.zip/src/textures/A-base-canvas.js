//@@A  ===== Базовые процедурные текстуры: стены, ковёр, потолок, дерево, металл, клавиши, башня ПК, лампа, отражение =====
//# FILE: textures/A-base-canvas.js — Канвас-текстуры без PBR-карт: wallTex, carTex, ceilTex, woodTex, metalTex, keysTex, towerTex, lampTex, reflTex + ядро (шум _pn/_fp, _px, _up, _in/_out, _abs, _kc). Грузится раньше остальных секций.
//# НЕ ЛОМАТЬ: имена функций/констант (их зовёт игра), размеры холстов и раскладку UV (клавиши, шкаф, башня, монитор).
//# ТОП-УРОВЕНЬ: AN, cv2, toTex, blot, grain, TX_NT, TX_pn, TX_fp, TX_h, TX_px, TX_up, TX_in, TX_out, TX_bay, TX_led, TX_txt, TX_abs, wallTex, carTex, ceilTex, woodTex, metalTex, TX_kc, keysTex, towerTex, lampTex, reflTex
const AN=R.capabilities.getMaxAnisotropy(),rnd=(a,b)=>a+Math.random()*(b-a);
function cv2(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return[c,c.getContext('2d')]}
function toTex(c){const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=AN;return t}
function blot(g,w,h,n,a0,a1,col,a){for(let i=0;i<n;i++){const x=rnd(0,w),y=rnd(0,h),r=rnd(a0,a1),gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(${col},${a*Math.random()})`);gr.addColorStop(.5,`rgba(${col},${a*Math.random()*.4})`);gr.addColorStop(1,`rgba(${col},0)`);g.fillStyle=gr;g.fillRect(x-r,y-r,2*r,2*r)}}
function grain(g,w,h,n,a){for(let i=0;i<n;i++){const v=Math.random()<.5?0:255;g.fillStyle=`rgba(${v},${v},${v*.7|0},${Math.random()*a})`;g.fillRect(Math.random()*w,Math.random()*h,1+Math.random()*1.5,1+Math.random()*1.5)}}
// --- ядро: бесшовный шум, пиксельный генератор с запечённым рельефом, хелперы ---
const TX_NT=new Float32Array(65536);for(let i=0;i<65536;i++)TX_NT[i]=Math.random();
const TX_pn=(x,y,px,py)=>{const xi=Math.floor(x),yi=Math.floor(y),u=x-xi,v=y-yi,s=u*u*(3-2*u),t=v*v*(3-2*v),a=((xi%px)+px)%px,b=((yi%py)+py)%py,a1=(a+1)%px&255,b1=(b+1)%py&255;return TX_NT[(b&255)*256+(a&255)]*(1-s)*(1-t)+TX_NT[(b&255)*256+a1]*s*(1-t)+TX_NT[b1*256+(a&255)]*(1-s)*t+TX_NT[b1*256+a1]*s*t};
const TX_fp=(x,y,px,py,o=4)=>{let a=.5,s=0,n=0;for(let i=0;i<o;i++){s+=a*TX_pn(x,y,px,py);n+=a;x*=2;y*=2;px*=2;py*=2;a*=.5}return s/n};
const TX_h=(a,b)=>{const t=Math.sin(a*127.1+b*311.7)*43758.5;return t-Math.floor(t)},TX_sm=(a,b,x)=>{x=Math.min(1,Math.max(0,(x-a)/(b-a)));return x*x*(3-2*x)},TX_mx=(a,b,t)=>a+(b-a)*t,TX_mc=(A,B,t)=>[TX_mx(A[0],B[0],t),TX_mx(A[1],B[1],t),TX_mx(A[2],B[2],t)],TX_c=(a,k=1,al=1)=>`rgba(${a[0]*k|0},${a[1]*k|0},${a[2]*k|0},${al})`;
function TX_px(w,h,f,k=0){const[c,g]=cv2(w,h),im=g.createImageData(w,h),d=im.data,H=k?new Float32Array(w*h):0;let i=0;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++,i+=4){const q=f(x/w,y/h);d[i]=q[0];d[i+1]=q[1];d[i+2]=q[2];d[i+3]=255;if(k)H[y*w+x]=q[3]}
 if(k)for(let y=0;y<h;y++){const a=((y+h-1)%h)*w,b=y*w,e=((y+1)%h)*w;for(let x=0;x<w;x++){const s=1+k*(H[e+(x+1)%w]-H[a+(x+w-1)%w]),j=(b+x)*4;d[j]*=s;d[j+1]*=s;d[j+2]*=s}}
 g.putImageData(im,0,0);return c}
function TX_up(c,W,H){const[o,g]=cv2(W,H);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(c,0,0,W,H);return[o,g]}
// утопленная панель (внутренняя тень) и выпуклая деталь (внешняя тень + блик кромки)
function TX_in(g,x,y,w,h,r,a=.55,b=8){g.save();g.beginPath();g.roundRect(x,y,w,h,r);g.clip();g.shadowColor=`rgba(0,0,0,${a})`;g.shadowBlur=b;g.shadowOffsetX=1;g.shadowOffsetY=3;g.beginPath();g.rect(x-80,y-80,w+160,h+160);g.roundRect(x,y,w,h,r);g.fillStyle='#000';g.fill('evenodd');g.restore();g.strokeStyle='rgba(255,255,255,.28)';g.lineWidth=1.2;g.beginPath();g.moveTo(x+r,y+h+1);g.lineTo(x+w-r,y+h+1);g.stroke()}
function TX_out(g,x,y,w,h,r,fill){g.save();g.shadowColor='rgba(0,0,0,.5)';g.shadowBlur=7;g.shadowOffsetY=3;g.fillStyle=fill;g.beginPath();g.roundRect(x,y,w,h,r);g.fill();g.restore();g.strokeStyle='rgba(255,255,255,.35)';g.lineWidth=1.2;g.beginPath();g.roundRect(x+.6,y+.6,w-1.2,h-1.2,r);g.stroke()}
function TX_bay(g,x,y,w,h){const q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,'#aaa384');q.addColorStop(1,'#bdb596');g.fillStyle=q;g.fillRect(x-3,y-3,w+6,h+6);TX_in(g,x,y,w,h,3,.6,10);g.fillStyle=q;g.fillRect(x,y,w,h);TX_in(g,x,y,w,h,3,.5,9)}
function TX_led(g,x,y,r,col){const q=g.createRadialGradient(x,y,0,x,y,r*3);q.addColorStop(0,col+'aa');q.addColorStop(1,col+'00');g.fillStyle=q;g.fillRect(x-r*3,y-r*3,r*6,r*6);const s=g.createRadialGradient(x-r*.3,y-r*.3,0,x,y,r);s.addColorStop(0,'#fff');s.addColorStop(.4,col);s.addColorStop(1,'#000');g.fillStyle=s;g.beginPath();g.arc(x,y,r,0,6.3);g.fill()}
function TX_txt(g,t,x,y,font,col,al='left'){g.font=font;g.textAlign=al;g.fillStyle='rgba(255,255,255,.4)';g.fillText(t,x,y+1);g.fillStyle=col;g.fillText(t,x,y)}
// пластик ABS (пожелтевший, с лёгкой неоднородностью): возвращает [canvas,ctx]
function TX_abs(W,H,A,B){const c=TX_px(W,H,(u,v)=>{const n=TX_fp(u*5,v*8,5,8,4),m=TX_pn(u*240,v*460,240,460),e=Math.min(u,1-u,v,1-v)*Math.min(W,H),k=(.94+.1*n)*(.97+.06*m)*(1-.16*TX_sm(.7,1,v))*(.82+.18*TX_sm(0,22,e)),q=TX_mc(A,B,u);return[q[0]*k*(1+.02*n),q[1]*k,q[2]*k*(1-.04*n),m*.4]},1.2);return[c,c.getContext('2d')]}
function wallTex(){const W=2048,H=768,f=(u,v)=>{const cx=u*42,ix=Math.floor(cx),fx=cx-ix,y=v*H,cy=(y-20)/56,iy=Math.floor(cy),fy=cy-iy,s=.5+.5*Math.cos(cx*6.2832),
 dm=(y>20&&y<H-60&&TX_h(ix,iy)>.08)?1-TX_sm(.55,1,Math.hypot(Math.abs(fx-.5)/.19,Math.min(fy,1-fy)/.21)):0,
 n=TX_fp(u*8,v*3,8,3,4),bl=TX_sm(.55,.8,TX_fp(u*5,v*3,5,3,3)),stk=TX_sm(.52,.8,TX_fp(u*90,v*2.5,90,3,3))*Math.pow(1-v,1.4),pn=TX_fp(u*4,v*2.5,4,3,3),top=v<.6?1:0,
 pl=TX_sm(.69,.72,pn)*top*(1-TX_sm(.5,.6,v)),ed=TX_sm(.67,.69,pn)*(1-TX_sm(.71,.73,pn))*top;
 let c=TX_mc([176,152,69],[205,184,96],v);const k=(1+.14*(s-.5)+(TX_h(ix,3)-.5)*.07)*(1-.1*dm)*(.8+.4*n)*(1-.4*bl)*(1-.28*TX_sm(.55,1,v))*(.8+.2*TX_sm(0,.12,v));
 c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[84,56,12],stk*.5);c=TX_mc(c,[224,212,164],pl*.9);const e=1-.45*ed;return[c[0]*e,c[1]*e,c[2]*e,dm*.5+s*.15-pl*.6-ed*.2]};
 const[o,g]=TX_up(TX_px(1024,384,f,3),W,H);
 let q=g.createLinearGradient(0,H-62,0,H-52);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,.45)');g.fillStyle=q;g.fillRect(0,H-62,W,10);
 q=g.createLinearGradient(0,H-55,0,H);q.addColorStop(0,'#4d3c23');q.addColorStop(.5,'#3d2e18');q.addColorStop(1,'#271c0f');g.fillStyle=q;g.fillRect(0,H-55,W,55);g.fillStyle='rgba(255,230,170,.2)';g.fillRect(0,H-55,W,3);g.fillStyle='rgba(0,0,0,.35)';g.fillRect(0,H-22,W,2);
 for(let i=0;i<300;i++){g.strokeStyle=`rgba(${Math.random()<.5?'20,12,4':'130,95,55'},${rnd(.05,.2)})`;g.lineWidth=rnd(.5,1.5);const y=rnd(H-52,H-2),x=rnd(0,W);g.beginPath();g.moveTo(x,y);g.lineTo(x+rnd(60,400),y+rnd(-1,1));g.stroke()}
 blot(g,W,H,20,40,150,'20,12,2',.25);grain(g,W,H,30000,.13);return toTex(o)}
function carTex(){const S=2048,c=TX_px(1024,1024,(u,v)=>{const a=TX_fp(u*6,v*6,6,6,5),b=TX_fp(u*24,v*24,24,24,4),t=TX_pn(u*256,v*256,256,256),fb=TX_pn(u*512,v*128,512,128),
 st=TX_sm(.6,.78,TX_fp(u*4,v*4,4,4,4)),wr=TX_sm(.55,.8,TX_fp(u*3,v*2,3,2,3)),sp=TX_sm(.78,.9,TX_fp(u*12,v*12,12,12,3));
 let c=[107,102,54];const k=(.78+.5*a)*(.9+.2*b)*(.78+.44*t)*(.9+.2*fb);c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[40,32,12],st*.55);c=TX_mc(c,[150,140,76],wr*.25);c=TX_mc(c,[26,18,6],sp*.6);return[c[0],c[1],c[2],t*.6+b*.3]},2.5),[o,g]=TX_up(c,S,S);
 for(const col of['rgba(40,34,12,.35)','rgba(150,140,80,.28)','rgba(90,82,38,.35)','rgba(20,16,4,.3)']){g.strokeStyle=col;g.lineWidth=1;g.beginPath();for(let i=0;i<14000;i++){const x=rnd(0,S),y=rnd(0,S),a=rnd(0,6.3),l=rnd(3,8);g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke()}
 grain(g,S,S,60000,.22);return toTex(o)}
function ceilTex(){const S=2048,T=128,c=TX_px(512,512,(u,v)=>{const cx=u*16,cy=v*16,h=TX_h(Math.floor(cx),Math.floor(cy)),dk=h<.12?.8:1,n=TX_fp(u*8,v*8,8,8,5),m=TX_fp(u*64,v*64,64,64,3),st=TX_sm(.58,.78,TX_fp(u*5,v*5,5,5,4)),
 e=Math.min(cx%1,1-cx%1,cy%1,1-cy%1)*T,ao=.62+.38*TX_sm(0,14,e);let c=TX_mc([216,209,164],[150,112,52],st*.55);const k=(.9+.2*n)*(.95+.1*m)*dk*(.96+.08*h)*ao;return[c[0]*k,c[1]*k,c[2]*k,m*.4+.2*n]},2),[o,g]=TX_up(c,S,S);
 g.fillStyle='rgba(60,54,28,.45)';g.beginPath();for(let i=0;i<20000;i++){const x=rnd(0,S),y=rnd(0,S),r=rnd(.7,2.2);g.moveTo(x+r,y);g.arc(x,y,r,0,6.3)}g.fill();
 g.strokeStyle='rgba(80,72,40,.3)';g.lineWidth=1;g.beginPath();for(let i=0;i<4000;i++){const x=rnd(0,S),y=rnd(0,S),a=rnd(0,6.3),l=rnd(4,12);g.moveTo(x,y);g.lineTo(x+Math.cos(a)*l,y+Math.sin(a)*l)}g.stroke();
 for(let i=0;i<=16;i++){for(const[x0,y0,x1,y1,dx,dy]of[[i*T,0,i*T,S,1,0],[0,i*T,S,i*T,0,1]]){let q=g.createLinearGradient(x0-12*dx,y0-12*dy,x0+12*dx+1e-3*dy,y0+12*dy+1e-3*dx);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(.5,'rgba(0,0,0,.32)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;g.fillRect(x0-12*dx,y0-12*dy,dx?24:S,dy?24:S);
  g.strokeStyle='#5d5840';g.lineWidth=8;g.beginPath();g.moveTo(x0,y0);g.lineTo(x1,y1);g.stroke();g.strokeStyle='rgba(255,252,215,.5)';g.lineWidth=2;g.beginPath();g.moveTo(x0+6*dx,y0+6*dy);g.lineTo(x1+6*dx,y1+6*dy);g.stroke();g.strokeStyle='rgba(0,0,0,.35)';g.beginPath();g.moveTo(x0-4*dx,y0-4*dy);g.lineTo(x1-4*dx,y1-4*dy);g.stroke()}}
 blot(g,S,S,30,60,200,'90,60,10',.18);grain(g,S,S,40000,.12);return toTex(o)}
function woodTex(){return toTex(TX_px(1024,512,(u,v)=>{const w=TX_fp(u*8,v*16,8,16,3)*5,r=v*28+w+TX_fp(u*3,v*6,3,6,2)*10,b=Math.pow(Math.abs(Math.sin(r*3.14159)),.8),fib=TX_pn(u*16,v*512,16,512),pore=TX_pn(u*256,v*256,256,256)>.84?.3:0,kn=TX_sm(.7,.85,TX_fp(u*2,v*3,2,3,3));
 const t=Math.min(1,Math.max(0,.25+.55*b+.5*(fib-.5)-pore-kn*.3)),c=TX_mc([58,37,20],[122,84,48],t),s=.92+.12*Math.sin(v*3.14159);return[c[0]*s,c[1]*s,c[2]*s,fib*.5+b*.3]},1.5))}
function metalTex(){return toTex(TX_px(512,512,(u,v)=>{const a=TX_pn(u*3,v*400,3,400),b=TX_pn(u*9,v*160,9,160),ox=TX_sm(.6,.8,TX_fp(u*3,v*3,3,3,4));let c=[123,127,119];const k=(.82+.36*a)*(.9+.2*b);c=TX_mc([c[0]*k,c[1]*k,c[2]*k],[70,64,40],ox*.35);return[c[0],c[1],c[2],0]}))}
function TX_kc(g,x,y,w,h,T,B,ink,t,z){g.save();g.shadowColor='rgba(0,0,0,.6)';g.shadowBlur=9;g.shadowOffsetY=4;g.fillStyle=TX_c(B);g.beginPath();g.roundRect(x,y,w,h,9);g.fill();g.restore();
 let q=g.createLinearGradient(0,y,0,y+h);q.addColorStop(0,TX_c(B,1.25));q.addColorStop(1,TX_c(B,.78));g.fillStyle=q;g.beginPath();g.roundRect(x,y,w,h,9);g.fill();
 const ix=x+w*.08,iy=y+h*.05,iw=w*.84,ih=h*.76,rr=()=>{g.beginPath();g.roundRect(ix,iy,iw,ih,7)};
 q=g.createLinearGradient(0,iy,0,iy+ih);q.addColorStop(0,TX_c(T,.9));q.addColorStop(.3,TX_c(T,1.04));q.addColorStop(1,TX_c(T,1.14));g.fillStyle=q;rr();g.fill();
 q=g.createRadialGradient(x+w/2,iy+ih*.4,2,x+w/2,iy+ih*.5,w*.62);q.addColorStop(0,'rgba(0,0,0,.12)');q.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=q;rr();g.fill();g.strokeStyle='rgba(255,255,255,.2)';g.lineWidth=1.4;rr();g.stroke();
 if(t){const ty=iy+ih/2+z*.35;g.font=`bold ${z}px Arial, Helvetica, sans-serif`;g.textAlign='center';g.fillStyle='rgba(0,0,0,.35)';g.fillText(t,x+w/2,ty+1.5);g.fillStyle=ink;g.fillText(t,x+w/2,ty)}}
function keysTex(){const[c,g]=cv2(1024,384);let q=g.createLinearGradient(0,0,0,384);q.addColorStop(0,'#1c1c21');q.addColorStop(1,'#111115');g.fillStyle=q;g.fillRect(0,0,1024,384);grain(g,1024,384,5000,.1);const L='QWERTYUIOPASDFGHJKLZXCVBNM';let n=0;
 const key=(x,y,w,h,t)=>TX_kc(g,x,y,w,h,[76,76,84],[40,40,46],'#dcdcdc',t,22);
 for(let r=0;r<4;r++)for(let i=0;i<14;i++)key(14+r*14+i*70,14+r*72,64,64,r>0&&i<10?L[n++%26]:'');
 key(14,302,120,64);key(150,302,120,64);key(286,302,440,64);key(742,302,120,64);key(878,302,120,64);return toTex(c)}
function towerTex(){const W=480,H=920,[c,g]=TX_abs(W,H,[200,192,160],[172,164,130]);
 [[50,40,380,100],[50,160,380,100]].forEach(([x,y,w,h])=>{TX_bay(g,x,y,w,h);g.fillStyle='#16150f';g.beginPath();g.roundRect(x+30,y+h/2-6,w-60,12,3);g.fill();TX_in(g,x+30,y+h/2-6,w-60,12,3,.7,5)});
 g.fillStyle='#16150f';g.fillRect(50,290,200,30);TX_in(g,50,290,200,30,2,.6,5);g.fillStyle='#8f8869';g.fillRect(60,300,180,5);
 g.strokeStyle='#706a50';g.lineWidth=3;g.beginPath();g.arc(240,420,52,0,6.3);g.stroke();let q=g.createRadialGradient(236,414,4,240,420,40);q.addColorStop(0,'#e4dfc6');q.addColorStop(1,'#bdb89c');g.fillStyle=q;g.beginPath();g.arc(240,420,40,0,6.3);g.fill();
 for(let y=520;y<880;y+=16){g.fillStyle='#17160f';g.fillRect(60,y,360,6);g.fillStyle='rgba(255,255,255,.4)';g.fillRect(60,y+6,360,1.5)}
 TX_txt(g,'PENTIUM',60,360,'bold 24px Arial','#3a3624');TX_txt(g,'turbo  HDD  PWR',280,325,'16px Arial','#3a3624');return toTex(c)}
function lampTex(){const[c,g]=cv2(256,128);let q=g.createLinearGradient(0,0,0,128);q.addColorStop(0,'#fff1bd');q.addColorStop(.5,'#fffbe8');q.addColorStop(1,'#fff0bb');g.fillStyle=q;g.fillRect(0,0,256,128);
 [33,101].forEach(y=>{const t=g.createLinearGradient(0,y-12,0,y+12);t.addColorStop(0,'rgba(255,255,255,0)');t.addColorStop(.5,'rgba(255,255,255,1)');t.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=t;g.fillRect(6,y-12,244,24)});
 q=g.createLinearGradient(0,0,256,0);q.addColorStop(0,'rgba(120,100,40,.4)');q.addColorStop(.12,'rgba(120,100,40,0)');q.addColorStop(.88,'rgba(120,100,40,0)');q.addColorStop(1,'rgba(120,100,40,.4)');g.fillStyle=q;g.fillRect(0,0,256,128);
 for(let x=0;x<=256;x+=16){g.fillStyle='rgba(140,125,60,.3)';g.fillRect(x,0,1.6,128);g.fillStyle='rgba(255,255,255,.55)';g.fillRect(x+1.6,0,1,128)}
 for(let y=0;y<=128;y+=16){g.fillStyle='rgba(140,125,60,.3)';g.fillRect(0,y,256,1.6);g.fillStyle='rgba(255,255,255,.55)';g.fillRect(0,y+1.6,256,1)}
 for(const y of[0,124]){q=g.createLinearGradient(0,y,0,y+4);q.addColorStop(0,'#7a7a7a');q.addColorStop(1,'#3d3d3d');g.fillStyle=q;g.fillRect(0,y,256,4)}grain(g,256,128,1200,.05);return toTex(c)}
function reflTex(){const[c,g]=cv2(256,144);let q=g.createLinearGradient(0,0,256,144);q.addColorStop(0,'rgba(255,255,255,.14)');q.addColorStop(.35,'rgba(255,255,255,.02)');q.addColorStop(.5,'rgba(255,255,255,.08)');q.addColorStop(.6,'rgba(255,255,255,0)');q.addColorStop(1,'rgba(255,240,200,.06)');g.fillStyle=q;g.fillRect(0,0,256,144);
 q=g.createRadialGradient(40,30,2,40,30,110);q.addColorStop(0,'rgba(255,255,255,.1)');q.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=q;g.fillRect(0,0,256,144);
 q=g.createRadialGradient(128,72,60,128,72,170);q.addColorStop(0,'rgba(0,0,0,0)');q.addColorStop(1,'rgba(0,0,0,.08)');g.fillStyle=q;g.fillRect(0,0,256,144);return toTex(c)}

