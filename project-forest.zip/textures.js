// ============================================================
// ТЕКСТУРЫ леса — полностью процедурные (canvas), без внешних файлов.
// Секция A подставляется в игру на маркер //@TEXTURES:A@.
// ============================================================
//@@A  ===== Процедурные текстуры леса: земля (хвоя, мох, шишки, камни, ветки), кора сосны, хвойные «кисти», лапы ели, трава, камень =====
const TX_AN=Math.min(8,R.capabilities.getMaxAnisotropy());
const TX_lerp=(a,b,t)=>a+(b-a)*t, TX_cl=(x,a=0,b=1)=>Math.min(b,Math.max(a,x));
const TX_ss=(a,b,x)=>{const t=TX_cl((x-a)/(b-a));return t*t*(3-2*t)};
function TX_rng(s){return()=>{s|=0;s=s+0x6D2B79F5|0;let t=Math.imul(s^s>>>15,1|s);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
function TX_h(x,y,s){let n=Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+Math.imul(s|0,1442695041)|0;n=Math.imul(n^n>>>13,1274126177);return((n^n>>>16)>>>0)/4294967296}
// периодический value-noise (бесшовный): px,py — период решётки
function TX_vn(x,y,px,py,s){const xi=Math.floor(x),yi=Math.floor(y),fx=x-xi,fy=y-yi,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);
 const x0=((xi%px)+px)%px,x1=(x0+1)%px,y0=((yi%py)+py)%py,y1=(y0+1)%py;
 const a=TX_h(x0,y0,s),b=TX_h(x1,y0,s),c=TX_h(x0,y1,s),d=TX_h(x1,y1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v}
function TX_fbm(x,y,px,py,o,s){let a=.5,t=0,f=1;for(let i=0;i<o;i++){t+=a*TX_vn(x*f,y*f,px*f,py*f,s+i*17);a*=.5;f*=2}return t/(1-Math.pow(.5,o))}
function TX_cvs(w,h){const c=document.createElement('canvas');c.width=w;c.height=h;return[c,c.getContext('2d')]}
function TX_tex(c,srgb=true,wrap=true){const t=new THREE.CanvasTexture(c);if(srgb)t.colorSpace=THREE.SRGBColorSpace;if(wrap)t.wrapS=t.wrapT=THREE.RepeatWrapping;t.anisotropy=TX_AN;t.generateMipmaps=true;t.minFilter=THREE.LinearMipmapLinearFilter;return t}
// карта нормалей из карты высот (Float32Array 0..1), бесшовно
function TX_normalMap(H,w,h,str){const[c,g]=TX_cvs(w,h),im=g.createImageData(w,h),o=im.data;
 for(let y=0;y<h;y++)for(let x=0;x<w;x++){const l=H[y*w+(x-1+w)%w],r=H[y*w+(x+1)%w],u=H[((y-1+h)%h)*w+x],d=H[((y+1)%h)*w+x];
  let nx=(l-r)*str,ny=(d-u)*str,nz=1;const k=1/Math.hypot(nx,ny,nz);const i=(y*w+x)*4;
  o[i]=(nx*k*.5+.5)*255;o[i+1]=(ny*k*.5+.5)*255;o[i+2]=(nz*k*.5+.5)*255;o[i+3]=255}
 g.putImageData(im,0,0);return TX_tex(c,false)}
function TX_readH(c){const w=c.width,h=c.height,d=c.getContext('2d').getImageData(0,0,w,h).data,H=new Float32Array(w*h);for(let i=0;i<w*h;i++)H[i]=d[i*4]/255;return H}

// ---------------- ЗЕМЛЯ: хвойная подстилка, мох, шишки, камушки, веточки ----------------
function TX_ground(N){
 const rnd=TX_rng(11),[c,g]=TX_cvs(N,N),[ch,gh]=TX_cvs(N,N),sc=N/1024,S2=sc*sc;
 const im=g.createImageData(N,N),d=im.data,hi=gh.createImageData(N,N),hd=hi.data;
 for(let y=0;y<N;y++)for(let x=0;x<N;x++){
  const u=x/N,v=y/N,n1=TX_fbm(u*8,v*8,8,8,5,1),n2=TX_fbm(u*32,v*32,32,32,3,2),mo=TX_fbm(u*5,v*5,5,5,4,3),dk=TX_fbm(u*12,v*12,12,12,3,4);
  const m=TX_cl((mo-.52)/.14)*.9;
  let r=TX_lerp(52,112,n1),gg=TX_lerp(38,80,n1),b=TX_lerp(26,52,n1);
  const dm=TX_lerp(.7,1.15,dk);r*=dm;gg*=dm;b*=dm;
  r=TX_lerp(r,TX_lerp(56,112,n2),m);gg=TX_lerp(gg,TX_lerp(78,134,n2),m);b=TX_lerp(b,TX_lerp(26,54,n2),m);
  const i=(y*N+x)*4;d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;
  const hv=(.3+.3*n1+.2*n2+m*.15)*255;hd[i]=hd[i+1]=hd[i+2]=hv;hd[i+3]=255}
 g.putImageData(im,0,0);gh.putImageData(hi,0,0);
 const wrap=(x,y,m,fn)=>{const xs=[0],ys=[0];if(x<m)xs.push(N);if(x>N-m)xs.push(-N);if(y<m)ys.push(N);if(y>N-m)ys.push(-N);for(const a of xs)for(const b of ys)fn(x+a,y+b)};
 const line=(x,y,ex,ey,w,col,hc)=>{wrap(x,y,Math.hypot(ex-x,ey-y)+8,(X,Y)=>{const dx=X-x,dy=Y-y;
  g.strokeStyle=col;g.lineWidth=w;g.beginPath();g.moveTo(X,Y);g.lineTo(ex+dx,ey+dy);g.stroke();
  gh.strokeStyle=hc;gh.lineWidth=w;gh.beginPath();gh.moveTo(X,Y);gh.lineTo(ex+dx,ey+dy);gh.stroke()})};
 g.lineCap=gh.lineCap='round';
 const dry=['#6e4a2a','#7f5a33','#5a3b22','#8d6a3d','#4b301d','#a07c48','#6a4d2b','#3f2a1a','#51381f'];
 // нижний слой: тёмные длинные иглы
 for(let i=0;i<5000*S2;i++){const x=rnd()*N,y=rnd()*N,a=rnd()*6.283,l=(22+rnd()*20)*1,k=rnd()*.14-.07;
  line(x,y,x+Math.cos(a)*l,y+Math.sin(a)*l,1.5*sc+.4,'#2e1f13','rgba(120,120,120,.5)');}
 // основной слой: пары сосновых игл
 for(let i=0;i<15000*S2;i++){const x=rnd()*N,y=rnd()*N,a=rnd()*6.283,l=(16+rnd()*22),w=(1.1+rnd()*.7);
  const col=rnd()<.06?'#4a5a2a':dry[rnd()*dry.length|0];const hc=`rgba(${150+rnd()*90|0},${150+rnd()*90|0},${150+rnd()*90|0},.6)`;
  for(let k=-1;k<=1;k+=2){const aa=a+k*.05;line(x,y,x+Math.cos(aa)*l,y+Math.sin(aa)*l,w,col,hc)}}
 // зелёные травинки и побеги
 for(let i=0;i<500*S2;i++){const x=rnd()*N,y=rnd()*N,a=rnd()*6.283,l=10+rnd()*18;line(x,y,x+Math.cos(a)*l,y+Math.sin(a)*l,1.2,rnd()<.5?'#4f6a2a':'#6a7d35','rgba(200,200,200,.6)')}
 // мох: кучки точек
 for(let p=0;p<(60*S2|0);p++){const cx=rnd()*N,cy=rnd()*N,rr=14+rnd()*34;for(let k=0;k<260;k++){const a=rnd()*6.283,r=Math.sqrt(rnd())*rr,x=cx+Math.cos(a)*r,y=cy+Math.sin(a)*r,s=1.2+rnd()*2.4;
  wrap(x,y,6,(X,Y)=>{g.fillStyle=`rgb(${45+rnd()*35|0},${70+rnd()*50|0},${22+rnd()*20|0})`;g.beginPath();g.arc(X,Y,s,0,6.283);g.fill();gh.fillStyle='rgba(200,200,200,.5)';gh.beginPath();gh.arc(X,Y,s,0,6.283);gh.fill()})}}
 // веточки
 for(let i=0;i<(150*S2|0);i++){const x=rnd()*N,y=rnd()*N,a=rnd()*6.283,l=45+rnd()*110,w=1.6+rnd()*2.2,ex=x+Math.cos(a)*l,ey=y+Math.sin(a)*l;
  line(x,y,ex,ey,w+1.2,'#1d130b','rgba(150,150,150,.8)');line(x,y,ex,ey,w,'#4c3826','rgba(235,235,235,.95)');line(x,y,ex,ey,w*.35,'#6b5238','rgba(255,255,255,1)');
  for(let k=0;k<3;k++){const t=.2+rnd()*.7,bx=x+(ex-x)*t,by=y+(ey-y)*t,ba=a+(rnd()<.5?-1:1)*(.6+rnd()*.5),bl=10+rnd()*22;line(bx,by,bx+Math.cos(ba)*bl,by+Math.sin(ba)*bl,w*.55,'#4c3826','rgba(220,220,220,.9)')}}
 // шишки
 for(let i=0;i<(26*S2|0);i++){const x=rnd()*N,y=rnd()*N,a=rnd()*3.14,L=11+rnd()*6,W=L*.5;
  wrap(x,y,24,(X,Y)=>{g.save();g.translate(X,Y);g.rotate(a);gh.save();gh.translate(X,Y);gh.rotate(a);
   g.fillStyle='#1e130b';g.beginPath();g.ellipse(1.5,1.5,L+1,W+1,0,0,6.283);g.fill();
   g.fillStyle='#5b3e25';g.beginPath();g.ellipse(0,0,L,W,0,0,6.283);g.fill();gh.fillStyle='rgba(240,240,240,.9)';gh.beginPath();gh.ellipse(0,0,L,W,0,0,6.283);gh.fill();
   for(let k=-L+2;k<L;k+=3.2)for(let j=-W+2;j<W-1;j+=3.2){g.strokeStyle='rgba(20,12,6,.7)';g.lineWidth=.9;g.beginPath();g.arc(k,j,2,.3,2.8);g.stroke();g.fillStyle='rgba(150,110,70,.35)';g.fillRect(k-1,j-2,2,1)}
   g.restore();gh.restore()})}
 // камушки
 for(let i=0;i<(110*S2|0);i++){const x=rnd()*N,y=rnd()*N,r=3+rnd()*rnd()*12,a=rnd()*3.14,q=.65+rnd()*.3;
  wrap(x,y,r*2+4,(X,Y)=>{const lt=60+rnd()*50|0;
   g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(X+r*.25,Y+r*.3,r*1.1,r*q*1.1,a,0,6.283);g.fill();
   const gr=g.createRadialGradient(X-r*.3,Y-r*.3,0,X,Y,r*1.1);gr.addColorStop(0,`rgb(${lt+40},${lt+38},${lt+30})`);gr.addColorStop(1,`rgb(${lt-20},${lt-20},${lt-24})`);
   g.fillStyle=gr;g.beginPath();g.ellipse(X,Y,r,r*q,a,0,6.283);g.fill();
   const gg2=gh.createRadialGradient(X,Y,0,X,Y,r);gg2.addColorStop(0,'rgba(255,255,255,1)');gg2.addColorStop(.8,'rgba(200,200,200,.9)');gg2.addColorStop(1,'rgba(120,120,120,0)');gh.fillStyle=gg2;gh.beginPath();gh.ellipse(X,Y,r,r*q,a,0,6.283);gh.fill()})}
 // мелкий шум зерна на альбедо
 const id=g.getImageData(0,0,N,N),dd=id.data;for(let i=0;i<dd.length;i+=4){const k=.88+rnd()*.24;dd[i]*=k;dd[i+1]*=k;dd[i+2]*=k}g.putImageData(id,0,0);
 const map=TX_tex(c);const H=TX_readH(ch),normalMap=TX_normalMap(H,N,N,4.2);return{map,normalMap}}

// ---------------- КОРА СОСНЫ: пластины с глубокими трещинами, лишайник ----------------
function TX_bark(){
 const W=512,Hh=1024,[c,g]=TX_cvs(W,Hh),im=g.createImageData(W,Hh),d=im.data,H=new Float32Array(W*Hh);
 for(let y=0;y<Hh;y++)for(let x=0;x<W;x++){
  const u=x/W,v=y/Hh,wx=TX_fbm(u*4,v*4,4,4,3,21),wy=TX_fbm(u*3,v*6,3,6,3,22);
  const n=TX_fbm(u*9+wx*1.6,v*3+wy*.9,9,3,4,23),f=Math.abs(n-.5)*2,fis=1-TX_ss(.0,.16,f);
  const cr=TX_fbm(u*7,v*16+wx*1.2,7,16,3,24),cf=1-TX_ss(.0,.07,Math.abs(cr-.5)*2);
  const fine=TX_fbm(u*40,v*60,40,60,3,25),fine2=TX_fbm(u*90,v*130,90,130,2,26);
  const fl=TX_fbm(u*12,v*12,12,12,4,27),lich=TX_cl((fl-.6)/.12);
  let dep=Math.max(fis,cf*.8);
  let hv=(1-dep*.95)*(.72+.28*fine)+.04*fine2;
  const base=TX_lerp(.55,1,fine);
  let r=TX_lerp(82,140,fine)*base+10*fine2,gg=TX_lerp(50,84,fine)*base,b=TX_lerp(32,56,fine)*base;
  const flk=TX_fbm(u*20,v*30,20,30,3,28);if(flk>.62){r*=1.18;gg*=1.1;b*=.95}
  r=TX_lerp(r,120,lich*.5);gg=TX_lerp(gg,126,lich*.5);b=TX_lerp(b,98,lich*.5);
  const ao=1-dep*.92;r*=ao;gg*=ao;b*=ao;
  const i=(y*W+x)*4;d[i]=r;d[i+1]=gg;d[i+2]=b;d[i+3]=255;H[y*W+x]=hv}
 g.putImageData(im,0,0);return{map:TX_tex(c),normalMap:TX_normalMap(H,W,Hh,5.5)}}

// ---------------- ХВОЙНАЯ КИСТЬ СОСНЫ (RGBA, alphaTest) ----------------
function TX_tuft(){
 const S=512,[c,g]=TX_cvs(S,S),rnd=TX_rng(31),cx=S/2,cy=S/2;g.lineCap='round';
 const cols=['#21402a','#2a5030','#3a6a3c','#4a7a44','#2f5a4a','#5a8a50','#7aa05a','#264428','#486a35','#8aa24a','#355f3a','#63904e'];
 const twigs=[];for(let i=0;i<46;i++){const a=rnd()*6.283,l=70+rnd()*150;twigs.push([a,l])}
 // тёмное «ядро» для плотности
 const rg=g.createRadialGradient(cx,cy,0,cx,cy,120);rg.addColorStop(0,'rgba(42,78,44,.6)');rg.addColorStop(1,'rgba(30,58,34,0)');g.fillStyle=rg;g.fillRect(0,0,S,S);
 for(const[a,l]of twigs){const ex=cx+Math.cos(a)*l,ey=cy+Math.sin(a)*l;
  g.strokeStyle='#4a3322';g.lineWidth=3;g.beginPath();g.moveTo(cx+Math.cos(a)*l*.3,cy+Math.sin(a)*l*.3);g.lineTo(ex,ey);g.stroke();
  const nf=22+(rnd()*14|0);for(let k=0;k<nf;k++){const t=.3+.7*k/nf,bx=cx+Math.cos(a)*l*t,by=cy+Math.sin(a)*l*t;
   const nn=3+(rnd()*3|0);for(let j=0;j<nn;j++){const aa=a+(rnd()-.5)*1.7,len=(22+rnd()*38)*(1-.4*t+.4*rnd()),col=cols[rnd()*cols.length|0];
    g.strokeStyle=col;g.lineWidth=1.5+rnd()*.6;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(aa)*len,by+Math.sin(aa)*len);g.stroke();
    const aa2=aa+.06;g.beginPath();g.moveTo(bx,by);g.lineTo(bx+Math.cos(aa2)*len*.95,by+Math.sin(aa2)*len*.95);g.stroke()}}}
 // ограничить круглой маской, чтобы не было квадратных краёв
 g.globalCompositeOperation='destination-in';const m=g.createRadialGradient(cx,cy,S*.22,cx,cy,S*.5);m.addColorStop(0,'#fff');m.addColorStop(.85,'rgba(255,255,255,.9)');m.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=m;g.fillRect(0,0,S,S);
 const t=TX_tex(c,true,false);t.wrapS=t.wrapT=THREE.ClampToEdgeWrapping;return t}

// ---------------- ЛАПА ЕЛИ (ось + иглы елочкой) ----------------
function TX_frond(){
 const W=256,Hh=512,[c,g]=TX_cvs(W,Hh),rnd=TX_rng(41);g.lineCap='round';
 const cols=['#173424','#1f4029','#2a5230','#356a38','#1a3320','#4a7a45','#7aa55c'];
 const x0=W/2;g.strokeStyle='#4a3322';g.lineWidth=3;g.beginPath();g.moveTo(x0,Hh-6);g.lineTo(x0,10);g.stroke();
 for(let i=0;i<150;i++){const t=i/150,y=Hh-10-t*(Hh-30),L=(112*Math.pow(1-t,.65)+8)*(.85+rnd()*.3);
  for(const sd of[-1,1])for(let k=0;k<3;k++){const a=-Math.PI/2+sd*(1.15-.5*t+(rnd()-.5)*.35),len=L*(.75+rnd()*.35),yy=y+(rnd()-.5)*4;
   g.strokeStyle=cols[(t>.9?4+rnd()*3:rnd()*5)|0];g.lineWidth=1.5+rnd()*.5;g.beginPath();g.moveTo(x0,yy);g.lineTo(x0+Math.cos(a)*len,yy+Math.sin(a)*len);g.stroke()}}
 const t=TX_tex(c,true,false);t.wrapS=t.wrapT=THREE.ClampToEdgeWrapping;return t}

// ---------------- ТРАВА (пучок) ----------------
function TX_grass(){
 const S=256,[c,g]=TX_cvs(S,S),rnd=TX_rng(51),cols=['#4a5d2a','#5e7332','#7a7c3c','#8a7b46','#35491f','#6b7d38','#9a8d52'];
 for(let i=0;i<70;i++){const bx=S/2+(rnd()-.5)*90,h=70+rnd()*170,lean=(rnd()-.5)*110,w=2.5+rnd()*3,col=cols[rnd()*cols.length|0];
  const tx=bx+lean,ty=S-h,cx2=bx+lean*.15,cy2=S-h*.6;
  const gr=g.createLinearGradient(0,S,0,ty);gr.addColorStop(0,'#1f2a12');gr.addColorStop(.35,col);gr.addColorStop(1,col);g.fillStyle=gr;
  g.beginPath();g.moveTo(bx-w,S);g.quadraticCurveTo(cx2-w*.6,cy2,tx,ty);g.quadraticCurveTo(cx2+w*.6,cy2,bx+w,S);g.closePath();g.fill()}
 const t=TX_tex(c,true,false);t.wrapS=t.wrapT=THREE.ClampToEdgeWrapping;return t}

// ---------------- КАМЕНЬ с лишайником ----------------
function TX_rock(){
 const N=512,[c,g]=TX_cvs(N,N),im=g.createImageData(N,N),d=im.data,H=new Float32Array(N*N);
 for(let y=0;y<N;y++)for(let x=0;x<N;x++){const u=x/N,v=y/N,n=TX_fbm(u*5,v*5,5,5,5,61),w=TX_fbm(u*3,v*3,3,3,3,62),rg=1-Math.abs(TX_fbm(u*6+w,v*6,6,6,4,63)-.5)*2;
  const crack=1-TX_ss(.0,.06,1-rg),fine=TX_fbm(u*60,v*60,60,60,3,64),li=TX_cl((TX_fbm(u*10,v*10,10,10,4,65)-.58)/.1);
  let k=TX_lerp(70,135,n)*(.8+.3*fine);let r=k,gg=k*.98,b=k*.94;
  r=TX_lerp(r,95,li*.6);gg=TX_lerp(gg,120,li*.6);b=TX_lerp(b,70,li*.6);
  const ao=1-crack*.7;const i=(y*N+x)*4;d[i]=r*ao;d[i+1]=gg*ao;d[i+2]=b*ao;d[i+3]=255;H[y*N+x]=(.5*n+.3*fine+.2*rg)*(1-crack*.8)}
 g.putImageData(im,0,0);return{map:TX_tex(c),normalMap:TX_normalMap(H,N,N,5)}}
