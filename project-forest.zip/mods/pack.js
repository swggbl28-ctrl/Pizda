// Запуск: node mods/pack.js <папка_вывода>   (CI: node mods/pack.js www/mods)
// Каждую папку mods/<id>/ (кроме начинающихся с _ или .) упаковывает в <out>/<id>.zip (README.md не входит) и пишет <out>/index.json.
const fs = require('fs'), path = require('path'), { execFileSync } = require('child_process');
const out = path.resolve(process.argv[2] || path.join(__dirname, 'dist')), list = [];
fs.mkdirSync(out, { recursive: true });
for (const d of fs.readdirSync(__dirname, { withFileTypes: true })) {
  const dir = path.join(__dirname, d.name), mf = path.join(dir, 'mod.json');
  if (!d.isDirectory() || /^[_.]/.test(d.name) || d.name === 'dist' || !fs.existsSync(mf)) continue;
  const m = JSON.parse(fs.readFileSync(mf, 'utf8')), zip = path.join(out, d.name + '.zip');
  fs.rmSync(zip, { force: true });
  execFileSync('zip', ['-qr', zip, '.', '-x', 'README.md'], { cwd: dir });
  list.push({ file: d.name + '.zip', id: m.id || d.name, version: m.version || '' });
}
fs.writeFileSync(path.join(out, 'index.json'), JSON.stringify(list));
console.log('mods:', list.map((x) => x.file).join(', ') || 'нет');
