# Мод «Аниме-девушка»
Сущность: стоит на земле, поворачивается к игроку, играет idle-анимацию. Спавн — меню Q/☰ → «Персонажи».
Без `model.glb` рисуется простая заглушка. Чтобы получить настоящую модель, положи `model.glb` в корень мода/ZIP.

## Где взять модель (проверено поиском; я не мог скачать файлы — в моей среде нет доступа к сети)
Свободные (CC-BY, указывай автора), есть GLB:
- Anime Maid Girl — автор VR Avatars, ~49k треугольников: https://downloadforfree.gumroad.com/l/free-anime-maid-girl-3d-model (цена «0» в поле «Name a fair price»; архив ~102 МБ)
- Anime Girl Base Mesh — ALexz.art, 13k треугольников (лёгкая, для телефона): https://downloadforfree.gumroad.com/l/free-anime-girl-base-mesh-3d-model
- Theresa (VRM/GLB, бесплатная версия для теста, коммерция от $5): https://thatnewdevgirl.itch.io/free-3d-anime-girl-theresa

## Мита (MiSide)
Свободной лицензированной версии не нашёл. Фанатские модели платные или с запретом перезалива (Gumroad MayoSplash — «personal use only, no re-upload», itch.io — от $15). Для личного использования скачай сам, конвертируй в GLB (Blender: File → Export → glTF Binary) и положи в ZIP на телефоне. В публичный репозиторий не коммить.
