// Мод-СУЩНОСТЬ: персонаж стоит на земле, поворачивается к игроку, играет idle-анимацию из GLB (если есть).
// Модель: положи model.glb (или .vrm переименуй в .glb) в корень мода. Нет файла — рисуется простая заглушка.
// Конфиг — mod.json → "spawn": { id, name, cat, icon, model, height(м), look(радиус взгляда, м), max(шт.) }
import * as THREE from 'three';

function girl() { // заглушка ~1.7 м, лицом к +Z
  const M = (c) => new THREE.MeshStandardMaterial({ color: c, roughness: .7 }), skin = M(0xf1cdb8), hair = M(0x232b52), dress = M(0xf2f2f8), acc = M(0x4a6fa5), eye = M(0x1a1a2e);
  const g = new THREE.Group(), cyl = (a, b, l) => new THREE.CylinderGeometry(a, b, l, 12), sph = new THREE.SphereGeometry(1, 16, 12);
  const add = (geo, m, x, y, z, sx = 1, sy = 1, sz = 1) => { const o = new THREE.Mesh(geo, m); o.position.set(x, y, z); o.scale.set(sx, sy, sz); g.add(o); };
  add(cyl(.06, .05, .8), skin, -.08, .4, 0); add(cyl(.06, .05, .8), skin, .08, .4, 0);
  add(cyl(.2, .3, .45), dress, 0, .88, 0); add(cyl(.14, .17, .4), dress, 0, 1.2, 0);
  add(cyl(.04, .035, .55), skin, -.22, 1.15, 0); add(cyl(.04, .035, .55), skin, .22, 1.15, 0);
  add(sph, skin, 0, 1.52, 0, .12, .13, .12); add(sph, hair, 0, 1.56, -.02, .135, .135, .13); add(sph, hair, 0, 1.3, -.1, .12, .35, .08);
  add(sph, eye, -.045, 1.52, .105, .018, .028, .01); add(sph, eye, .045, 1.52, .105, .018, .028, .01); add(sph, acc, 0, 1.33, .15, .04, .03, .02);
  return g;
}

export async function init(game, mod) {
  const C = mod.meta.spawn, ents = [];
  let model = null, SU = null;
  const url = mod.url(C.model);
  if (url) try {
    const [{ GLTFLoader }, su] = await Promise.all([import('three/addons/loaders/GLTFLoader.js'), import('three/addons/utils/SkeletonUtils.js')]);
    model = await new GLTFLoader().loadAsync(url); SU = su;
  } catch (e) { console.warn('[anime-girl] модель не загрузилась, использую заглушку:', e); }

  const base = model ? model.scene : girl(), bb = new THREE.Box3().setFromObject(base);
  const k = C.height / (bb.max.y - bb.min.y), y0 = -bb.min.y * k;

  const spawn = (pos) => {
    if (ents.length >= C.max) ents.shift().g.removeFromParent();
    const o = model ? SU.clone(base) : girl(), g = new THREE.Group();
    o.scale.setScalar(k); o.position.y = y0; g.add(o); g.position.copy(pos);
    o.traverse((m) => { if (m.isMesh) m.castShadow = true; });
    let mixer = null;
    if (model?.animations.length) { mixer = new THREE.AnimationMixer(o); mixer.clipAction(model.animations.find((a) => /idle/i.test(a.name)) || model.animations[0]).play(); }
    game.scene.add(g); ents.push({ g, o, mixer, t: Math.random() * 6 });
  };

  game.onUpdate((dt) => {
    const c = game.camera; if (!c) return;
    for (const e of ents) {
      e.mixer?.update(dt); e.t += dt;
      const dx = c.position.x - e.g.position.x, dz = c.position.z - e.g.position.z;
      if (dx * dx + dz * dz < C.look * C.look) { let d = Math.atan2(dx, dz) - e.g.rotation.y; d = Math.atan2(Math.sin(d), Math.cos(d)); e.g.rotation.y += d * Math.min(1, dt * 3); }
      if (!e.mixer) e.o.scale.y = k * (1 + Math.sin(e.t * 1.8) * .006);
    }
  });

  // регистрация в меню спавна (SPAWN появляется после старта игры — ждём без блокировки)
  const reg = () => window.SPAWN && (window.SPAWN.add({ id: C.id, name: C.name, cat: C.cat, icon: C.icon, spawn }), true);
  if (!reg()) { const t = setInterval(() => reg() && clearInterval(t), 300); mod.cleanup(() => clearInterval(t)); }
  mod.cleanup(() => { ents.forEach((e) => e.g.removeFromParent()); window.SPAWN?.remove(C.id); });
}
