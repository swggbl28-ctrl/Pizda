// ШАБЛОН мода-ПРЕДМЕТА (физический проп: гравипушка берёт/бросает, падает, сталкивается).
// Копируй папку, меняй id/name/icon/model/size/r/mass в mod.json. Нет model.glb — рисуется серый куб.
// size — наибольший габарит модели (м), r — радиус физической сферы (м), mass — масса (чем больше, тем слабее бросок).
// Для сущности со своей логикой (ИИ, анимации) смотри ../anime-girl/main.js: вместо make — spawn(pos).
import * as THREE from 'three';

export async function init(game, mod) {
  const C = mod.meta.spawn;
  let proto = null;
  const url = mod.url(C.model);
  if (url) try { const { GLTFLoader } = await import('three/addons/loaders/GLTFLoader.js'); proto = (await new GLTFLoader().loadAsync(url)).scene; }
  catch (e) { console.warn('[' + C.id + '] модель не загрузилась, куб:', e); }

  const make = () => { // центр модели = центр физической сферы
    if (!proto) return new THREE.Mesh(new THREE.BoxGeometry(.6, .6, .6), new THREE.MeshStandardMaterial({ color: 0xcccccc }));
    const o = proto.clone(true), b = new THREE.Box3().setFromObject(o), s = b.getSize(new THREE.Vector3()), kk = C.size / Math.max(s.x, s.y, s.z);
    o.scale.setScalar(kk); o.position.sub(b.getCenter(new THREE.Vector3()).multiplyScalar(kk));
    return new THREE.Group().add(o);
  };

  const reg = () => window.SPAWN && (window.SPAWN.add({ id: C.id, name: C.name, cat: C.cat, icon: C.icon, r: C.r, mass: C.mass, make }), true);
  if (!reg()) { const t = setInterval(() => reg() && clearInterval(t), 300); mod.cleanup(() => clearInterval(t)); }
  mod.cleanup(() => window.SPAWN?.remove(C.id));
}
