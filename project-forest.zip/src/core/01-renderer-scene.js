//# FILE: core/01-renderer-scene.js
//# ЧТО: рендерер R, сцена S, камера cam, туман, лунный свет MOONL, ambient, качество Q.
//# ТОП-УРОВЕНЬ: $, MOB, Q, R, S, cam, FOGC, MOON_DIR, MOONL, HEMI
const $=i=>document.getElementById(i);
const MOB=matchMedia('(pointer:coarse)').matches||/Android|iPhone|iPad/i.test(navigator.userAgent);
const Q=MOB?{chunks:2,shadow:1024,tex:1024,crown:.6,grass:120,dpr:1.5}:{chunks:3,shadow:2048,tex:2048,crown:1,grass:260,dpr:2};
const R=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
R.setPixelRatio(Math.min(devicePixelRatio,Q.dpr));R.setSize(innerWidth,innerHeight);
R.outputColorSpace=THREE.SRGBColorSpace;R.toneMapping=THREE.ACESFilmicToneMapping;R.toneMappingExposure=1.5;
R.shadowMap.enabled=true;R.shadowMap.type=THREE.PCFSoftShadowMap;document.body.prepend(R.domElement);
const S=new THREE.Scene();
const FOGC=new THREE.Color(0x3a4d66);S.background=FOGC.clone();S.fog=new THREE.FogExp2(FOGC,MOB?.028:.021);
const cam=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.05,420);cam.rotation.order='YXZ';S.add(cam);
addEventListener('resize',()=>{R.setSize(innerWidth,innerHeight);cam.aspect=innerWidth/innerHeight;cam.updateProjectionMatrix()});
// Луна: направление ИЗ которого приходит свет (на небе — в этой же точке)
const MOON_DIR=new THREE.Vector3(Math.cos(.62)*Math.cos(.8),Math.sin(.8),Math.sin(.62)*Math.cos(.8)).normalize();
const MOONL=new THREE.DirectionalLight(0xb4c9ff,5.2);MOONL.castShadow=true;
MOONL.shadow.mapSize.set(Q.shadow,Q.shadow);const SH=MOB?32:52;
Object.assign(MOONL.shadow.camera,{left:-SH,right:SH,top:SH,bottom:-SH,near:1,far:330});
MOONL.shadow.bias=-.0004;MOONL.shadow.normalBias=.07;MOONL.shadow.camera.updateProjectionMatrix();
S.add(MOONL,MOONL.target);
const HEMI=new THREE.HemisphereLight(0x86a3d0,0x33422f,2.1);S.add(HEMI);
