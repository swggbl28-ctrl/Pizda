//# FILE: core/02-textures.js
//# ЧТО: маркер подстановки секции A из textures.js (генераторы текстур леса).
//@TEXTURES:A@
