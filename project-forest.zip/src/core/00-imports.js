//# FILE: core/00-imports.js
//# ЧТО: import THREE и заглушка window.mp (мультиплеер-хуки). Всегда первым.
//# СКОУП: не ES-модуль; все game-файлы склеиваются в один модуль (порядок — src/order.json), имена из других файлов доступны напрямую.
import * as THREE from 'three';
window.mp={on:0,host:0,sync(){},ev(){}};
