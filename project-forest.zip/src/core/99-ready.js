//# FILE: core/99-ready.js
//# ЧТО: Сигнал window.__gameReady. Всегда последним.
window.__gameReady&&window.__gameReady();
