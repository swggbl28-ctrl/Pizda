//# FILE: mechanics/automods.js
//# ЧТО: автоустановка модов, вшитых в APK (mods/index.json → bridge: game.mods.install). Ставит мод, если его нет или версия другая.
(async () => {
  const g = window.game, r = await fetch('mods/index.json');
  if (!g?.mods || !r.ok) return;
  const have = new Map(g.mods.list().map((x) => [x.id, x.version]));
  for (const m of await r.json()) if (have.get(m.id) !== m.version) await g.mods.install('mods/' + m.file);
})();
