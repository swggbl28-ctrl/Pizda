//# FILE: mechanics/gravgun.js
//# ЧТО: гравитационная пушка: ПКМ/E — хват и бросок вниз, ЛКМ/F — удар (выстрел удерживаемым), колесо — дистанция. На телефоне — кнопки «Хват»/«Удар».
//# ТОП-УРОВЕНЬ: GG, GG_grab, GG_drop, GG_punch, GG_tick
const GG={held:null,dist:4,kick:0},GG_f=new THREE.Vector3(),GG_t=new THREE.Vector3(),
 GG_orb=new THREE.MeshBasicMaterial({color:0xff9a2e}),GG_view=new THREE.Group();
{const m=new THREE.MeshStandardMaterial({color:0x2a2e36,metalness:.6,roughness:.4}),add=(g,x,y,z,mt)=>{const o=new THREE.Mesh(g,mt||m);o.position.set(x,y,z);GG_view.add(o)};
 add(new THREE.BoxGeometry(.09,.1,.4),0,0,0);add(new THREE.BoxGeometry(.02,.02,.26),-.05,.06,-.24);add(new THREE.BoxGeometry(.02,.02,.26),.05,.06,-.24);
 add(new THREE.SphereGeometry(.035,12,8),0,.03,-.22,GG_orb);
 GG_view.position.set(.2,-.22,-.55);GG_view.rotation.y=.08;cam.add(GG_view)}
const GG_dir=()=>{cam.updateMatrixWorld();return cam.getWorldDirection(GG_f)};
function GG_drop(){if(GG.held){GG.held.held=0;GG.held=null}}
function GG_grab(){
 if(GG.held)return GG_drop();
 const h=PR_pick(cam.position,GG_dir(),16);
 if(h){GG.held=h.b;h.b.held=1;h.b.rest=0;GG.dist=PR_cl(h.t,2,6)}}
function GG_punch(){
 const d=GG_dir();let b=GG.held;
 if(b)GG_drop();else{const h=PR_pick(cam.position,d,24);b=h&&h.b}
 if(b){b.rest=0;b.v.copy(d).multiplyScalar(30/Math.cbrt(b.m));b.w.set(Math.random()-.5,Math.random()-.5,Math.random()-.5).multiplyScalar(14)}
 GG.kick=1}
function GG_tick(dt){
 const b=GG.held;GG.kick=Math.max(0,GG.kick-dt*6);
 if(b){GG_t.copy(cam.position).addScaledVector(GG_dir(),GG.dist);b.v.copy(GG_t).sub(b.mesh.position).multiplyScalar(14);const s=b.v.length();if(s>30)b.v.multiplyScalar(30/s);b.w.multiplyScalar(.9)}
 GG_orb.color.setHex(b?0x4fb0ff:0xff9a2e);GG_view.position.z=-.55+GG.kick*.12}
// ---- ввод ----
const GG_typing=()=>/INPUT|TEXTAREA/.test(document.activeElement.tagName);
addEventListener('mousedown',e=>{if(document.pointerLockElement!==R.domElement)return;if(e.button===0)GG_punch();else if(e.button===2)GG_grab()});
addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('keydown',e=>{if(e.repeat||GG_typing())return;if(e.code==='KeyE')GG_grab();else if(e.code==='KeyF')GG_punch()});
addEventListener('wheel',e=>{if(GG.held)GG.dist=PR_cl(GG.dist-Math.sign(e.deltaY)*.5,1.5,10)});
// ---- HUD: прицел + кнопки для телефона ----
{const st=document.createElement('style');st.textContent=`#xh{position:fixed;left:50%;top:50%;width:6px;height:6px;margin:-3px;border-radius:50%;background:#fff9;pointer-events:none}
#gg{position:fixed;right:max(20px,env(safe-area-inset-right));bottom:max(24px,env(safe-area-inset-bottom));display:none;gap:12px;z-index:20}
@media (pointer:coarse){#gg{display:flex}}
#gg button{width:76px;height:76px;border-radius:50%;border:2px solid #7f9cbb99;background:#10182499;color:#cfe0f0;font:600 14px sans-serif;touch-action:none}`;document.head.appendChild(st);
 const x=document.createElement('div');x.id='xh';const w=document.createElement('div');w.id='gg';w.innerHTML='<button data-a="g">Хват</button><button data-a="p">Удар</button>';
 w.addEventListener('pointerdown',e=>{const a=e.target.dataset.a;if(!a)return;e.preventDefault();e.stopPropagation();a==='g'?GG_grab():GG_punch()});
 document.body.append(x,w)}
