//# FILE: mechanics/props.js
//# ЧТО: реестр спавна SPAWN, физические пропсы, прицел PR_aim, выбор луча PR_pick.
//# ТОП-УРОВЕНЬ: SPAWN, PR_bodies, PR_add, PR_aim, PR_pick, PR_tick
// Регистрация предмета/сущности из любого файла игры:
//   SPAWN.add({id,name,cat,icon,make:()=>Object3D,r:радиус,mass,round})  — физический проп
//   SPAWN.add({id,name,cat,icon,spawn:pos=>...})                         — своя сущность (pos — точка прицела)
const PR_bodies=[],PR_MAX=120,PR_col=[],PR_cl=(v,a,b)=>Math.max(a,Math.min(b,v));
const PR_d=new THREE.Vector3(),PR_f=new THREE.Vector3(),PR_ax=new THREE.Vector3(),PR_dq=new THREE.Quaternion();
const SPAWN=window.SPAWN={items:[],
 add(d){const i=this.items.findIndex(x=>x.id===d.id);if(i<0)this.items.push(d);else this.items[i]=d;return d},
 remove(id){this.items=this.items.filter(x=>x.id!==id)},
 cats(){return[...new Set(this.items.map(d=>d.cat||'Разное'))]},
 spawn(id,pos){const d=this.items.find(x=>x.id===id);return d&&(d.spawn?d.spawn(pos):PR_add(d,pos))}};
function PR_add(d,pos){
 const mesh=d.make();mesh.traverse(o=>{if(o.isMesh)o.castShadow=o.receiveShadow=true});
 mesh.position.copy(pos);mesh.position.y+=d.r+.02;mesh.rotation.y=Math.random()*6.28;S.add(mesh);
 const b={mesh,v:new THREE.Vector3(),w:new THREE.Vector3(),r:d.r,m:d.mass||1,round:!!d.round,held:0,rest:0};PR_bodies.push(b);
 if(PR_bodies.length>PR_MAX){const i=PR_bodies.findIndex(x=>!x.held);if(i>=0){S.remove(PR_bodies[i].mesh);PR_bodies.splice(i,1)}}
 return b}
// точка, куда смотрит камера (земля), иначе 5 м вперёд
function PR_aim(max=30){cam.updateMatrixWorld();cam.getWorldDirection(PR_f);const p=new THREE.Vector3();
 for(let t=1;t<max;t+=.5){p.copy(cam.position).addScaledVector(PR_f,t);if(p.y<terrainH(p.x,p.z)){p.y=terrainH(p.x,p.z);return p}}
 return p.copy(cam.position).addScaledVector(PR_f,5)}
// тело под лучом (o — начало, d — единичное направление)
function PR_pick(o,d,max){let best=null,bt=max;
 for(const b of PR_bodies){PR_d.subVectors(b.mesh.position,o);const t=PR_d.dot(d);if(t<0||t>bt)continue;const r=b.r*1.15;if(PR_d.lengthSq()-t*t<r*r){best=b;bt=t}}
 return best&&{b:best,t:bt}}
function PR_step(b,dt){
 if(b.rest)return;
 const p=b.mesh.position,v=b.v;
 if(!b.held)v.y-=12*dt;
 p.addScaledVector(v,dt);
 forestColliders(p.x,p.z,PR_col);
 for(const o of PR_col){const dx=p.x-o.x,dz=p.z-o.z,d=Math.hypot(dx,dz),m=o.r+b.r*.8;
  if(d<m&&d>1e-4){const nx=dx/d,nz=dz/d,vn=v.x*nx+v.z*nz;p.x=o.x+nx*m;p.z=o.z+nz*m;if(vn<0){v.x-=1.4*vn*nx;v.z-=1.4*vn*nz}}}
 const gy=terrainH(p.x,p.z)+b.r;let g=0;
 if(p.y<=gy){p.y=gy;g=1;if(v.y<-1.5)v.y*=-.3;else v.y=0;const f=Math.exp(-(b.round?.5:3)*dt);v.x*=f;v.z*=f}
 if(g&&b.round)b.w.set(v.z,0,-v.x).divideScalar(b.r);else b.w.multiplyScalar(Math.exp(-(g?5:.3)*dt));
 const wl=b.w.length();if(wl>1e-3){PR_dq.setFromAxisAngle(PR_ax.copy(b.w).divideScalar(wl),wl*dt);b.mesh.quaternion.premultiply(PR_dq)}
 if(g&&!b.held&&v.lengthSq()<.02){v.set(0,0,0);b.w.set(0,0,0);b.rest=1}}
function PR_pairs(){const B=PR_bodies;
 for(let i=0;i<B.length;i++)for(let j=i+1;j<B.length;j++){const a=B[i],b=B[j];if(a.rest&&b.rest)continue;
  PR_d.subVectors(b.mesh.position,a.mesh.position);const d=PR_d.length(),m=a.r+b.r;if(d>=m||d<1e-4)continue;
  PR_d.divideScalar(d);const ia=a.held?0:1/a.m,ib=b.held?0:1/b.m,s=ia+ib;if(!s)continue;
  const o=(m-d)/s;a.mesh.position.addScaledVector(PR_d,-o*ia);b.mesh.position.addScaledVector(PR_d,o*ib);
  const vn=(b.v.x-a.v.x)*PR_d.x+(b.v.y-a.v.y)*PR_d.y+(b.v.z-a.v.z)*PR_d.z;
  if(vn<0){const k=-1.3*vn/s;a.v.addScaledVector(PR_d,-k*ia);b.v.addScaledVector(PR_d,k*ib)}
  a.rest=b.rest=0}}
function PR_tick(dt){for(const b of PR_bodies)PR_step(b,dt);PR_pairs()}
// ---- стартовый набор ----
{const mat=c=>new THREE.MeshStandardMaterial({color:c,roughness:.85,metalness:.05}),
 box=new THREE.BoxGeometry(.8,.8,.8),cyl=new THREE.CylinderGeometry(.3,.3,.9,16),sph=new THREE.SphereGeometry(.35,20,14),rock=new THREE.IcosahedronGeometry(.42,0),
 mw=mat(0x8a6a44),mb=mat(0x3f5f7a),mr=mat(0xb34a3a),mk=new THREE.MeshStandardMaterial({color:0x6b6f73,roughness:1,flatShading:true});
 SPAWN.add({id:'crate',name:'Ящик',cat:'Пропсы',icon:'📦',r:.45,mass:3,make:()=>new THREE.Mesh(box,mw)});
 SPAWN.add({id:'barrel',name:'Бочка',cat:'Пропсы',icon:'🛢️',r:.45,mass:4,make:()=>new THREE.Mesh(cyl,mb)});
 SPAWN.add({id:'ball',name:'Мяч',cat:'Пропсы',icon:'⚽',r:.35,mass:1,round:true,make:()=>new THREE.Mesh(sph,mr)});
 SPAWN.add({id:'rock',name:'Камень',cat:'Природа',icon:'🪨',r:.4,mass:6,make:()=>new THREE.Mesh(rock,mk)})}
