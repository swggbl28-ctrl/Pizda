//# FILE: mechanics/player.js
//# ЧТО: игрок от первого лица (WASD/мышь, джойстик/свайп), столкновения со стволами, привязка луны к игроку (тени), главный цикл.
//# ТОП-УРОВЕНЬ: PL, PL_tick
const PL={x:0,z:0,yaw:Math.atan2(-MOON_DIR.x,-MOON_DIR.z),pitch:.5,vx:0,vz:0,bob:0},PL_keys={},PL_col=[],PL_joy={x:0,y:0,on:0},PL_clock=new THREE.Clock();
addEventListener('keydown',e=>{PL_keys[e.code]=1});addEventListener('keyup',e=>{PL_keys[e.code]=0});addEventListener('blur',()=>{for(const k in PL_keys)PL_keys[k]=0});
const PL_cv=R.domElement;
PL_cv.addEventListener('click',()=>{if(!MOB&&document.pointerLockElement!==PL_cv&&PL_cv.requestPointerLock)PL_cv.requestPointerLock()});
addEventListener('mousemove',e=>{if(document.pointerLockElement===PL_cv){PL.yaw-=e.movementX*.0022;PL.pitch=TX_cl(PL.pitch-e.movementY*.0022,-1.45,1.45)}});
// сенсор: свайп — осмотр, джойстик — ходьба
let PL_look=null;
PL_cv.addEventListener('pointerdown',e=>{if(e.pointerType!=='mouse'&&PL_look===null){PL_look={id:e.pointerId,x:e.clientX,y:e.clientY};PL_cv.setPointerCapture(e.pointerId)}});
PL_cv.addEventListener('pointermove',e=>{if(PL_look&&e.pointerId===PL_look.id){PL.yaw-=(e.clientX-PL_look.x)*.005;PL.pitch=TX_cl(PL.pitch-(e.clientY-PL_look.y)*.005,-1.45,1.45);PL_look.x=e.clientX;PL_look.y=e.clientY}});
const PL_up=e=>{if(PL_look&&e.pointerId===PL_look.id)PL_look=null};PL_cv.addEventListener('pointerup',PL_up);PL_cv.addEventListener('pointercancel',PL_up);
{const j=$('joy'),kn=$('kn');let id=null;
 const set=e=>{const b=j.getBoundingClientRect(),cx=b.left+b.width/2,cy=b.top+b.height/2;let dx=(e.clientX-cx)/(b.width/2),dy=(e.clientY-cy)/(b.height/2);const l=Math.hypot(dx,dy);if(l>1){dx/=l;dy/=l}PL_joy.x=dx;PL_joy.y=dy;kn.style.transform=`translate(${dx*35}px,${dy*35}px)`};
 j.addEventListener('pointerdown',e=>{id=e.pointerId;j.setPointerCapture(id);PL_joy.on=1;set(e);e.stopPropagation()});
 j.addEventListener('pointermove',e=>{if(e.pointerId===id)set(e)});
 const end=e=>{if(e.pointerId===id){id=null;PL_joy.x=PL_joy.y=0;PL_joy.on=0;kn.style.transform=''}};j.addEventListener('pointerup',end);j.addEventListener('pointercancel',end)}
setTimeout(()=>{const h=$('hint');if(h)h.style.opacity=0},12000);
// луна: тени не «плывут» — цель света шагает по сетке теплов карты теней
const PL_r=new THREE.Vector3(),PL_u=new THREE.Vector3(),PL_UP=new THREE.Vector3(0,1,0);
function PL_moon(px,py,pz){const tx=2*MOONL.shadow.camera.right/Q.shadow;PL_r.crossVectors(PL_UP,MOON_DIR).normalize();PL_u.crossVectors(MOON_DIR,PL_r);
 const a=Math.round((px*PL_r.x+py*PL_r.y+pz*PL_r.z)/tx)*tx,b=Math.round((px*PL_u.x+py*PL_u.y+pz*PL_u.z)/tx)*tx,c=px*MOON_DIR.x+py*MOON_DIR.y+pz*MOON_DIR.z;
 MOONL.target.position.set(0,0,0).addScaledVector(PL_r,a).addScaledVector(PL_u,b).addScaledVector(MOON_DIR,c);MOONL.position.copy(MOONL.target.position).addScaledVector(MOON_DIR,150)}
function PL_tick(){
 const dt=Math.min(PL_clock.getDelta(),.05),t=PL_clock.elapsedTime;
 let fx=(PL_keys.KeyD||PL_keys.ArrowRight?1:0)-(PL_keys.KeyA||PL_keys.ArrowLeft?1:0)+PL_joy.x,fz=(PL_keys.KeyS||PL_keys.ArrowDown?1:0)-(PL_keys.KeyW||PL_keys.ArrowUp?1:0)+PL_joy.y;
 const l=Math.hypot(fx,fz);if(l>1){fx/=l;fz/=l}
 const run=PL_keys.ShiftLeft||PL_keys.ShiftRight||(PL_joy.on&&l>.92),sp=run?5.4:2.4,s=Math.sin(PL.yaw),c=Math.cos(PL.yaw);
 const tvx=(fx*c+fz*s)*sp,tvz=(-fx*s+fz*c)*sp,k=1-Math.exp(-10*dt);PL.vx+=(tvx-PL.vx)*k;PL.vz+=(tvz-PL.vz)*k;
 let nx=PL.x+PL.vx*dt,nz=PL.z+PL.vz*dt;
 forestColliders(nx,nz,PL_col);
 for(let it=0;it<2;it++)for(const o of PL_col){const dx=nx-o.x,dz=nz-o.z,d=Math.hypot(dx,dz),m=o.r+.32;if(d<m&&d>1e-4){nx=o.x+dx/d*m;nz=o.z+dz/d*m}}
 PL.x=nx;PL.z=nz;const spd=Math.hypot(PL.vx,PL.vz);PL.bob+=spd*dt*2.1;
 const gy=terrainH(PL.x,PL.z),ey=gy+1.7+Math.sin(PL.bob*2)*.035*Math.min(1,spd/2.4);
 cam.position.set(PL.x,ey,PL.z);cam.rotation.set(PL.pitch,PL.yaw,0);
 GG_tick(dt);PR_tick(dt);
 forestUpdate(PL.x,PL.z,false);F_T.value=t;SK_mat.uniforms.uTime.value=t;SK_mesh.position.copy(cam.position);PL_moon(PL.x,gy,PL.z);
 R.render(S,cam)}
{const y=terrainH(0,0);forestUpdate(0,0,true);PL_moon(0,y,0);R.setAnimationLoop(PL_tick)}
window.game={R,S,cam,PL,terrainH,F_chunks,MOON_DIR};
