//# FILE: ui/spawn-menu.js
//# ЧТО: меню спавна (клавиша Q / кнопка ☰): всё, что есть в SPAWN.items, с поиском и категориями. Предмет появляется в точке прицела.
//# ТОП-УРОВЕНЬ: SM
const SM={open:0,cat:'Все',q:''};
{const st=document.createElement('style');st.textContent=`#sm{position:fixed;inset:0;display:none;flex-direction:column;gap:10px;padding:max(12px,env(safe-area-inset-top)) 12px 12px;background:#0b0d12ee;z-index:30;color:#fff;font-family:system-ui,sans-serif}
#sm.on{display:flex}#sm-top{display:flex;gap:8px}
#sm-q{flex:1;min-width:0;padding:12px;border-radius:10px;border:0;background:#2a3142;color:#fff;font:inherit;user-select:text}
#sm button,#sm-btn{padding:10px 14px;border-radius:10px;border:0;background:#2a3142;color:#fff;font:inherit;white-space:nowrap}
#sm button:active{background:#3d4760}#sm button.on{background:#4a6fa5}
#sm-cats{display:flex;gap:8px;overflow-x:auto;touch-action:pan-x}
#sm-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:10px;overflow-y:auto;touch-action:pan-y;align-content:start}
#sm-grid button{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px}
#sm-grid i{font-style:normal;font-size:32px}
#sm-btn{position:fixed;top:max(10px,env(safe-area-inset-top));right:max(10px,env(safe-area-inset-right));z-index:25;width:44px;height:44px;padding:0!important;background:#10182499!important;border:2px solid #7f9cbb99!important}`;
 document.head.appendChild(st);
 const el=document.createElement('div');el.id='sm';el.innerHTML='<div id="sm-top"><input id="sm-q" placeholder="Поиск" autocomplete="off"><button data-x="1">✕</button></div><div id="sm-cats"></div><div id="sm-grid"></div>';
 const btn=document.createElement('button');btn.id='sm-btn';btn.textContent='☰';document.body.append(el,btn);
 const q=el.querySelector('#sm-q'),cats=el.querySelector('#sm-cats'),grid=el.querySelector('#sm-grid');
 const draw=()=>{const s=SM.q.toLowerCase();
  cats.innerHTML=['Все',...SPAWN.cats()].map(c=>`<button data-c="${c}"${c===SM.cat?' class="on"':''}>${c}</button>`).join('');
  grid.innerHTML=SPAWN.items.filter(d=>(SM.cat==='Все'||(d.cat||'Разное')===SM.cat)&&d.name.toLowerCase().includes(s)).map(d=>`<button data-id="${d.id}"><i>${d.icon||'◻'}</i>${d.name}</button>`).join('')||'<p>Пусто</p>'};
 const toggle=v=>{SM.open=v===undefined?!SM.open:v;el.classList.toggle('on',!!SM.open);if(SM.open){document.exitPointerLock&&document.exitPointerLock();GG_drop();draw()}};
 el.onclick=e=>{const t=e.target.closest('button');if(!t)return;
  if(t.dataset.x)toggle(0);else if(t.dataset.c){SM.cat=t.dataset.c;draw()}else if(t.dataset.id){SPAWN.spawn(t.dataset.id,PR_aim());toggle(0)}};
 q.oninput=()=>{SM.q=q.value;draw()};
 for(const t of['keydown','keyup'])q.addEventListener(t,e=>{if(t==='keydown'&&e.code==='Escape')toggle(0);e.stopPropagation()});
 btn.onclick=()=>toggle();
 addEventListener('keydown',e=>{if(e.repeat)return;if(e.code==='KeyQ')toggle();else if(e.code==='Escape'&&SM.open)toggle(0)})}
