//# FILE: world/terrain.js
//# ЧТО: функция рельефа terrainH(x,z), плотность леса, текстуры (GT земля, BK кора, TF кисть, FR лапа ели, GR трава, RK камень), материал земли и построение мэша земли чанка.
//# ТОП-УРОВЕНЬ: CH, TNZ, terrainH, forestDensity, GT, BK, TF, FR, GRS, RK, groundMat, buildGround
const CH=40; // размер чанка, м
const TNZ=(x,z,s)=>TX_vn(x,z,65536,65536,s);
function terrainH(x,z){return 9*(TNZ(x/90,z/90,101)-.5)+3*(TNZ(x/28,z/28,102)-.5)+.5*(TNZ(x/7,z/7,103)-.5)}
function forestDensity(x,z){return TX_ss(.25,.55,TNZ(x/150,z/150,121))}
const GT=TX_ground(Q.tex),BK=TX_bark(),TF=TX_tuft(),FR=TX_frond(),GRS=TX_grass(),RK=TX_rock();
const GTILE=Q.tex/512; // 512 px на метр
const groundMat=new THREE.MeshStandardMaterial({map:GT.map,normalMap:GT.normalMap,normalScale:new THREE.Vector2(1.3,1.3),roughness:.97,metalness:0,vertexColors:true});
groundMat.onBeforeCompile=sh=>{sh.fragmentShader=sh.fragmentShader.replace('#include <map_fragment>',`
 vec4 tA=texture2D(map,vMapUv);vec4 tB=texture2D(map,vMapUv*.73+vec2(.37,.11));
 float wv=.5+.5*sin(vMapUv.x*1.3+sin(vMapUv.y*1.7)*1.9)*sin(vMapUv.y*1.1+sin(vMapUv.x*.9)*2.1);
 diffuseColor*=mix(tA,tB*vec4(1.1,1.05,1.,1.),wv*.55);`)};
function buildGround(cx,cz){
 const seg=40,geo=new THREE.PlaneGeometry(CH,CH,seg,seg);geo.rotateX(-Math.PI/2);
 const pos=geo.attributes.position,uv=geo.attributes.uv,n=pos.count,col=new Float32Array(n*3),nor=new Float32Array(n*3),ox=cx*CH+CH/2,oz=cz*CH+CH/2,e=.5;
 for(let i=0;i<n;i++){const x=pos.getX(i)+ox,z=pos.getZ(i)+oz;pos.setY(i,terrainH(x,z));
  let nx=terrainH(x-e,z)-terrainH(x+e,z),nz=terrainH(x,z-e)-terrainH(x,z+e),ny=2*e,k=1/Math.hypot(nx,ny,nz);nor[i*3]=nx*k;nor[i*3+1]=ny*k;nor[i*3+2]=nz*k;
  uv.setXY(i,x/GTILE,z/GTILE);
  const t1=TNZ(x/17,z/17,111),t2=TNZ(x/5.5,z/5.5,112),b=.72+.5*t1;col[i*3]=b*(1-.12*t2);col[i*3+1]=b*(1+.06*t2);col[i*3+2]=b*(1-.2*t2)}
 geo.setAttribute('normal',new THREE.BufferAttribute(nor,3));geo.setAttribute('color',new THREE.BufferAttribute(col,3));
 const m=new THREE.Mesh(geo,groundMat);m.position.set(ox,0,oz);m.receiveShadow=true;m.matrixAutoUpdate=false;m.updateMatrix();m.frustumCulled=true;
 geo.boundingSphere=new THREE.Sphere(new THREE.Vector3(0,0,0),CH*.75+10);return m}
