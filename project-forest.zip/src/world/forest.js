//# FILE: world/forest.js
//# ЧТО: геометрия сосен/ели/травы/камней/брёвен (процедурно), материалы с ветром, потоковые чанки бесконечного леса, коллайдеры деревьев.
//# ТОП-УРОВЕНЬ: F_*, forestUpdate, forestColliders
// ---------- буфер геометрии ----------
const F_G=()=>({p:[],n:[],uv:[],c:[],i:[]});
const F_geo=g=>{const o=new THREE.BufferGeometry();o.setAttribute('position',new THREE.Float32BufferAttribute(g.p,3));o.setAttribute('normal',new THREE.Float32BufferAttribute(g.n,3));o.setAttribute('uv',new THREE.Float32BufferAttribute(g.uv,2));o.setAttribute('color',new THREE.Float32BufferAttribute(g.c,3));o.setIndex(g.i);o.computeBoundingSphere();return o};
const F_nrm=(x,y,z)=>{const k=1/(Math.hypot(x,y,z)||1);return[x*k,y*k,z*k]};
// труба по пути (ствол, ветка, бревно)
function F_tube(g,path,radii,seg,vScale,uRep,colFn){
 const base=g.p.length/3;let len=0;
 for(let k=0;k<path.length;k++){const P=path[k],Pn=path[Math.min(k+1,path.length-1)],Pp=path[Math.max(k-1,0)];
  let T=F_nrm(Pn[0]-Pp[0],Pn[1]-Pp[1],Pn[2]-Pp[2]);const hx=Math.abs(T[1])<.9?[0,1,0]:[1,0,0];
  const n1=F_nrm(T[1]*hx[2]-T[2]*hx[1],T[2]*hx[0]-T[0]*hx[2],T[0]*hx[1]-T[1]*hx[0]);
  const n2=[T[1]*n1[2]-T[2]*n1[1],T[2]*n1[0]-T[0]*n1[2],T[0]*n1[1]-T[1]*n1[0]];
  if(k>0)len+=Math.hypot(P[0]-path[k-1][0],P[1]-path[k-1][1],P[2]-path[k-1][2]);
  const c=colFn(P,k);
  for(let j=0;j<=seg;j++){const a=j/seg*6.2832,ca=Math.cos(a),sa=Math.sin(a),nx=n1[0]*ca+n2[0]*sa,ny=n1[1]*ca+n2[1]*sa,nz=n1[2]*ca+n2[2]*sa;
   g.p.push(P[0]+nx*radii[k],P[1]+ny*radii[k],P[2]+nz*radii[k]);g.n.push(nx,ny,nz);g.uv.push(j/seg*uRep,len/vScale);g.c.push(c[0],c[1],c[2])}}
 for(let k=0;k<path.length-1;k++)for(let j=0;j<seg;j++){const a=base+k*(seg+1)+j,b=a+1,c=a+seg+1,d=c+1;g.i.push(a,b,c,b,d,c)}}
// двусторонняя карточка (две копии, нормали заданы вручную)
function F_quad(g,P,N,C,uvs){const b=g.p.length/3;for(let k=0;k<4;k++){g.p.push(...P[k]);g.n.push(...N[k]);g.uv.push(...uvs[k]);g.c.push(...C)}g.i.push(b,b+1,b+2,b,b+2,b+3,b,b+2,b+1,b,b+3,b+2)}
const F_UV=[[0,0],[1,0],[1,1],[0,1]];
// «кисть» хвои: 3 пересекающиеся карточки с мягкими нормалями от центра кроны
function F_puff(g,c,sz,th,tilt,cc,col){
 const h=sz/2,planes=[[[Math.cos(th),0,Math.sin(th)],[-Math.sin(th)*Math.sin(tilt),Math.cos(tilt),Math.cos(th)*Math.sin(tilt)]],
  [[Math.cos(th),0,Math.sin(th)],[0,1,0]],[[-Math.sin(th),0,Math.cos(th)],[0,1,0]]];
 for(const[ax,ay]of planes){const P=[],N=[];for(const[sx,sy]of[[-1,-1],[1,-1],[1,1],[-1,1]]){const p=[c[0]+ax[0]*h*sx+ay[0]*h*sy,c[1]+ax[1]*h*sx+ay[1]*h*sy,c[2]+ax[2]*h*sx+ay[2]*h*sy];P.push(p);
  const n=F_nrm(p[0]-cc[0],(p[1]-cc[1])*.8+.35*Math.hypot(p[0]-cc[0],p[2]-cc[2]),p[2]-cc[2]);N.push(n)}
  F_quad(g,P,N,col,F_UV)}}
// ---------- сосна ----------
function F_pine(seed,young){
 const r=TX_rng(seed*977+13),tr=F_G(),fo=F_G(),q=Q.crown;
 const H=young?4.5+r()*3.5:17+r()*9,r0=young?.07+r()*.04:.24+r()*.14,hc=H*(young?.1:.5+r()*.1);
 const lean=[(r()-.5)*.9,(r()-.5)*.9],ph=r()*6.28;
 const tp=h=>{const t=h/H;return[lean[0]*t*t+Math.sin(h*.35+ph)*.12*t,h,lean[1]*t*t+Math.cos(h*.29+ph)*.12*t]};
 const tcol=h=>{const s=TX_ss(.3,.62,h/H);return[TX_lerp(.8,1.5,s),TX_lerp(.77,.98,s),TX_lerp(.74,.62,s)]};
 const nR=young?6:14,path=[],rad=[];
 for(let k=0;k<=nR;k++){const t=Math.pow(k/nR,1.3),h=H*t;path.push(tp(h));rad.push((r0*Math.pow(1-t,.75)+.025)*(1+.7*Math.exp(-h*2.2)))}
 const uRep=Math.max(1,Math.round(6.283*r0/1.2));
 F_tube(tr,path,rad,young?6:MOB?8:10,2.4,uRep,(P)=>tcol(P[1]));
 const cc=[0,hc+(H-hc)*(young?.42:.55),0];
 const nb=Math.round((young?12:23)*q),Rmax=young?1.7:4.6;
 for(let i=0;i<nb;i++){const tb=Math.pow(r(),.9),hb=hc+(H*.97-hc)*(1-tb*.0)*((i+r())/nb),T=(hb-hc)/(H-hc);
  const yaw=i*2.399+r()*.5,e=TX_lerp(-.12,.5,T)+(r()-.5)*.2,L=(young?.6+(1-T)*1.2:1.3+Math.pow(1-T,.7)*(Rmax-.4))*(.7+.5*r()),dx=Math.cos(yaw),dz=Math.sin(yaw),b0=tp(hb);
  const bp=s=>[b0[0]+dx*L*s*Math.cos(e),hb+L*s*Math.sin(e)-L*.2*s*s*(1-T),b0[2]+dz*L*s*Math.cos(e)];
  const bpath=[0,.33,.66,1].map(bp),rb=(young?.025:.07)*(1-hb/H*.5);
  F_tube(tr,bpath,[rb,rb*.7,rb*.45,rb*.2],MOB?3:4,1,1,(P)=>tcol(P[1]));
  const np=young?2:2+Math.round(r()*2*Math.max(q,.7));
  for(let j=0;j<np;j++){const s=.42+.58*(j+r()*.8)/np,pc=bp(s),sz=(young?1.1:1.9)*(.75+.6*r())*(1.1-.35*T*(young?0:1));
   const hd=Math.hypot(pc[0],pc[2]),ao=TX_lerp(.72,1.15,TX_cl(hd/(Rmax*.85)))*TX_lerp(.85,1.1,T)*(.88+.24*r());
   F_puff(fo,[pc[0]+(r()-.5)*.4,pc[1]+(r()-.5)*.3,pc[2]+(r()-.5)*.4],sz,r()*6.28,(r()-.5)*.6,cc,[ao*.95,ao,ao*.9])}}
 const top=tp(H);for(let j=0;j<(young?2:4);j++)F_puff(fo,[top[0]+(r()-.5)*.8,H-.8+j*.35,top[2]+(r()-.5)*.8],young?1.2:2.2*(1-j*.12),r()*6.28,0,cc,[1.1,1.15,1.05]);
 return{trunk:F_geo(tr),foliage:F_geo(fo),r0,H}}
// ---------- молодая ель (подрост) ----------
function F_spruce(seed){
 const r=TX_rng(seed*313+7),g=F_G(),nt=8;
 for(let i=0;i<nt;i++){const t=i/nt,h=.1+t*.86,len=.62*(1-t)+.13,nf=7-(t>.6?2:0);
  for(let f=0;f<nf;f++){const a=f/nf*6.283+i*.9+r()*.3,dx=Math.cos(a),dz=Math.sin(a),px=-dz,pz=dx,w=len*.58,droop=len*(.35+.2*r()),h0=h+.02*r();
   const P=[[dx*.02-px*w*.12,h0,dz*.02-pz*w*.12],[dx*.02+px*w*.12,h0,dz*.02+pz*w*.12],[dx*len+px*w*.55,h0-droop,dz*len+pz*w*.55],[dx*len-px*w*.55,h0-droop,dz*len-pz*w*.55]];
   const n=F_nrm(dx*.35,1,dz*.35),ao=TX_lerp(.7,1.1,t)*(.9+.2*r());F_quad(g,P,[n,n,n,n],[ao*.9,ao,ao*.9],F_UV)}}
 for(const th of[0,1.57]){const c=Math.cos(th),s=Math.sin(th),w=.1,P=[[-c*w,.92,-s*w],[c*w,.92,s*w],[c*w*.3,1.14,s*w*.3],[-c*w*.3,1.14,-s*w*.3]];const n=[0,1,0];F_quad(g,P,[n,n,n,n],[1,1.1,1],F_UV)}
 return F_geo(g)}
function F_fallen(seed){const r=TX_rng(seed*29+3),g=F_G();
 for(let k=0;k<3;k++){const a=(k-1)*.45+(r()-.5)*.2,dx=Math.cos(a),dz=Math.sin(a),px=-dz,pz=dx,L=.9+r()*.8,w=L*.5,n=F_nrm(0,1,0);
  F_quad(g,[[-px*.04,.03,-pz*.04],[px*.04,.03,pz*.04],[dx*L+px*w*.5,.05,dz*L+pz*w*.5],[dx*L-px*w*.5,.05,dz*L-pz*w*.5]],[n,n,n,n],[.8,.85,.75],F_UV)}
 return F_geo(g)}
function F_grassGeo(){const g=F_G();for(let k=0;k<3;k++){const th=k*1.047+.2,c=Math.cos(th),s=Math.sin(th),w=.5,h=.85,n=[0,1,0];
  F_quad(g,[[-c*w,0,-s*w],[c*w,0,s*w],[c*w,h,s*w],[-c*w,h,-s*w]],[n,n,n,n],[1,1,1],F_UV)}return F_geo(g)}
function F_rockGeo(seed){const geo=new THREE.IcosahedronGeometry(1,3),p=geo.attributes.position,r=TX_rng(seed);
 const ph=[r()*50,r()*50,r()*50];
 for(let i=0;i<p.count;i++){let x=p.getX(i),y=p.getY(i),z=p.getZ(i);
  const nz=TX_vn(x*1.6+ph[0],z*1.6+ph[1],65536,65536,seed)*.6+TX_vn(y*3.1+ph[2],x*3.1,65536,65536,seed+1)*.3+TX_vn(x*7+z*5+ph[0],y*7,65536,65536,seed+2)*.1;
  const k=.72+.6*nz;x*=k*1.1;z*=k;y=(y<0?y*.35:y)*k*.8;p.setXYZ(i,x,y,z)}
 geo.computeVertexNormals();const n=geo.attributes.normal,uv=geo.attributes.uv,col=new Float32Array(p.count*3);
 for(let i=0;i<p.count;i++){const nx=Math.abs(n.getX(i)),ny=Math.abs(n.getY(i)),nzz=Math.abs(n.getZ(i)),x=p.getX(i),y=p.getY(i),z=p.getZ(i);
  if(ny>=nx&&ny>=nzz)uv.setXY(i,x*.7,z*.7);else if(nx>nzz)uv.setXY(i,z*.7,y*.7);else uv.setXY(i,x*.7,y*.7);
  const m=TX_ss(.45,.85,n.getY(i)+.15*(TX_vn(x*4,z*4,65536,65536,seed+5)-.5));col[i*3]=TX_lerp(.95,.5,m);col[i*3+1]=TX_lerp(.95,.78,m);col[i*3+2]=TX_lerp(.92,.32,m)}
 geo.setAttribute('color',new THREE.BufferAttribute(col,3));geo.computeBoundingSphere();return geo}
function F_logGeo(seed){const r=TX_rng(seed*7+1),g=F_G(),L=4.5+r()*3,rr=.2+r()*.14,path=[],rad=[];
 for(let k=0;k<=6;k++){path.push([-L/2+L*k/6,rr*.6+(r()-.5)*.03,0]);rad.push(rr*(1-.15*k/6))}
 F_tube(g,path,rad,9,2.4,Math.max(1,Math.round(6.283*rr/1.2)),()=>[.72,.7,.66]);
 for(const[sx,x]of[[-1,path[0][0]],[1,path[6][0]]]){const b=g.p.length/3;g.p.push(x,path[0][1],0);g.n.push(sx,0,0);g.uv.push(.5,.5);g.c.push(1.25,1,.75);
  for(let j=0;j<=9;j++){const a=j/9*6.283;g.p.push(x,path[0][1]+Math.cos(a)*rad[0],Math.sin(a)*rad[0]);g.n.push(sx,0,0);g.uv.push(.5+Math.cos(a)*.4,.5+Math.sin(a)*.4);g.c.push(1.1,.85,.62)}
  for(let j=0;j<9;j++)g.i.push(b,b+1+j,b+2+j,b,b+2+j,b+1+j)}
 return{geo:F_geo(g),L,rr}}
// ---------- материалы ----------
const F_T={value:0};
function F_wind(mat,amp,hs,flut){mat.onBeforeCompile=sh=>{sh.uniforms.uTime=F_T;
 sh.vertexShader=('uniform float uTime;\n'+sh.vertexShader).replace('#include <begin_vertex>',`#include <begin_vertex>
 {float sw=clamp(position.y/${hs.toFixed(1)},0.,1.);sw*=sw;float ph=uTime*1.15+instanceMatrix[3][0]*.11+instanceMatrix[3][2]*.13;
 transformed.x+=(sin(ph)*.7+sin(ph*2.3+position.y)*.3)*${amp.toFixed(3)}*sw;transformed.z+=(cos(ph*.87)*.7+sin(ph*1.9)*.3)*${amp.toFixed(3)}*sw*.7;
 transformed+=vec3(sin(uTime*2.7+position.x*3.1+position.z*2.3),sin(uTime*2.1+position.y*2.7),cos(uTime*2.4+position.z*3.3))*${flut.toFixed(3)}*sw;}`)};
 mat.customProgramCacheKey=()=>'w'+amp+hs+flut}
const F_trunkMat=new THREE.MeshStandardMaterial({map:BK.map,normalMap:BK.normalMap,normalScale:new THREE.Vector2(1.5,1.5),roughness:.95,vertexColors:true});F_wind(F_trunkMat,.5,26,.0);
const F_foliMat=new THREE.MeshStandardMaterial({map:TF,alphaTest:.42,roughness:.82,vertexColors:true});F_wind(F_foliMat,.55,26,.05);
const F_sprMat=new THREE.MeshStandardMaterial({map:FR,alphaTest:.45,roughness:.85,vertexColors:true});F_wind(F_sprMat,.12,2,.02);
const F_grassMat=new THREE.MeshStandardMaterial({map:GRS,alphaTest:.5,roughness:1,vertexColors:true});F_wind(F_grassMat,.25,.9,.02);
const F_rockMat=new THREE.MeshStandardMaterial({map:RK.map,normalMap:RK.normalMap,normalScale:new THREE.Vector2(1.2,1.2),roughness:.92,vertexColors:true});
const F_logMat=new THREE.MeshStandardMaterial({map:BK.map,normalMap:BK.normalMap,normalScale:new THREE.Vector2(1.5,1.5),roughness:.97,vertexColors:true});
// ---------- наборы геометрий ----------
const F_OLD=[F_pine(1,0),F_pine(2,0),F_pine(3,0)],F_YNG=[F_pine(4,1),F_pine(5,1)],F_VAR=[...F_OLD,...F_YNG];
const F_SPR=[F_spruce(1),F_spruce(2)],F_FALL=F_fallen(1),F_GRASS=F_grassGeo(),F_ROCKS=[F_rockGeo(1),F_rockGeo(2),F_rockGeo(3)],F_LOGS=[F_logGeo(1),F_logGeo(2)];
// просека к луне от точки старта
const F_mh=Math.hypot(MOON_DIR.x,MOON_DIR.z),F_mx=MOON_DIR.x/F_mh,F_mz=MOON_DIR.z/F_mh;
const F_glade=(x,z)=>{const a=x*F_mx+z*F_mz,b=Math.abs(-x*F_mz+z*F_mx);return a>0&&a<50&&b<9+a*.15};
// ---------- чанки ----------
const F_chunks=new Map(),F_key=(a,b)=>a+','+b,_m=new THREE.Matrix4(),_q=new THREE.Quaternion(),_e=new THREE.Euler(),_p=new THREE.Vector3(),_s=new THREE.Vector3(),_c=new THREE.Color();
function F_inst(grp,geo,mat,list,cast,cx,cz,rad){ // list: [{x,y,z,yaw,sx,sy,sz,tx,tz,c}]
 if(!list.length)return;const m=new THREE.InstancedMesh(geo,mat,list.length);
 list.forEach((o,i)=>{_e.set(o.tx||0,o.yaw,o.tz||0);_q.setFromEuler(_e);_p.set(o.x,o.y,o.z);_s.set(o.sx,o.sy,o.sz);_m.compose(_p,_q,_s);m.setMatrixAt(i,_m);_c.setRGB(o.c[0],o.c[1],o.c[2]);m.setColorAt(i,_c)});
 m.instanceMatrix.needsUpdate=true;m.instanceColor.needsUpdate=true;m.castShadow=cast;m.receiveShadow=true;
 m.boundingSphere=new THREE.Sphere(new THREE.Vector3(cx,12,cz),CH*.72+rad);m.matrixAutoUpdate=false;grp.add(m)}
function F_make(cx,cz){
 const r=TX_rng((cx*73856093^cz*19349663)|0),grp=new THREE.Group(),colls=[],ox=cx*CH,oz=cz*CH,mx=ox+CH/2,mz=oz+CH/2;
 grp.add(buildGround(cx,cz));
 const tv=F_VAR.map(()=>[]),cs=5;
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){const x=ox+(i+.5)*cs+(r()-.5)*4.2,z=oz+(j+.5)*cs+(r()-.5)*4.2,d=forestDensity(x,z);
  if(r()>.22+.55*(.35+.65*d)||x*x+z*z<64||F_glade(x,z))continue;const young=r()<.3,v=young?3+(r()*2|0):(r()*3|0),s=young?.8+.5*r():.85+.35*r(),g=F_VAR[v];
  tv[v].push({x,y:terrainH(x,z)-.2,z,yaw:r()*6.28,sx:s*(.95+.1*r()),sy:s*(.93+.14*r()),sz:s,tx:(r()-.5)*.05,tz:(r()-.5)*.05,c:(b=>[b*(.92+.16*r()),b,b*(.9+.2*r())])(.8+.35*r()),b:1});
  colls.push({x,z,r:g.r0*s*1.15+.12})}
 tv.forEach((l,v)=>{F_inst(grp,F_VAR[v].trunk,F_trunkMat,l.map(o=>({...o,c:[o.c[1],o.c[1],o.c[1]]})),true,mx,mz,28);F_inst(grp,F_VAR[v].foliage,F_foliMat,l,true,mx,mz,28)});
 // подрост ели
 const sp=[[],[]];for(let k=0;k<10;k++){const x=ox+r()*CH,z=oz+r()*CH,s=.8+r()*1.5;sp[r()*2|0].push({x,y:terrainH(x,z)-.03,z,yaw:r()*6.28,sx:s,sy:s*(.85+.3*r()),sz:s,c:(b=>[b*.95,b,b*.9])(.8+.3*r())})}
 sp.forEach((l,i)=>F_inst(grp,F_SPR[i],F_sprMat,l,true,mx,mz,2));
 // лапы на земле
 const fl=[];for(let k=0;k<16;k++){const x=ox+r()*CH,z=oz+r()*CH,s=.7+r()*.8;fl.push({x,y:terrainH(x,z)+.01,z,yaw:r()*6.28,sx:s,sy:1,sz:s,c:[.9,.95,.85]})}F_inst(grp,F_FALL,F_sprMat,fl,false,mx,mz,2);
 // трава
 const gr=[];for(let k=0;k<Q.grass;k++){const x=ox+r()*CH,z=oz+r()*CH,s=.55+r()*.9;gr.push({x,y:terrainH(x,z)-.02,z,yaw:r()*6.28,sx:s,sy:s*(.8+.5*r()),sz:s,c:(b=>[b,b*(.95+.1*r()),b*.85])(.7+.45*r())})}F_inst(grp,F_GRASS,F_grassMat,gr,false,mx,mz,2);
 // камни
 const rk=[[],[],[]];for(let k=0;k<6;k++){const x=ox+r()*CH,z=oz+r()*CH,s=r()<.2?.9+r()*.9:.25+r()*.5,v=r()*3|0;rk[v].push({x,y:terrainH(x,z)+s*.12,z,yaw:r()*6.28,sx:s*(1+.5*r()),sy:s*(.7+.4*r()),sz:s,c:[1,1,1]});if(s>.5)colls.push({x,z,r:s*1.0})}
 rk.forEach((l,i)=>F_inst(grp,F_ROCKS[i],F_rockMat,l,true,mx,mz,3));
 // упавшие брёвна
 if(r()<.4){const v=r()*2|0,x=ox+4+r()*(CH-8),z=oz+4+r()*(CH-8),lg=F_LOGS[v];F_inst(grp,lg.geo,F_logMat,[{x,y:terrainH(x,z)+lg.rr*.2,z,yaw:r()*6.28,sx:1,sy:1,sz:1,tz:(r()-.5)*.16,c:[1,1,1]}],true,mx,mz,6)}
 S.add(grp);return{grp,colls}}
function F_free(c){S.remove(c.grp);c.grp.traverse(o=>{if(o.isInstancedMesh)o.dispose();else if(o.isMesh)o.geometry.dispose()})}
function forestUpdate(px,pz,all){
 const cx=Math.floor(px/CH),cz=Math.floor(pz/CH),R2=(Q.chunks+.6)**2,need=[];
 for(let i=-Q.chunks-1;i<=Q.chunks+1;i++)for(let j=-Q.chunks-1;j<=Q.chunks+1;j++){const d=i*i+j*j;if(d<=R2)need.push([d,cx+i,cz+j])}
 need.sort((a,b)=>a[0]-b[0]);let made=0;
 for(const[,a,b]of need){const k=F_key(a,b);if(!F_chunks.has(k)){F_chunks.set(k,F_make(a,b));if(!all&&++made>=1)break}}
 const U2=(Q.chunks+1.6)**2;for(const[k,c]of F_chunks){const[a,b]=k.split(',').map(Number);if((a-cx)**2+(b-cz)**2>U2){F_free(c);F_chunks.delete(k)}}}
function forestColliders(px,pz,out){out.length=0;const cx=Math.floor(px/CH),cz=Math.floor(pz/CH);
 for(let i=-1;i<=1;i++)for(let j=-1;j<=1;j++){const c=F_chunks.get(F_key(cx+i,cz+j));if(c)for(const o of c.colls)out.push(o)}return out}
