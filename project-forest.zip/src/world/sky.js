//# FILE: world/sky.js
//# ЧТО: небо-купол (шейдер): градиент, звёзды, тонкие облака, луна с кратерами/морями и гало; следует за камерой.
//# ТОП-УРОВЕНЬ: SK_mat, SK_mesh
const SK_mat=new THREE.ShaderMaterial({uniforms:{uMoon:{value:MOON_DIR},uFog:{value:FOGC},uTime:{value:0}},side:THREE.BackSide,depthWrite:false,depthTest:false,fog:false,
vertexShader:`varying vec3 vD;void main(){vD=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
fragmentShader:`varying vec3 vD;uniform vec3 uMoon,uFog;uniform float uTime;
float hash(vec2 p){p=fract(p*vec2(123.34,456.21));p+=dot(p,p+45.32);return fract(p.x*p.y);}
float hash3(vec3 p){p=fract(p*vec3(.1031,.1030,.0973));p+=dot(p,p.yxz+33.33);return fract((p.x+p.y)*p.z);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),f.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<5;i++){s+=a*noise(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return s;}
void main(){
 vec3 d=normalize(vD);float y=d.y;
 vec3 zen=vec3(.003,.008,.024),mid=vec3(.016,.038,.085);
 vec3 col=mix(mid,zen,smoothstep(.25,1.,y));float fa=1.-smoothstep(-.02,.24,y);
 float md=dot(d,uMoon);
 // звёзды
 vec3 sp=d*230.,ip=floor(sp);float hv=hash3(ip),st=0.;
 if(hv>.88){vec3 j=vec3(hash3(ip+7.1),hash3(ip+3.3),hash3(ip+9.7))-.5;st=smoothstep(.2,.0,length(fract(sp)-.5-j*.6))*(hv-.88)*8.*(.4+hash3(ip+1.));}
 st*=smoothstep(.1,.5,y);
 // тонкие облака
 vec2 cuv=d.xz/(y+.2)*1.1+vec2(uTime*.004,uTime*.002);
 float cl=smoothstep(.46,.84,fbm(cuv*2.2))*smoothstep(.0,.3,y)*.85;
 float cl2=smoothstep(.5,.9,fbm(cuv*5.+3.))*smoothstep(.0,.3,y)*.4;
 float mdp=max(md,0.);
 float glow=pow(mdp,28.)*.9+pow(mdp,7.)*.28+pow(mdp,220.)*1.6;
 col+=vec3(.55,.68,1.)*glow*.6;
 col+=vec3(.9,.95,1.)*st*(1.-cl);
 float lit=pow(mdp,9.)*1.6+.07;
 vec3 ccol=mix(vec3(.02,.035,.065),vec3(.5,.6,.78),lit);
 col=mix(col,ccol*(.55+glow*1.6),clamp(cl+cl2,0.,1.)*.75);
 // диск луны
 vec3 up=abs(uMoon.y)<.99?vec3(0,1,0):vec3(1,0,0);vec3 rt=normalize(cross(up,uMoon));vec3 u2=cross(uMoon,rt);
 vec2 q=vec2(dot(d,rt),dot(d,u2));float Rm=.05;float rr=length(q)/Rm;
 if(md>0.&&rr<1.){float z=sqrt(1.-rr*rr);vec3 n=vec3(q/Rm,z);vec3 L=normalize(vec3(.3,.22,.9));float dif=smoothstep(-.15,.75,dot(n,L));
  vec2 uvm=q/Rm;float maria=smoothstep(.45,.66,fbm(uvm*2.3+4.));float cr=fbm(uvm*11.);float cr2=smoothstep(.55,.75,fbm(uvm*5.+9.));
  vec3 mc=mix(vec3(.9,.88,.82),vec3(.44,.47,.52),maria*.85);mc*=(.8+.35*cr)*(1.-.18*cr2);
  vec3 mcol=mc*dif*pow(z,.3)*3.4;col=mix(col,mcol,smoothstep(1.,.965,rr)*(1.-clamp(cl+cl2,0.,1.)*.55));}
 gl_FragColor=vec4(col,1.);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
 gl_FragColor.rgb=mix(gl_FragColor.rgb,linearToOutputTexel(vec4(uFog,1.)).rgb,fa);
}`});
const SK_mesh=new THREE.Mesh(new THREE.SphereGeometry(300,48,32),SK_mat);SK_mesh.frustumCulled=false;SK_mesh.renderOrder=-10;S.add(SK_mesh);
