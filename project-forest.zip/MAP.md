# MAP (генерируется build.js — не править руками)

| Файл | Строк | Что | Верхний уровень |
|---|---|---|---|
| `src/textures/A-forest-textures.js` | 141 | textures/A-forest-textures.js — всё рисуется на canvas при старте, без внешних файлов. Альбедо + карты нормалей (из карты высот). | TX_AN, TX_lerp, TX_ss, TX_rng, TX_h, TX_vn, TX_fbm, TX_cvs, TX_tex, TX_normalMap, TX_readH, TX_ground… |
| `src/core/00-imports.js` | 6 | import THREE и заглушка window.mp (мультиплеер-хуки). Всегда первым. |  |
| `src/core/01-renderer-scene.js` | 28 | рендерер R, сцена S, камера cam, туман, лунный свет MOONL, ambient, качество Q. | $, MOB, Q_PRESETS, Q_NAME, R, S, FOGC, cam, MOON_DIR, MOONL, HEMI |
| `src/core/02-textures.js` | 4 | маркер подстановки секции A из textures.js (генераторы текстур леса). |  |
| `src/world/terrain.js` | 25 | функция рельефа terrainH(x,z), плотность леса, текстуры (GT земля, BK кора, TF кисть, FR лапа ели, GR трава, RK камень), материал земли и построение мэша земли чанка. | CH, TNZ, terrainH, forestDensity, GT, GTILE, groundMat, buildGround |
| `src/world/forest.js` | 144 | геометрия сосен/ели/травы/камней/брёвен (процедурно), материалы с ветром, потоковые чанки бесконечного леса, коллайдеры деревьев. | F_G, F_geo, F_nrm, F_tube, F_quad, F_UV, F_puff, F_pine, F_spruce, F_fallen, F_grassGeo, F_rockGeo… |
| `src/world/sky.js` | 44 | небо-купол (шейдер): градиент, звёзды, тонкие облака, луна с кратерами/морями и гало; следует за камерой. | SK_mat, SK_mesh |
| `src/mechanics/props.js` | 58 | реестр спавна SPAWN, физические пропсы, прицел PR_aim, выбор луча PR_pick. | PR_bodies, PR_d, SPAWN, PR_add, PR_aim, PR_pick, PR_step, PR_pairs, PR_tick |
| `src/mechanics/gravgun.js` | 39 | гравитационная пушка: ПКМ/E — хват и бросок вниз, ЛКМ/F — удар (выстрел удерживаемым), колесо — дистанция. На телефоне — кнопки «Хват»/«Удар». | GG, GG_dir, GG_drop, GG_grab, GG_punch, GG_tick, GG_typing |
| `src/ui/spawn-menu.js` | 29 | меню спавна (клавиша Q / кнопка ☰): всё, что есть в SPAWN.items, с поиском и категориями. Предмет появляется в точке прицела. | SM |
| `src/mechanics/player.js` | 42 | игрок от первого лица (WASD/мышь, джойстик/свайп), столкновения со стволами, привязка луны к игроку (тени), главный цикл. | PL, PL_cv, PL_look, PL_up, PL_r, PL_moon, PL_tick |
| `src/core/99-ready.js` | 4 | Сигнал window.__gameReady. Всегда последним. |  |

## Имена из textures, которые использует игра (не переименовывать)
TX_bark, TX_frond, TX_grass, TX_ground, TX_lerp, TX_rng, TX_rock, TX_ss, TX_tuft, TX_vn
