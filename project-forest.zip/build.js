// build.js — собирает index.html и textures.js из src/ (без зависимостей: node build.js).
//   node build.js          сборка + обновление MAP.md
//   node build.js --check  то же + проверка синтаксиса итоговой игры (ловит дубли const и опечатки)
// Строки //# и <!--# ... --> — подсказки для людей/Claude, в сборку не попадают.
const fs=require('fs'),path=require('path'),cp=require('child_process'),os=require('os');
const S=path.join(__dirname,'src'),rd=f=>fs.readFileSync(path.join(S,f),'utf8'),O=JSON.parse(rd('order.json'));
const strip=t=>t.replace(/^\/\/#.*\r?\n/gm,'').replace(/^<!--#.*-->\r?\n/gm,'');
const game=O.game.map(f=>strip(rd(f))).join(''),
 textures=strip(rd(O.texturesHead))+O.textures.map(f=>strip(rd(f))).join(''),
 css=strip(rd(O.css)),menu=strip(rd(O.menu));
const html=strip(rd(O.shell)).replace('{{CSS}}\n',()=>css).replace('{{GAME}}\n',()=>game).replace('{{MENU}}\n',()=>menu).replace('{{TEXTURES}}',()=>textures);
fs.writeFileSync(path.join(__dirname,'index.html'),html);fs.writeFileSync(path.join(__dirname,'textures.js'),textures);
// --- MAP.md: карта файлов для быстрого поиска ---
const sym=/^(?:async\s+)?function\*?\s+([\w$]+)|^(?:const|let|var)\s+([\w$]+)|^class\s+([\w$]+)/;
const rows=[],all=[...O.textures.map(f=>[f,'textures']),...O.game.map(f=>[f,'game'])];
for(const[f,k]of all){const t=rd(f),L=t.split('\n'),what=(L.find(l=>l.startsWith('//# ЧТО'))||L.find(l=>l.startsWith('//# FILE'))||'').replace(/^\/\/# (ЧТО: |FILE: )?/,'');
 const n=[];for(const l of L){const m=sym.exec(l);if(m){const x=m.slice(1).find(Boolean);if(!n.includes(x))n.push(x)}}
 rows.push(`| \`src/${f}\` | ${L.length} | ${what.replace(/\|/g,'/')} | ${n.slice(0,12).join(', ')}${n.length>12?'…':''} |`)}
const used=new Set(),tn=new Set();for(const f of O.textures)for(const l of rd(f).split('\n')){const m=sym.exec(l);if(m)tn.add(m.slice(1).find(Boolean))}
for(const n of tn)if(new RegExp('(?<![\\w$])'+n.replace(/\$/g,'\\$')+'(?![\\w$])').test(game))used.add(n);
fs.writeFileSync(path.join(__dirname,'MAP.md'),`# MAP (генерируется build.js — не править руками)\n\n| Файл | Строк | Что | Верхний уровень |\n|---|---|---|---|\n${rows.join('\n')}\n\n## Имена из textures, которые использует игра (не переименовывать)\n${[...used].sort().join(', ')}\n`);
console.log('built: index.html',(html.length/1024|0)+'KB, textures.js',(textures.length/1024|0)+'KB');
if(process.argv.includes('--check')){
 const T={};textures.split(/^\/\/@@(\w+).*$/m).forEach((x,i,a)=>{if(i%2)T[x]=a[i+1].replace(/^\n|\n+$/g,'')});
 const code=game.replace(/\/\/@TEXTURES:(\w+)@/g,(m,k)=>T[k]??m),tmp=path.join(os.tmpdir(),'game_check.mjs');fs.writeFileSync(tmp,code);
 const r=cp.spawnSync(process.execPath,['--check',tmp],{encoding:'utf8'});
 if(r.status){console.error('SYNTAX ERROR:\n'+r.stderr);process.exit(1)}console.log('syntax OK (game + textures)')}
